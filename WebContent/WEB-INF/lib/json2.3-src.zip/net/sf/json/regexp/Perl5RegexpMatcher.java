// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Perl5RegexpMatcher.java

package net.sf.json.regexp;

import org.apache.commons.lang.exception.NestableRuntimeException;
import org.apache.oro.text.regex.*;

// Referenced classes of package net.sf.json.regexp:
//			RegexpMatcher

public class Perl5RegexpMatcher
	implements RegexpMatcher
{

	private static final Perl5Compiler compiler = new Perl5Compiler();
	private Pattern pattern;

	public Perl5RegexpMatcher(String pattern)
	{
		this(pattern, false);
	}

	public Perl5RegexpMatcher(String pattern, boolean multiline)
	{
		try
		{
			if (multiline)
				this.pattern = compiler.compile(pattern, 32776);
			else
				this.pattern = compiler.compile(pattern, 32768);
		}
		catch (MalformedPatternException mpe)
		{
			throw new NestableRuntimeException(mpe);
		}
	}

	public String getGroupIfMatches(String str, int group)
	{
		PatternMatcher matcher = new Perl5Matcher();
		if (matcher.matches(str, pattern))
			return matcher.getMatch().group(1);
		else
			return "";
	}

	public boolean matches(String str)
	{
		return (new Perl5Matcher()).matches(str, pattern);
	}

}
