// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RegexpUtils.java

package net.sf.json.regexp;


// Referenced classes of package net.sf.json.regexp:
//			Perl5RegexpMatcher, JdkRegexpMatcher, RegexpMatcher

public class RegexpUtils
{

	private static String javaVersion = "1.3.1";

	public static RegexpMatcher getMatcher(String pattern)
	{
		if (isJDK13())
			return new Perl5RegexpMatcher(pattern);
		else
			return new JdkRegexpMatcher(pattern);
	}

	public static RegexpMatcher getMatcher(String pattern, boolean multiline)
	{
		if (isJDK13())
			return new Perl5RegexpMatcher(pattern, true);
		else
			return new JdkRegexpMatcher(pattern, true);
	}

	public static boolean isJDK13()
	{
		return javaVersion.indexOf("1.3") != -1;
	}

	private RegexpUtils()
	{
	}

	static 
	{
		javaVersion = System.getProperty("java.version");
	}
}
