// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RegexpMatcher.java

package net.sf.json.regexp;


public interface RegexpMatcher
{

	public abstract String getGroupIfMatches(String s, int i);

	public abstract boolean matches(String s);
}
