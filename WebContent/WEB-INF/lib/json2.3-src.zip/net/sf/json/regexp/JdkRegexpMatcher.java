// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JdkRegexpMatcher.java

package net.sf.json.regexp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package net.sf.json.regexp:
//			RegexpMatcher

public class JdkRegexpMatcher
	implements RegexpMatcher
{

	private final Pattern pattern;

	public JdkRegexpMatcher(String pattern)
	{
		this(pattern, false);
	}

	public JdkRegexpMatcher(String pattern, boolean multiline)
	{
		if (multiline)
			this.pattern = Pattern.compile(pattern, 8);
		else
			this.pattern = Pattern.compile(pattern);
	}

	public String getGroupIfMatches(String str, int group)
	{
		Matcher matcher = pattern.matcher(str);
		if (matcher.matches())
			return matcher.group(group);
		else
			return "";
	}

	public boolean matches(String str)
	{
		return pattern.matcher(str).matches();
	}
}
