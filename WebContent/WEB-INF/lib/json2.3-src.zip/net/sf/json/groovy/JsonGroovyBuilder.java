// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonGroovyBuilder.java

package net.sf.json.groovy;

import groovy.lang.*;
import java.util.*;
import net.sf.json.*;

public class JsonGroovyBuilder extends GroovyObjectSupport
{

	private static final String JSON = "json";
	private JSON current;
	private Map properties;
	private Stack stack;

	public JsonGroovyBuilder()
	{
		stack = new Stack();
		properties = new HashMap();
	}

	public Object getProperty(String name)
	{
		if (!stack.isEmpty())
		{
			Object top = stack.peek();
			if (top instanceof JSONObject)
			{
				JSONObject json = (JSONObject)top;
				if (json.containsKey(name))
					return json.get(name);
				else
					return _getProperty(name);
			} else
			{
				return _getProperty(name);
			}
		} else
		{
			return _getProperty(name);
		}
	}

	public Object invokeMethod(String name, Object arg)
	{
		if ("json".equals(name) && stack.isEmpty())
			return createObject(name, arg);
		Object args[] = (Object[])(Object[])arg;
		if (args.length == 0)
			throw new MissingMethodException(name, getClass(), args);
		Object value = null;
		if (args.length > 1)
		{
			JSONArray array = new JSONArray();
			stack.push(array);
			for (int i = 0; i < args.length; i++)
			{
				if (args[i] instanceof Closure)
				{
					append(name, createObject((Closure)args[i]));
					continue;
				}
				if (args[i] instanceof Map)
				{
					append(name, createObject((Map)args[i]));
					continue;
				}
				if (args[i] instanceof List)
					append(name, createArray((List)args[i]));
				else
					_append(name, args[i], (JSON)stack.peek());
			}

			stack.pop();
		} else
		if (args[0] instanceof Closure)
			value = createObject((Closure)args[0]);
		else
		if (args[0] instanceof Map)
			value = createObject((Map)args[0]);
		else
		if (args[0] instanceof List)
			value = createArray((List)args[0]);
		if (stack.isEmpty())
		{
			JSONObject object = new JSONObject();
			object.accumulate(name, current);
			current = object;
		} else
		{
			JSON top = (JSON)stack.peek();
			if (top instanceof JSONObject)
				append(name, current != null ? ((Object) (current)) : value);
		}
		return current;
	}

	public void setProperty(String name, Object value)
	{
		if (value instanceof GString)
		{
			value = value.toString();
			try
			{
				value = JSONSerializer.toJSON(value);
			}
			catch (JSONException jsone) { }
		} else
		if (value instanceof Closure)
			value = createObject((Closure)value);
		else
		if (value instanceof Map)
			value = createObject((Map)value);
		else
		if (value instanceof List)
			value = createArray((List)value);
		append(name, value);
	}

	private Object _getProperty(String name)
	{
		if (properties.containsKey(name))
			return properties.get(name);
		else
			return super.getProperty(name);
	}

	private void append(String key, Object value)
	{
		Object target = null;
		if (!stack.isEmpty())
		{
			target = stack.peek();
			current = (JSON)target;
			_append(key, value, current);
		} else
		{
			properties.put(key, value);
		}
	}

	private void _append(String key, Object value, JSON target)
	{
		if (target instanceof JSONObject)
			((JSONObject)target).accumulate(key, value);
		else
		if (target instanceof JSONArray)
			((JSONArray)target).element(value);
	}

	private JSON createArray(List list)
	{
		JSONArray array = new JSONArray();
		stack.push(array);
		Object element;
		for (Iterator elements = list.iterator(); elements.hasNext(); array.element(element))
		{
			element = elements.next();
			if (element instanceof Closure)
			{
				element = createObject((Closure)element);
				continue;
			}
			if (element instanceof Map)
			{
				element = createObject((Map)element);
				continue;
			}
			if (element instanceof List)
				element = createArray((List)element);
		}

		stack.pop();
		return array;
	}

	private JSON createObject(Closure closure)
	{
		JSONObject object = new JSONObject();
		stack.push(object);
		closure.setDelegate(this);
		closure.call();
		stack.pop();
		return object;
	}

	private JSON createObject(Map map)
	{
		JSONObject object = new JSONObject();
		stack.push(object);
		String key;
		Object value;
		for (Iterator properties = map.entrySet().iterator(); properties.hasNext(); object.element(key, value))
		{
			java.util.Map.Entry property = (java.util.Map.Entry)properties.next();
			key = String.valueOf(property.getKey());
			value = property.getValue();
			if (value instanceof Closure)
			{
				value = createObject((Closure)value);
				continue;
			}
			if (value instanceof Map)
			{
				value = createObject((Map)value);
				continue;
			}
			if (value instanceof List)
				value = createArray((List)value);
		}

		stack.pop();
		return object;
	}

	private JSON createObject(String name, Object arg)
	{
		Object args[] = (Object[])(Object[])arg;
		if (args.length == 0)
			throw new MissingMethodException(name, getClass(), args);
		if (args.length == 1)
		{
			if (args[0] instanceof Closure)
				return createObject((Closure)args[0]);
			if (args[0] instanceof Map)
				return createObject((Map)args[0]);
			if (args[0] instanceof List)
				return createArray((List)args[0]);
			else
				throw new JSONException("Unsupported type");
		}
		JSONArray array = new JSONArray();
		stack.push(array);
		for (int i = 0; i < args.length; i++)
		{
			if (args[i] instanceof Closure)
			{
				append(name, createObject((Closure)args[i]));
				continue;
			}
			if (args[i] instanceof Map)
			{
				append(name, createObject((Map)args[i]));
				continue;
			}
			if (args[i] instanceof List)
				append(name, createArray((List)args[i]));
			else
				_append(name, args[i], (JSON)stack.peek());
		}

		stack.pop();
		return array;
	}
}
