// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonSlurper.java

package net.sf.json.groovy;

import groovy.lang.GroovyObjectSupport;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import net.sf.json.*;

public class JsonSlurper extends GroovyObjectSupport
{

	private JsonConfig jsonConfig;

	public JsonSlurper()
	{
		this(new JsonConfig());
	}

	public JsonSlurper(JsonConfig jsonConfig)
	{
		this.jsonConfig = jsonConfig == null ? new JsonConfig() : jsonConfig;
	}

	public JSON parse(File file)
		throws IOException
	{
		return parse(((Reader) (new FileReader(file))));
	}

	public JSON parse(URL url)
		throws IOException
	{
		return parse(url.openConnection().getInputStream());
	}

	public JSON parse(InputStream input)
		throws IOException
	{
		return parse(((Reader) (new InputStreamReader(input))));
	}

	public JSON parse(String uri)
		throws IOException
	{
		return parse(new URL(uri));
	}

	public JSON parse(Reader reader)
		throws IOException
	{
		StringBuffer buffer = new StringBuffer();
		BufferedReader in = new BufferedReader(reader);
		for (String line = null; (line = in.readLine()) != null;)
			buffer.append(line).append("\n");

		return parseText(buffer.toString());
	}

	public JSON parseText(String text)
	{
		return JSONSerializer.toJSON(text, jsonConfig);
	}
}
