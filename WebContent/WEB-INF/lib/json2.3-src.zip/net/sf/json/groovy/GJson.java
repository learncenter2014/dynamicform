// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   GJson.groovy

package net.sf.json.groovy;

import groovy.lang.*;
import java.util.List;
import java.util.Map;
import org.codehaus.groovy.runtime.GeneratedClosure;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;

public class GJson
	implements GroovyObject
{

	transient MetaClass metaClass;
	public static Long __timeStamp;
	public static Long __timeStamp__239_neverHappen1247350110597;

	public GJson()
	{
		MetaClass metaclass;
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		metaclass = (MetaClass)ScriptBytecodeAdapter.castToType(ScriptBytecodeAdapter.invokeStaticMethodN(class1, org.codehaus.groovy.runtime.ScriptBytecodeAdapter.class, "initMetaClass", new Object[] {
			this
		}), class2);
		metaclass;
		(MetaClass)ScriptBytecodeAdapter.castToType(metaclass, class2);
		this;
		JVM INSTR swap ;
		metaClass;
		JVM INSTR pop ;
	}

	public static void enhanceClasses()
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		Object s = ScriptBytecodeAdapter.invokeStaticMethod0(class1, class1, "enhanceString");
		Object l = ScriptBytecodeAdapter.invokeStaticMethod0(class1, class1, "enhanceCollection");
		Object m = ScriptBytecodeAdapter.invokeStaticMethod0(class1, class1, "enhanceMap");
		Object j = ScriptBytecodeAdapter.invokeStaticMethod0(class1, class1, "enhanceJSONObject");
		if (DefaultTypeTransformation.booleanUnbox(DefaultTypeTransformation.booleanUnbox(DefaultTypeTransformation.booleanUnbox(DefaultTypeTransformation.booleanUnbox(s) || DefaultTypeTransformation.booleanUnbox(l) ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE))) || DefaultTypeTransformation.booleanUnbox(m) ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE))) || DefaultTypeTransformation.booleanUnbox(j) ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE))))
			ScriptBytecodeAdapter.invokeMethod0(class1, groovy.lang.ExpandoMetaClass.class, "enableGlobally");
	}

	private static boolean enhanceString()
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		class _enhanceString_closure1 extends Closure
			implements GeneratedClosure
		{

			public Object doCall(Object it)
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceString_closure1.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.compareEqual(ScriptBytecodeAdapter.getProperty(net.sf.json.groovy.GJson.class, it, "name"), "isJsonEnhanced") ? Boolean.TRUE : Boolean.FALSE;
			}

			public Object doCall()
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceString_closure1.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
					null
				});
			}

			public _enhanceString_closure1(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceString_closure1.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
		}

		_enhanceString_closure2 _lenhancestring_closure2;
		_enhanceString_closure3 _lenhancestring_closure3;
		if (!DefaultTypeTransformation.booleanUnbox(ScriptBytecodeAdapter.invokeMethodN(class1, ScriptBytecodeAdapter.getProperty(class1, ScriptBytecodeAdapter.getProperty(class1, java.lang.String.class, "metaClass"), "methods"), "find", new Object[] {
	new _enhanceString_closure1(class1, class1)
})))
		{
			Object asType = new Reference(ScriptBytecodeAdapter.getMethodPointer(ScriptBytecodeAdapter.getProperty(class1, java.lang.String.class, "metaClass"), "asType"));
			class _enhanceString_closure2 extends Closure
				implements GeneratedClosure
			{

				private Reference asType;

				public Object doCall(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceString_closure2.class;
					Class class5 = groovy.lang.MetaClass.class;
					Object obj = clazz.get();
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSON.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONSerializer.class, "toJSON", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSONArray.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONArray.class, "fromObject", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSONObject.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONObject.class, "fromObject", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSONFunction.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONFunction.class, "parse", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					else
						return ScriptBytecodeAdapter.invokeClosure(asType.get(), new Object[] {
							clazz.get()
						});
				}

				public Object call(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceString_closure2.class;
					Class class5 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class4, this, "doCall", new Object[] {
						clazz.get()
					});
				}

				public Object getAsType()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceString_closure2.class;
					Class class4 = groovy.lang.MetaClass.class;
					return asType.get();
				}

			public _enhanceString_closure2(Object _outerInstance, Object _thisObject, Reference asType)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceString_closure2.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
				asType;
				(Reference)asType;
				this;
				JVM INSTR swap ;
				asType;
				JVM INSTR pop ;
			}
			}

			_lenhancestring_closure2 = new _enhanceString_closure2(class1, class1, ((Reference) (asType)));
			_enhanceString_closure2  = _lenhancestring_closure2;
			ScriptBytecodeAdapter.setProperty(_lenhancestring_closure2, class1, ScriptBytecodeAdapter.getProperty(class1, java.lang.String.class, "metaClass"), "asType");
			class _enhanceString_closure3 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(Object it)
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceString_closure3.class;
					Class class4 = groovy.lang.MetaClass.class;
					return Boolean.TRUE;
				}

				public Object doCall()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceString_closure3.class;
					Class class4 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
						null
					});
				}

			public _enhanceString_closure3(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceString_closure3.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancestring_closure3 = new _enhanceString_closure3(class1, class1);
			_enhanceString_closure3 1 = _lenhancestring_closure3;
			ScriptBytecodeAdapter.setProperty(_lenhancestring_closure3, class1, ScriptBytecodeAdapter.getProperty(class1, java.lang.String.class, "metaClass"), "isJsonEnhanced");
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.TRUE, java.lang.Boolean.class));
		} else
		{
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.FALSE, java.lang.Boolean.class));
		}
	}

	private static boolean enhanceCollection()
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		class _enhanceCollection_closure4 extends Closure
			implements GeneratedClosure
		{

			public Object doCall(Object it)
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceCollection_closure4.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.compareEqual(ScriptBytecodeAdapter.getProperty(net.sf.json.groovy.GJson.class, it, "name"), "isJsonEnhanced") ? Boolean.TRUE : Boolean.FALSE;
			}

			public Object doCall()
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceCollection_closure4.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
					null
				});
			}

			public _enhanceCollection_closure4(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceCollection_closure4.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
		}

		_enhanceCollection_closure6 _lenhancecollection_closure6;
		if (!DefaultTypeTransformation.booleanUnbox(ScriptBytecodeAdapter.invokeMethodN(class1, ScriptBytecodeAdapter.getProperty(class1, ScriptBytecodeAdapter.getProperty(class1, java.util.Collection.class, "metaClass"), "methods"), "find", new Object[] {
	new _enhanceCollection_closure4(class1, class1)
})))
		{
			Object asType = new Reference(ScriptBytecodeAdapter.getMethodPointer(ScriptBytecodeAdapter.getProperty(class1, java.util.Collection.class, "metaClass"), "asType"));
			class _enhanceCollection_closure5 extends Closure
				implements GeneratedClosure
			{

				private Reference asType;

				public Object doCall(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceCollection_closure5.class;
					Class class5 = groovy.lang.MetaClass.class;
					Object obj = clazz.get();
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSONArray.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONArray.class, "fromObject", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					else
						return ScriptBytecodeAdapter.invokeClosure(asType.get(), new Object[] {
							clazz.get()
						});
				}

				public Object call(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceCollection_closure5.class;
					Class class5 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class4, this, "doCall", new Object[] {
						clazz.get()
					});
				}

				public Object getAsType()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceCollection_closure5.class;
					Class class4 = groovy.lang.MetaClass.class;
					return asType.get();
				}

			public _enhanceCollection_closure5(Object _outerInstance, Object _thisObject, Reference asType)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceCollection_closure5.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
				asType;
				(Reference)asType;
				this;
				JVM INSTR swap ;
				asType;
				JVM INSTR pop ;
			}
			}

			Object typeConverter = new _enhanceCollection_closure5(class1, class1, ((Reference) (asType)));
			ScriptBytecodeAdapter.setProperty(typeConverter, class1, ScriptBytecodeAdapter.getProperty(class1, java.util.ArrayList.class, "metaClass"), "asType");
			Object  = typeConverter;
			ScriptBytecodeAdapter.setProperty(typeConverter, class1, ScriptBytecodeAdapter.getProperty(class1, java.util.HashSet.class, "metaClass"), "asType");
			Object 1 = typeConverter;
			class _enhanceCollection_closure6 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(Object it)
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceCollection_closure6.class;
					Class class4 = groovy.lang.MetaClass.class;
					return Boolean.TRUE;
				}

				public Object doCall()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceCollection_closure6.class;
					Class class4 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
						null
					});
				}

			public _enhanceCollection_closure6(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceCollection_closure6.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancecollection_closure6 = new _enhanceCollection_closure6(class1, class1);
			_enhanceCollection_closure6 2 = _lenhancecollection_closure6;
			ScriptBytecodeAdapter.setProperty(_lenhancecollection_closure6, class1, ScriptBytecodeAdapter.getProperty(class1, java.util.Collection.class, "metaClass"), "isJsonEnhanced");
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.TRUE, java.lang.Boolean.class));
		} else
		{
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.FALSE, java.lang.Boolean.class));
		}
	}

	private static boolean enhanceMap()
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		class _enhanceMap_closure7 extends Closure
			implements GeneratedClosure
		{

			public Object doCall(Object it)
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceMap_closure7.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.compareEqual(ScriptBytecodeAdapter.getProperty(net.sf.json.groovy.GJson.class, it, "name"), "isJsonEnhanced") ? Boolean.TRUE : Boolean.FALSE;
			}

			public Object doCall()
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceMap_closure7.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
					null
				});
			}

			public _enhanceMap_closure7(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceMap_closure7.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
		}

		_enhanceMap_closure8 _lenhancemap_closure8;
		_enhanceMap_closure9 _lenhancemap_closure9;
		if (!DefaultTypeTransformation.booleanUnbox(ScriptBytecodeAdapter.invokeMethodN(class1, ScriptBytecodeAdapter.getProperty(class1, ScriptBytecodeAdapter.getProperty(class1, java.util.Map.class, "metaClass"), "methods"), "find", new Object[] {
	new _enhanceMap_closure7(class1, class1)
})))
		{
			Object asType = new Reference(ScriptBytecodeAdapter.getMethodPointer(ScriptBytecodeAdapter.getProperty(class1, java.util.Map.class, "metaClass"), "asType"));
			class _enhanceMap_closure8 extends Closure
				implements GeneratedClosure
			{

				private Reference asType;

				public Object doCall(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceMap_closure8.class;
					Class class5 = groovy.lang.MetaClass.class;
					Object obj = clazz.get();
					if (ScriptBytecodeAdapter.isCase(obj, net.sf.json.JSONObject.class))
						return ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, net.sf.json.JSONObject.class, "fromObject", new Object[] {
							ScriptBytecodeAdapter.getProperty(class4, this, "delegate")
						});
					else
						return ScriptBytecodeAdapter.invokeClosure(asType.get(), new Object[] {
							clazz.get()
						});
				}

				public Object call(Class class3)
				{
					class3;
					JVM INSTR new #31  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Class clazz;
					clazz;
					Class class4 = net.sf.json.groovy.GJson$_enhanceMap_closure8.class;
					Class class5 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class4, this, "doCall", new Object[] {
						clazz.get()
					});
				}

				public Object getAsType()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceMap_closure8.class;
					Class class4 = groovy.lang.MetaClass.class;
					return asType.get();
				}

			public _enhanceMap_closure8(Object _outerInstance, Object _thisObject, Reference asType)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceMap_closure8.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
				asType;
				(Reference)asType;
				this;
				JVM INSTR swap ;
				asType;
				JVM INSTR pop ;
			}
			}

			_lenhancemap_closure8 = new _enhanceMap_closure8(class1, class1, ((Reference) (asType)));
			_enhanceMap_closure8  = _lenhancemap_closure8;
			ScriptBytecodeAdapter.setProperty(_lenhancemap_closure8, class1, ScriptBytecodeAdapter.getProperty(class1, java.util.Map.class, "metaClass"), "asType");
			class _enhanceMap_closure9 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(Object it)
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceMap_closure9.class;
					Class class4 = groovy.lang.MetaClass.class;
					return Boolean.TRUE;
				}

				public Object doCall()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceMap_closure9.class;
					Class class4 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
						null
					});
				}

			public _enhanceMap_closure9(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceMap_closure9.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancemap_closure9 = new _enhanceMap_closure9(class1, class1);
			_enhanceMap_closure9 1 = _lenhancemap_closure9;
			ScriptBytecodeAdapter.setProperty(_lenhancemap_closure9, class1, ScriptBytecodeAdapter.getProperty(class1, java.util.Map.class, "metaClass"), "isJsonEnhanced");
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.TRUE, java.lang.Boolean.class));
		} else
		{
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.FALSE, java.lang.Boolean.class));
		}
	}

	private static boolean enhanceJSONObject()
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		class _enhanceJSONObject_closure10 extends Closure
			implements GeneratedClosure
		{

			public Object doCall(Object it)
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure10.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.compareEqual(ScriptBytecodeAdapter.getProperty(net.sf.json.groovy.GJson.class, it, "name"), "isJsonEnhanced") ? Boolean.TRUE : Boolean.FALSE;
			}

			public Object doCall()
			{
				Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure10.class;
				Class class4 = groovy.lang.MetaClass.class;
				return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
					null
				});
			}

			public _enhanceJSONObject_closure10(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure10.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
		}

		_enhanceJSONObject_closure11 _lenhancejsonobject_closure11;
		_enhanceJSONObject_closure12 _lenhancejsonobject_closure12;
		_enhanceJSONObject_closure13 _lenhancejsonobject_closure13;
		if (!DefaultTypeTransformation.booleanUnbox(ScriptBytecodeAdapter.invokeMethodN(class1, ScriptBytecodeAdapter.getProperty(class1, ScriptBytecodeAdapter.getProperty(class1, net.sf.json.JSONObject.class, "metaClass"), "methods"), "find", new Object[] {
	new _enhanceJSONObject_closure10(class1, class1)
})))
		{
			class _enhanceJSONObject_closure11 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(Object obj)
				{
					obj;
					JVM INSTR new #35  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					Object args;
					args;
					Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure11.class;
					Class class4 = groovy.lang.MetaClass.class;
					if (((Reference) (args)).get() instanceof Map)
					{
						ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "putAll", new Object[] {
							((Reference) (args)).get()
						});
						ScriptBytecodeAdapter.getProperty(class3, this, "delegate");
					} else
					if (DefaultTypeTransformation.booleanUnbox(!(((Reference) (args)).get() instanceof List) || !ScriptBytecodeAdapter.compareGreaterThanEqual(ScriptBytecodeAdapter.invokeMethod0(net.sf.json.groovy.GJson.class, ((Reference) (args)).get(), "size"), new Integer(2)) ? ((Object) (Boolean.FALSE)) : ((Object) (Boolean.TRUE))))
					{
						Object key = new Reference(ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ((Reference) (args)).get(), "remove", new Object[] {
							new Integer(0)
						}));
						if (ScriptBytecodeAdapter.compareEqual(ScriptBytecodeAdapter.invokeMethod0(net.sf.json.groovy.GJson.class, ((Reference) (args)).get(), "size"), new Integer(1)))
							ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "element", new Object[] {
								((Reference) (key)).get(), ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ((Reference) (args)).get(), "get", new Object[] {
									new Integer(0)
								})
							});
						else
							ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "element", new Object[] {
								((Reference) (key)).get(), ((Reference) (args)).get()
							});
					}
					return null;
				}

			public _enhanceJSONObject_closure11(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure11.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancejsonobject_closure11 = new _enhanceJSONObject_closure11(class1, class1);
			_enhanceJSONObject_closure11  = _lenhancejsonobject_closure11;
			ScriptBytecodeAdapter.setProperty(_lenhancejsonobject_closure11, class1, ScriptBytecodeAdapter.getProperty(class1, net.sf.json.JSONObject.class, "metaClass"), "leftShift");
			class _enhanceJSONObject_closure12 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(String s, Object obj)
				{
					s;
					JVM INSTR new #35  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					String key;
					key;
					Object defaultValue = new Reference(obj);
					Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure12.class;
					Class class4 = groovy.lang.MetaClass.class;
					Object previousValue = new Reference(ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "opt", new Object[] {
						key.get()
					}));
					Object obj1;
					if (!DefaultTypeTransformation.booleanUnbox(((Reference) (previousValue)).get()))
					{
						ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "element", new Object[] {
							key.get(), ((Reference) (defaultValue)).get()
						});
						obj1 = ScriptBytecodeAdapter.invokeMethodN(net.sf.json.groovy.GJson.class, ScriptBytecodeAdapter.getProperty(class3, this, "delegate"), "get", new Object[] {
							key.get()
						});
						obj1;
						((Reference) (previousValue)).set(obj1);
					}
					return ((Reference) (previousValue)).get();
				}

				public Object call(String s, Object obj)
				{
					s;
					JVM INSTR new #35  <Class Reference>;
					JVM INSTR dup_x1 ;
					JVM INSTR swap ;
					Reference();
					String key;
					key;
					Object defaultValue = new Reference(obj);
					Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure12.class;
					Class class4 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
						key.get(), ((Reference) (defaultValue)).get()
					});
				}

			public _enhanceJSONObject_closure12(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure12.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancejsonobject_closure12 = new _enhanceJSONObject_closure12(class1, class1);
			_enhanceJSONObject_closure12 1 = _lenhancejsonobject_closure12;
			ScriptBytecodeAdapter.setProperty(_lenhancejsonobject_closure12, class1, ScriptBytecodeAdapter.getProperty(class1, net.sf.json.JSONObject.class, "metaClass"), "get");
			class _enhanceJSONObject_closure13 extends Closure
				implements GeneratedClosure
			{

				public Object doCall(Object it)
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure13.class;
					Class class4 = groovy.lang.MetaClass.class;
					return Boolean.TRUE;
				}

				public Object doCall()
				{
					Class class3 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure13.class;
					Class class4 = groovy.lang.MetaClass.class;
					return ScriptBytecodeAdapter.invokeMethodOnCurrentN(class3, this, "doCall", new Object[] {
						null
					});
				}

			public _enhanceJSONObject_closure13(Object _outerInstance, Object _thisObject)
			{
				Class class1 = net.sf.json.groovy.GJson$_enhanceJSONObject_closure13.class;
				Class class2 = groovy.lang.MetaClass.class;
				super(_outerInstance, _thisObject);
			}
			}

			_lenhancejsonobject_closure13 = new _enhanceJSONObject_closure13(class1, class1);
			_enhanceJSONObject_closure13 2 = _lenhancejsonobject_closure13;
			ScriptBytecodeAdapter.setProperty(_lenhancejsonobject_closure13, class1, ScriptBytecodeAdapter.getProperty(class1, net.sf.json.JSONObject.class, "metaClass"), "isJsonEnhanced");
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.TRUE, java.lang.Boolean.class));
		} else
		{
			return DefaultTypeTransformation.booleanUnbox((Boolean)ScriptBytecodeAdapter.castToType(Boolean.FALSE, java.lang.Boolean.class));
		}
	}

	public MetaClass getMetaClass()
	{
		Class class2;
		MetaClass metaclass;
		Class class1 = net.sf.json.groovy.GJson.class;
		class2 = groovy.lang.MetaClass.class;
		if (!ScriptBytecodeAdapter.compareEqual(metaClass, null))
			break MISSING_BLOCK_LABEL_118;
		metaclass = (MetaClass)ScriptBytecodeAdapter.castToType(ScriptBytecodeAdapter.invokeStaticMethodN(class1, org.codehaus.groovy.runtime.ScriptBytecodeAdapter.class, "initMetaClass", new Object[] {
			this
		}), class2);
		metaclass;
		(MetaClass)ScriptBytecodeAdapter.castToType(metaclass, class2);
		this;
		JVM INSTR swap ;
		metaClass;
		JVM INSTR pop ;
		return (MetaClass)ScriptBytecodeAdapter.castToType(metaClass, class2);
	}

	public void setMetaClass(MetaClass mc)
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		metaClass = mc;
	}

	public Object invokeMethod(String method, Object arguments)
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		return getMetaClass().invokeMethod(this, method, arguments);
	}

	public Object getProperty(String property)
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		return getMetaClass().getProperty(this, property);
	}

	public void setProperty(String property, Object value)
	{
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		getMetaClass().setProperty(this, property, value);
	}

	boolean this$2$enhanceString()
	{
		return enhanceString();
	}

	boolean this$2$enhanceCollection()
	{
		return enhanceCollection();
	}

	boolean this$2$enhanceMap()
	{
		return enhanceMap();
	}

	boolean this$2$enhanceJSONObject()
	{
		return enhanceJSONObject();
	}

	void super$1$wait()
	{
		super.wait();
	}

	String super$1$toString()
	{
		return super.toString();
	}

	void super$1$wait(long l)
	{
		super.wait(l);
	}

	void super$1$wait(long l, int i)
	{
		super.wait(l, i);
	}

	void super$1$notify()
	{
		super.notify();
	}

	void super$1$notifyAll()
	{
		super.notifyAll();
	}

	Class super$1$getClass()
	{
		return super.getClass();
	}

	boolean super$1$equals(Object obj)
	{
		return super.equals(obj);
	}

	Object super$1$clone()
	{
		return super.clone();
	}

	int super$1$hashCode()
	{
		return super.hashCode();
	}

	void super$1$finalize()
	{
		super.finalize();
	}

	static 
	{
		Long long1;
		Long long2;
		Class class1 = net.sf.json.groovy.GJson.class;
		Class class2 = groovy.lang.MetaClass.class;
		long1 = new Long(0x1226bdc3985L);
		Long  = long1;
		__timeStamp = (Long)long1;
		long2 = new Long(0L);
		Long 1 = long2;
		__timeStamp__239_neverHappen1247350110597 = (Long)long2;
	}
}
