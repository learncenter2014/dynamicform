// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONObject.java

package net.sf.json;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;
import net.sf.ezmorph.MorpherRegistry;
import net.sf.ezmorph.array.ObjectArrayMorpher;
import net.sf.ezmorph.bean.BeanMorpher;
import net.sf.ezmorph.object.IdentityObjectMorpher;
import net.sf.json.processors.DefaultValueProcessor;
import net.sf.json.processors.JsonBeanProcessor;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.processors.JsonVerifier;
import net.sf.json.processors.PropertyNameProcessor;
import net.sf.json.regexp.RegexpMatcher;
import net.sf.json.regexp.RegexpUtils;
import net.sf.json.util.CycleDetectionStrategy;
import net.sf.json.util.EnumMorpher;
import net.sf.json.util.JSONTokener;
import net.sf.json.util.JSONUtils;
import net.sf.json.util.NewBeanInstanceStrategy;
import net.sf.json.util.PropertyFilter;
import net.sf.json.util.PropertySetStrategy;
import org.apache.commons.beanutils.*;
import org.apache.commons.collections.map.ListOrderedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

// Referenced classes of package net.sf.json:
//			AbstractJSON, JsonConfig, JSONException, JSONString, 
//			JSONArray, JSONFunction, JSON, JSONNull

public final class JSONObject extends AbstractJSON
	implements JSON, Map, Comparable
{

	private static final Log log = LogFactory.getLog(net/sf/json/JSONObject);
	private boolean nullObject;
	private Map properties;

	public static JSONObject fromObject(Object object)
	{
		return fromObject(object, new JsonConfig());
	}

	public static JSONObject fromObject(Object object, JsonConfig jsonConfig)
	{
		if (object == null || JSONUtils.isNull(object))
			return new JSONObject(true);
		if (object instanceof Enum)
			throw new JSONException("'object' is an Enum. Use JSONArray instead");
		if ((object instanceof Annotation) || object != null && object.getClass().isAnnotation())
			throw new JSONException("'object' is an Annotation.");
		if (object instanceof JSONObject)
			return _fromJSONObject((JSONObject)object, jsonConfig);
		if (object instanceof DynaBean)
			return _fromDynaBean((DynaBean)object, jsonConfig);
		if (object instanceof JSONTokener)
			return _fromJSONTokener((JSONTokener)object, jsonConfig);
		if (object instanceof JSONString)
			return _fromJSONString((JSONString)object, jsonConfig);
		if (object instanceof Map)
			return _fromMap((Map)object, jsonConfig);
		if (object instanceof String)
			return _fromString((String)object, jsonConfig);
		if (JSONUtils.isNumber(object) || JSONUtils.isBoolean(object) || JSONUtils.isString(object))
			return new JSONObject();
		if (JSONUtils.isArray(object))
			throw new JSONException("'object' is an array. Use JSONArray instead");
		else
			return _fromBean(object, jsonConfig);
	}

	public static Object toBean(JSONObject jsonObject)
	{
		if (jsonObject == null || jsonObject.isNullObject())
			return null;
		DynaBean dynaBean = null;
		JsonConfig jsonConfig = new JsonConfig();
		Map props = JSONUtils.getProperties(jsonObject);
		dynaBean = JSONUtils.newDynaBean(jsonObject, jsonConfig);
		for (Iterator entries = jsonObject.names(jsonConfig).iterator(); entries.hasNext();)
		{
			String name = (String)entries.next();
			String key = JSONUtils.convertToJavaIdentifier(name, jsonConfig);
			Class type = (Class)props.get(name);
			Object value = jsonObject.get(name);
			try
			{
				if (!JSONUtils.isNull(value))
				{
					if (value instanceof JSONArray)
						dynaBean.set(key, JSONArray.toCollection((JSONArray)value));
					else
					if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || JSONUtils.isNumber(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
						dynaBean.set(key, value);
					else
						dynaBean.set(key, toBean((JSONObject)value));
				} else
				if (type.isPrimitive())
				{
					log.warn((new StringBuilder()).append("Tried to assign null value to ").append(key).append(":").append(type.getName()).toString());
					dynaBean.set(key, JSONUtils.getMorpherRegistry().morph(type, null));
				} else
				{
					dynaBean.set(key, null);
				}
			}
			catch (JSONException jsone)
			{
				throw jsone;
			}
			catch (Exception e)
			{
				throw new JSONException((new StringBuilder()).append("Error while setting property=").append(name).append(" type").append(type).toString(), e);
			}
		}

		return dynaBean;
	}

	public static Object toBean(JSONObject jsonObject, Class beanClass)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(beanClass);
		return toBean(jsonObject, jsonConfig);
	}

	public static Object toBean(JSONObject jsonObject, Class beanClass, Map classMap)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(beanClass);
		jsonConfig.setClassMap(classMap);
		return toBean(jsonObject, jsonConfig);
	}

	public static Object toBean(JSONObject jsonObject, JsonConfig jsonConfig)
	{
		Class beanClass;
		Map classMap;
		Object bean;
		Map props;
		PropertyFilter javaPropertyFilter;
		Iterator entries;
		if (jsonObject == null || jsonObject.isNullObject())
			return null;
		beanClass = jsonConfig.getRootClass();
		classMap = jsonConfig.getClassMap();
		if (beanClass == null)
			return toBean(jsonObject);
		if (classMap == null)
			classMap = Collections.EMPTY_MAP;
		bean = null;
		try
		{
			if (beanClass.isInterface())
			{
				if (!java/util/Map.isAssignableFrom(beanClass))
					throw new JSONException((new StringBuilder()).append("beanClass is an interface. ").append(beanClass).toString());
				bean = new HashMap();
			} else
			{
				bean = jsonConfig.getNewBeanInstanceStrategy().newInstance(beanClass, jsonObject);
			}
		}
		catch (JSONException jsone)
		{
			throw jsone;
		}
		catch (Exception e)
		{
			throw new JSONException(e);
		}
		props = JSONUtils.getProperties(jsonObject);
		javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
		entries = jsonObject.names(jsonConfig).iterator();
_L2:
		String name;
		Class type;
		Object value;
		String key;
		if (!entries.hasNext())
			break; /* Loop/switch isn't completed */
		name = (String)entries.next();
		type = (Class)props.get(name);
		value = jsonObject.get(name);
		if (javaPropertyFilter != null && javaPropertyFilter.apply(bean, name, value))
			continue; /* Loop/switch isn't completed */
		key = !java/util/Map.isAssignableFrom(beanClass) || !jsonConfig.isSkipJavaIdentifierTransformationInMapKeys() ? JSONUtils.convertToJavaIdentifier(name, jsonConfig) : name;
		PropertyNameProcessor propertyNameProcessor = jsonConfig.findJavaPropertyNameProcessor(beanClass);
		if (propertyNameProcessor != null)
			key = propertyNameProcessor.processPropertyName(beanClass, key);
		if (java/util/Map.isAssignableFrom(beanClass))
		{
			if (JSONUtils.isNull(value))
				setProperty(bean, key, value, jsonConfig);
			else
			if (value instanceof JSONArray)
				setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, java/util/List), jsonConfig);
			else
			if (java/lang/String.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value))
					setProperty(bean, key, null, jsonConfig);
				else
					setProperty(bean, key, value, jsonConfig);
			} else
			{
				Class targetClass = findTargetClass(key, classMap);
				targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
				JsonConfig jsc = jsonConfig.copy();
				jsc.setRootClass(targetClass);
				jsc.setClassMap(classMap);
				if (targetClass != null)
					setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig);
				else
					setProperty(bean, key, toBean((JSONObject)value), jsonConfig);
			}
			continue; /* Loop/switch isn't completed */
		}
		PropertyDescriptor pd = PropertyUtils.getPropertyDescriptor(bean, key);
		if (pd != null && pd.getWriteMethod() == null)
		{
			log.info((new StringBuilder()).append("Property '").append(key).append("' of ").append(bean.getClass()).append(" has no write method. SKIPPED.").toString());
			continue; /* Loop/switch isn't completed */
		}
		try
		{
			if (pd != null)
			{
				Class targetType = pd.getPropertyType();
				if (!JSONUtils.isNull(value))
				{
					if (value instanceof JSONArray)
					{
						if (java/util/List.isAssignableFrom(pd.getPropertyType()))
							setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, pd.getPropertyType()), jsonConfig);
						else
						if (java/util/Set.isAssignableFrom(pd.getPropertyType()))
							setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, pd.getPropertyType()), jsonConfig);
						else
							setProperty(bean, key, convertPropertyValueToArray(key, value, targetType, jsonConfig, classMap), jsonConfig);
					} else
					if (java/lang/String.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
					{
						if (pd != null)
						{
							if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value))
								setProperty(bean, key, null, jsonConfig);
							else
							if (!targetType.isInstance(value))
								setProperty(bean, key, morphPropertyValue(key, value, type, targetType), jsonConfig);
							else
								setProperty(bean, key, value, jsonConfig);
						} else
						if (beanClass == null || (bean instanceof Map))
							setProperty(bean, key, value, jsonConfig);
						else
							log.warn((new StringBuilder()).append("Tried to assign property ").append(key).append(":").append(type.getName()).append(" to bean of class ").append(bean.getClass().getName()).toString());
					} else
					if (jsonConfig.isHandleJettisonSingleElementArray())
					{
						JSONArray array = (new JSONArray()).element(value, jsonConfig);
						Class newTargetClass = findTargetClass(key, classMap);
						newTargetClass = newTargetClass != null ? newTargetClass : findTargetClass(name, classMap);
						JsonConfig jsc = jsonConfig.copy();
						jsc.setRootClass(newTargetClass);
						jsc.setClassMap(classMap);
						if (targetType.isArray())
							setProperty(bean, key, JSONArray.toArray(array, jsc), jsonConfig);
						else
						if (net/sf/json/JSONArray.isAssignableFrom(targetType))
							setProperty(bean, key, array, jsonConfig);
						else
						if (java/util/List.isAssignableFrom(targetType) || java/util/Set.isAssignableFrom(targetType))
						{
							jsc.setCollectionType(targetType);
							setProperty(bean, key, JSONArray.toCollection(array, jsc), jsonConfig);
						} else
						{
							setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig);
						}
					} else
					{
						if (targetType == java/lang/Object || targetType.isInterface())
						{
							Class targetTypeCopy = targetType;
							targetType = findTargetClass(key, classMap);
							targetType = targetType != null ? targetType : findTargetClass(name, classMap);
							targetType = targetType != null || !targetTypeCopy.isInterface() ? targetType : targetTypeCopy;
						}
						JsonConfig jsc = jsonConfig.copy();
						jsc.setRootClass(targetType);
						jsc.setClassMap(classMap);
						setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig);
					}
				} else
				if (type.isPrimitive())
				{
					log.warn((new StringBuilder()).append("Tried to assign null value to ").append(key).append(":").append(type.getName()).toString());
					setProperty(bean, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
				} else
				{
					setProperty(bean, key, null, jsonConfig);
				}
			} else
			if (!JSONUtils.isNull(value))
			{
				if (value instanceof JSONArray)
					setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, java/util/List), jsonConfig);
				else
				if (java/lang/String.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
				{
					if (beanClass == null || (bean instanceof Map) || jsonConfig.getPropertySetStrategy() != null || !jsonConfig.isIgnorePublicFields())
						setProperty(bean, key, value, jsonConfig);
					else
						log.warn((new StringBuilder()).append("Tried to assign property ").append(key).append(":").append(type.getName()).append(" to bean of class ").append(bean.getClass().getName()).toString());
				} else
				if (jsonConfig.isHandleJettisonSingleElementArray())
				{
					Class newTargetClass = findTargetClass(key, classMap);
					newTargetClass = newTargetClass != null ? newTargetClass : findTargetClass(name, classMap);
					JsonConfig jsc = jsonConfig.copy();
					jsc.setRootClass(newTargetClass);
					jsc.setClassMap(classMap);
					setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig);
				} else
				{
					setProperty(bean, key, value, jsonConfig);
				}
			} else
			if (type.isPrimitive())
			{
				log.warn((new StringBuilder()).append("Tried to assign null value to ").append(key).append(":").append(type.getName()).toString());
				setProperty(bean, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
			} else
			{
				setProperty(bean, key, null, jsonConfig);
			}
		}
		catch (JSONException jsone)
		{
			throw jsone;
		}
		catch (Exception e)
		{
			throw new JSONException((new StringBuilder()).append("Error while setting property=").append(name).append(" type ").append(type).toString(), e);
		}
		if (true) goto _L2; else goto _L1
_L1:
		return bean;
	}

	public static Object toBean(JSONObject jsonObject, Object root, JsonConfig jsonConfig)
	{
		Class rootClass;
		Map classMap;
		Map props;
		PropertyFilter javaPropertyFilter;
		Iterator entries;
		if (jsonObject == null || jsonObject.isNullObject() || root == null)
			return root;
		rootClass = root.getClass();
		if (rootClass.isInterface())
			throw new JSONException((new StringBuilder()).append("Root bean is an interface. ").append(rootClass).toString());
		classMap = jsonConfig.getClassMap();
		if (classMap == null)
			classMap = Collections.EMPTY_MAP;
		props = JSONUtils.getProperties(jsonObject);
		javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
		entries = jsonObject.names(jsonConfig).iterator();
_L2:
		String name;
		Class type;
		Object value;
		String key;
		if (!entries.hasNext())
			break; /* Loop/switch isn't completed */
		name = (String)entries.next();
		type = (Class)props.get(name);
		value = jsonObject.get(name);
		if (javaPropertyFilter != null && javaPropertyFilter.apply(root, name, value))
			continue; /* Loop/switch isn't completed */
		key = JSONUtils.convertToJavaIdentifier(name, jsonConfig);
		PropertyDescriptor pd = PropertyUtils.getPropertyDescriptor(root, key);
		if (pd != null && pd.getWriteMethod() == null)
		{
			log.info((new StringBuilder()).append("Property '").append(key).append("' of ").append(root.getClass()).append(" has no write method. SKIPPED.").toString());
			continue; /* Loop/switch isn't completed */
		}
		try
		{
			if (!JSONUtils.isNull(value))
			{
				if (value instanceof JSONArray)
				{
					if (pd == null || java/util/List.isAssignableFrom(pd.getPropertyType()))
					{
						Class targetClass = findTargetClass(key, classMap);
						targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
						Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, null);
						List list = JSONArray.toList((JSONArray)value, newRoot, jsonConfig);
						setProperty(root, key, list, jsonConfig);
					} else
					{
						Class innerType = JSONUtils.getInnerComponentType(pd.getPropertyType());
						Class targetInnerType = findTargetClass(key, classMap);
						if (innerType.equals(java/lang/Object) && targetInnerType != null && !targetInnerType.equals(java/lang/Object))
							innerType = targetInnerType;
						Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(innerType, null);
						Object array = JSONArray.toArray((JSONArray)value, newRoot, jsonConfig);
						if (innerType.isPrimitive() || JSONUtils.isNumber(innerType) || java/lang/Boolean.isAssignableFrom(innerType) || JSONUtils.isString(innerType))
							array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
						else
						if (!array.getClass().equals(pd.getPropertyType()) && !pd.getPropertyType().equals(java/lang/Object))
						{
							net.sf.ezmorph.Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(innerType, 0).getClass());
							if (IdentityObjectMorpher.getInstance().equals(morpher))
							{
								ObjectArrayMorpher beanMorpher = new ObjectArrayMorpher(new BeanMorpher(innerType, JSONUtils.getMorpherRegistry()));
								JSONUtils.getMorpherRegistry().registerMorpher(beanMorpher);
							}
							array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
						}
						setProperty(root, key, array, jsonConfig);
					}
				} else
				if (java/lang/String.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
				{
					if (pd != null)
					{
						if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value))
							setProperty(root, key, null, jsonConfig);
						else
						if (!pd.getPropertyType().isInstance(value))
						{
							net.sf.ezmorph.Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(pd.getPropertyType());
							if (IdentityObjectMorpher.getInstance().equals(morpher))
							{
								log.warn((new StringBuilder()).append("Can't transform property '").append(key).append("' from ").append(type.getName()).append(" into ").append(pd.getPropertyType().getName()).append(". Will register a default BeanMorpher").toString());
								JSONUtils.getMorpherRegistry().registerMorpher(new BeanMorpher(pd.getPropertyType(), JSONUtils.getMorpherRegistry()));
							}
							setProperty(root, key, JSONUtils.getMorpherRegistry().morph(pd.getPropertyType(), value), jsonConfig);
						} else
						{
							setProperty(root, key, value, jsonConfig);
						}
					} else
					if (root instanceof Map)
						setProperty(root, key, value, jsonConfig);
					else
						log.warn((new StringBuilder()).append("Tried to assign property ").append(key).append(":").append(type.getName()).append(" to bean of class ").append(root.getClass().getName()).toString());
				} else
				if (pd != null)
				{
					Class targetClass = pd.getPropertyType();
					if (jsonConfig.isHandleJettisonSingleElementArray())
					{
						JSONArray array = (new JSONArray()).element(value, jsonConfig);
						Class newTargetClass = findTargetClass(key, classMap);
						newTargetClass = newTargetClass != null ? newTargetClass : findTargetClass(name, classMap);
						Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(newTargetClass, null);
						if (targetClass.isArray())
							setProperty(root, key, JSONArray.toArray(array, newRoot, jsonConfig), jsonConfig);
						else
						if (java/util/Collection.isAssignableFrom(targetClass))
							setProperty(root, key, JSONArray.toList(array, newRoot, jsonConfig), jsonConfig);
						else
						if (net/sf/json/JSONArray.isAssignableFrom(targetClass))
							setProperty(root, key, array, jsonConfig);
						else
							setProperty(root, key, toBean((JSONObject)value, newRoot, jsonConfig), jsonConfig);
					} else
					{
						if (targetClass == java/lang/Object)
						{
							targetClass = findTargetClass(key, classMap);
							targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
						}
						Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, null);
						setProperty(root, key, toBean((JSONObject)value, newRoot, jsonConfig), jsonConfig);
					}
				} else
				if (root instanceof Map)
				{
					Class targetClass = findTargetClass(key, classMap);
					targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
					Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, null);
					setProperty(root, key, toBean((JSONObject)value, newRoot, jsonConfig), jsonConfig);
				} else
				{
					log.warn((new StringBuilder()).append("Tried to assign property ").append(key).append(":").append(type.getName()).append(" to bean of class ").append(rootClass.getName()).toString());
				}
			} else
			if (type.isPrimitive())
			{
				log.warn((new StringBuilder()).append("Tried to assign null value to ").append(key).append(":").append(type.getName()).toString());
				setProperty(root, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
			} else
			{
				setProperty(root, key, null, jsonConfig);
			}
		}
		catch (JSONException jsone)
		{
			throw jsone;
		}
		catch (Exception e)
		{
			throw new JSONException((new StringBuilder()).append("Error while setting property=").append(name).append(" type ").append(type).toString(), e);
		}
		if (true) goto _L2; else goto _L1
_L1:
		return root;
	}

	private static JSONObject _fromBean(Object bean, JsonConfig jsonConfig)
	{
		if (addInstance(bean))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(bean);
		JSONException jsone;
		jsone;
		removeInstance(bean);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(bean);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireObjectStartEvent(jsonConfig);
		JsonBeanProcessor processor = jsonConfig.findJsonBeanProcessor(bean.getClass());
		if (processor != null)
		{
			JSONObject json = null;
			try
			{
				json = processor.processBean(bean, jsonConfig);
				if (json == null)
				{
					json = (JSONObject)jsonConfig.findDefaultValueProcessor(bean.getClass()).getDefaultValue(bean.getClass());
					if (json == null)
						json = new JSONObject(true);
				}
				removeInstance(bean);
				fireObjectEndEvent(jsonConfig);
			}
			catch (JSONException jsone)
			{
				removeInstance(bean);
				fireErrorEvent(jsone, jsonConfig);
				throw jsone;
			}
			catch (RuntimeException e)
			{
				removeInstance(bean);
				JSONException jsone = new JSONException(e);
				fireErrorEvent(jsone, jsonConfig);
				throw jsone;
			}
			return json;
		}
		Class beanClass = bean.getClass();
		PropertyNameProcessor propertyNameProcessor = jsonConfig.findJsonPropertyNameProcessor(beanClass);
		Collection exclusions = jsonConfig.getMergedExcludes(beanClass);
		JSONObject jsonObject = new JSONObject();
		try
		{
			PropertyDescriptor pds[] = PropertyUtils.getPropertyDescriptors(bean);
			PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
			for (int i = 0; i < pds.length; i++)
			{
				boolean bypass = false;
				String key = pds[i].getName();
				if (exclusions.contains(key) || jsonConfig.isIgnoreTransientFields() && isTransientField(key, beanClass, jsonConfig))
					continue;
				Class type = pds[i].getPropertyType();
				try
				{
					pds[i].getReadMethod();
				}
				catch (Exception e)
				{
					String warning = (new StringBuilder()).append("Property '").append(key).append("' of ").append(beanClass).append(" has no read method. SKIPPED").toString();
					fireWarnEvent(warning, jsonConfig);
					log.info(warning);
					continue;
				}
				if (pds[i].getReadMethod() != null)
				{
					if (isTransient(pds[i].getReadMethod(), jsonConfig))
						continue;
					Object value = PropertyUtils.getProperty(bean, key);
					if (jsonPropertyFilter != null && jsonPropertyFilter.apply(bean, key, value))
						continue;
					JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(beanClass, type, key);
					if (jsonValueProcessor != null)
					{
						value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
						bypass = true;
						if (!JsonVerifier.isValidJsonValue(value))
							throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
					}
					if (propertyNameProcessor != null)
						key = propertyNameProcessor.processPropertyName(beanClass, key);
					setValue(jsonObject, key, value, type, jsonConfig, bypass);
				} else
				{
					String warning = (new StringBuilder()).append("Property '").append(key).append("' of ").append(beanClass).append(" has no read method. SKIPPED").toString();
					fireWarnEvent(warning, jsonConfig);
					log.info(warning);
				}
			}

			try
			{
				if (!jsonConfig.isIgnorePublicFields())
				{
					Field fields[] = beanClass.getFields();
					for (int i = 0; i < fields.length; i++)
					{
						boolean bypass = false;
						Field field = fields[i];
						String key = field.getName();
						if (!exclusions.contains(key) && (!jsonConfig.isIgnoreTransientFields() || !isTransient(field, jsonConfig)))
						{
							Class type = field.getType();
							Object value = field.get(bean);
							if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(bean, key, value))
							{
								JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(beanClass, type, key);
								if (jsonValueProcessor != null)
								{
									value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
									bypass = true;
									if (!JsonVerifier.isValidJsonValue(value))
										throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
								}
								if (propertyNameProcessor != null)
									key = propertyNameProcessor.processPropertyName(beanClass, key);
								setValue(jsonObject, key, value, type, jsonConfig, bypass);
							}
						}
					}

				}
			}
			catch (Exception e)
			{
				log.trace("Couldn't read public fields.", e);
			}
		}
		catch (JSONException jsone)
		{
			removeInstance(bean);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		catch (Exception e)
		{
			removeInstance(bean);
			JSONException jsone = new JSONException(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(bean);
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
	}

	private static JSONObject _fromDynaBean(DynaBean bean, JsonConfig jsonConfig)
	{
		if (bean == null)
		{
			fireObjectStartEvent(jsonConfig);
			fireObjectEndEvent(jsonConfig);
			return new JSONObject(true);
		}
		if (addInstance(bean))
			break MISSING_BLOCK_LABEL_70;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(bean);
		JSONException jsone;
		jsone;
		removeInstance(bean);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(bean);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireObjectStartEvent(jsonConfig);
		JSONObject jsonObject = new JSONObject();
		try
		{
			DynaProperty props[] = bean.getDynaClass().getDynaProperties();
			Collection exclusions = jsonConfig.getMergedExcludes();
			PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
			for (int i = 0; i < props.length; i++)
			{
				boolean bypass = false;
				DynaProperty dynaProperty = props[i];
				String key = dynaProperty.getName();
				if (!exclusions.contains(key))
				{
					Class type = dynaProperty.getType();
					Object value = bean.get(dynaProperty.getName());
					if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(bean, key, value))
					{
						JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(type, key);
						if (jsonValueProcessor != null)
						{
							value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
							bypass = true;
							if (!JsonVerifier.isValidJsonValue(value))
								throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
						}
						setValue(jsonObject, key, value, type, jsonConfig, bypass);
					}
				}
			}

		}
		catch (JSONException jsone)
		{
			removeInstance(bean);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		catch (RuntimeException e)
		{
			removeInstance(bean);
			JSONException jsone = new JSONException(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(bean);
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
	}

	private static JSONObject _fromJSONObject(JSONObject object, JsonConfig jsonConfig)
	{
		if (object == null || object.isNullObject())
		{
			fireObjectStartEvent(jsonConfig);
			fireObjectEndEvent(jsonConfig);
			return new JSONObject(true);
		}
		if (addInstance(object))
			break MISSING_BLOCK_LABEL_77;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(object);
		JSONException jsone;
		jsone;
		removeInstance(object);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(object);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireObjectStartEvent(jsonConfig);
		JSONArray sa = object.names(jsonConfig);
		Collection exclusions = jsonConfig.getMergedExcludes();
		JSONObject jsonObject = new JSONObject();
		PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
		Iterator i = sa.iterator();
		do
		{
			if (!i.hasNext())
				break;
			Object k = i.next();
			if (k == null)
				throw new JSONException("JSON keys cannot be null.");
			if (!(k instanceof String) && !jsonConfig.isAllowNonStringKeys())
				throw new ClassCastException("JSON keys must be strings.");
			String key = String.valueOf(k);
			if ("null".equals(key))
				throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
			if (!exclusions.contains(key))
			{
				Object value = object.opt(key);
				if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(object, key, value))
					if (jsonObject.properties.containsKey(key))
					{
						jsonObject.accumulate(key, value, jsonConfig);
						firePropertySetEvent(key, value, true, jsonConfig);
					} else
					{
						jsonObject.setInternal(key, value, jsonConfig);
						firePropertySetEvent(key, value, false, jsonConfig);
					}
			}
		} while (true);
		removeInstance(object);
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
	}

	private static JSONObject _fromJSONString(JSONString string, JsonConfig jsonConfig)
	{
		return _fromJSONTokener(new JSONTokener(string.toJSONString()), jsonConfig);
	}

	private static JSONObject _fromJSONTokener(JSONTokener tokener, JsonConfig jsonConfig)
	{
		if (!tokener.matches("null.*"))
			break MISSING_BLOCK_LABEL_26;
		fireObjectStartEvent(jsonConfig);
		fireObjectEndEvent(jsonConfig);
		return new JSONObject(true);
		Collection exclusions;
		PropertyFilter jsonPropertyFilter;
		JSONObject jsonObject;
		if (tokener.nextClean() != '{')
			throw tokener.syntaxError("A JSONObject text must begin with '{'");
		fireObjectStartEvent(jsonConfig);
		exclusions = jsonConfig.getMergedExcludes();
		jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
		jsonObject = new JSONObject();
_L13:
		char c = tokener.nextClean();
		c;
		JVM INSTR lookupswitch 2: default 114
	//	               0: 100
	//	               125: 107;
		   goto _L1 _L2 _L3
_L2:
		throw tokener.syntaxError("A JSONObject text must end with '}'");
_L3:
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
_L1:
		String key;
		boolean quoted;
		Object v;
		tokener.back();
		key = tokener.nextValue(jsonConfig).toString();
		c = tokener.nextClean();
		if (c == '=')
		{
			if (tokener.next() != '>')
				tokener.back();
		} else
		if (c != ':')
			throw tokener.syntaxError("Expected a ':' after a key");
		char peek = tokener.peek();
		quoted = peek == '"' || peek == '\'';
		v = tokener.nextValue(jsonConfig);
		if (!quoted && JSONUtils.isFunctionHeader(v)) goto _L5; else goto _L4
_L4:
		if (!exclusions.contains(key)) goto _L7; else goto _L6
_L6:
		tokener.nextClean();
		JVM INSTR lookupswitch 3: default 294
	//	               44: 264
	//	               59: 264
	//	               125: 287;
		   goto _L8 _L9 _L9 _L10
_L9:
		if (tokener.nextClean() != '}') goto _L12; else goto _L11
_L11:
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
_L12:
		tokener.back();
		  goto _L13
_L10:
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
_L8:
		throw tokener.syntaxError("Expected a ',' or '}'");
_L7:
		if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(tokener, key, v))
		{
			if (quoted && (v instanceof String) && (JSONUtils.mayBeJSON((String)v) || JSONUtils.isFunction(v)))
				v = (new StringBuilder()).append("\"").append(v).append("\"").toString();
			if (jsonObject.properties.containsKey(key))
			{
				jsonObject.accumulate(key, v, jsonConfig);
				firePropertySetEvent(key, v, true, jsonConfig);
			} else
			{
				jsonObject.element(key, v, jsonConfig);
				firePropertySetEvent(key, v, false, jsonConfig);
			}
		}
		  goto _L14
_L5:
		String params = JSONUtils.getFunctionParams((String)v);
		int i = 0;
		StringBuffer sb = new StringBuffer();
		do
		{
			char ch = tokener.next();
			if (ch == 0)
				break;
			if (ch == '{')
				i++;
			if (ch == '}')
				i--;
			sb.append(ch);
		} while (i != 0);
		if (i != 0)
			throw tokener.syntaxError((new StringBuilder()).append("Unbalanced '{' or '}' on prop: ").append(v).toString());
		String text = sb.toString();
		text = text.substring(1, text.length() - 1).trim();
		Object value = new JSONFunction(params == null ? null : StringUtils.split(params, ","), text);
		if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(tokener, key, value))
			if (jsonObject.properties.containsKey(key))
			{
				jsonObject.accumulate(key, value, jsonConfig);
				firePropertySetEvent(key, value, true, jsonConfig);
			} else
			{
				jsonObject.element(key, value, jsonConfig);
				firePropertySetEvent(key, value, false, jsonConfig);
			}
_L14:
		tokener.nextClean();
		JVM INSTR lookupswitch 3: default 734
	//	               44: 704
	//	               59: 704
	//	               125: 727;
		   goto _L15 _L16 _L16 _L17
_L16:
		if (tokener.nextClean() != '}') goto _L19; else goto _L18
_L18:
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
_L19:
		tokener.back();
		  goto _L13
_L17:
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
_L15:
		try
		{
			throw tokener.syntaxError("Expected a ',' or '}'");
		}
		catch (JSONException jsone)
		{
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
	}

	private static JSONObject _fromMap(Map map, JsonConfig jsonConfig)
	{
		if (map == null)
		{
			fireObjectStartEvent(jsonConfig);
			fireObjectEndEvent(jsonConfig);
			return new JSONObject(true);
		}
		if (addInstance(map))
			break MISSING_BLOCK_LABEL_70;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(map);
		JSONException jsone;
		jsone;
		removeInstance(map);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(map);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireObjectStartEvent(jsonConfig);
		Collection exclusions = jsonConfig.getMergedExcludes();
		JSONObject jsonObject = new JSONObject();
		PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
		try
		{
			Iterator entries = map.entrySet().iterator();
			do
			{
				if (!entries.hasNext())
					break;
				boolean bypass = false;
				java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
				Object k = entry.getKey();
				if (k == null)
					throw new JSONException("JSON keys cannot be null.");
				if (!(k instanceof String) && !jsonConfig.isAllowNonStringKeys())
					throw new ClassCastException("JSON keys must be strings.");
				String key = String.valueOf(k);
				if ("null".equals(key))
					throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
				if (!exclusions.contains(key))
				{
					Object value = entry.getValue();
					if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(map, key, value))
						if (value != null)
						{
							JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(value.getClass(), key);
							if (jsonValueProcessor != null)
							{
								value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
								bypass = true;
								if (!JsonVerifier.isValidJsonValue(value))
									throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
							}
							setValue(jsonObject, key, value, value.getClass(), jsonConfig, bypass);
						} else
						if (jsonObject.properties.containsKey(key))
						{
							jsonObject.accumulate(key, JSONNull.getInstance());
							firePropertySetEvent(key, JSONNull.getInstance(), true, jsonConfig);
						} else
						{
							jsonObject.element(key, JSONNull.getInstance());
							firePropertySetEvent(key, JSONNull.getInstance(), false, jsonConfig);
						}
				}
			} while (true);
		}
		catch (JSONException jsone)
		{
			removeInstance(map);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		catch (RuntimeException e)
		{
			removeInstance(map);
			JSONException jsone = new JSONException(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(map);
		fireObjectEndEvent(jsonConfig);
		return jsonObject;
	}

	private static JSONObject _fromString(String str, JsonConfig jsonConfig)
	{
		if (str == null || "null".equals(str))
		{
			fireObjectStartEvent(jsonConfig);
			fireObjectEndEvent(jsonConfig);
			return new JSONObject(true);
		} else
		{
			return _fromJSONTokener(new JSONTokener(str), jsonConfig);
		}
	}

	private static Object convertPropertyValueToArray(String key, Object value, Class targetType, JsonConfig jsonConfig, Map classMap)
	{
		Class innerType = JSONUtils.getInnerComponentType(targetType);
		Class targetInnerType = findTargetClass(key, classMap);
		if (innerType.equals(java/lang/Object) && targetInnerType != null && !targetInnerType.equals(java/lang/Object))
			innerType = targetInnerType;
		JsonConfig jsc = jsonConfig.copy();
		jsc.setRootClass(innerType);
		jsc.setClassMap(classMap);
		Object array = JSONArray.toArray((JSONArray)value, jsc);
		if (innerType.isPrimitive() || JSONUtils.isNumber(innerType) || java/lang/Boolean.isAssignableFrom(innerType) || JSONUtils.isString(innerType))
			array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
		else
		if (!array.getClass().equals(targetType) && !targetType.equals(java/lang/Object))
		{
			net.sf.ezmorph.Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(innerType, 0).getClass());
			if (IdentityObjectMorpher.getInstance().equals(morpher))
			{
				ObjectArrayMorpher beanMorpher = new ObjectArrayMorpher(new BeanMorpher(innerType, JSONUtils.getMorpherRegistry()));
				JSONUtils.getMorpherRegistry().registerMorpher(beanMorpher);
			}
			array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
		}
		return array;
	}

	private static List convertPropertyValueToList(String key, Object value, JsonConfig jsonConfig, String name, Map classMap)
	{
		Class targetClass = findTargetClass(key, classMap);
		targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
		JsonConfig jsc = jsonConfig.copy();
		jsc.setRootClass(targetClass);
		jsc.setClassMap(classMap);
		List list = (List)JSONArray.toCollection((JSONArray)value, jsc);
		return list;
	}

	private static Collection convertPropertyValueToCollection(String key, Object value, JsonConfig jsonConfig, String name, Map classMap, Class collectionType)
	{
		Class targetClass = findTargetClass(key, classMap);
		targetClass = targetClass != null ? targetClass : findTargetClass(name, classMap);
		JsonConfig jsc = jsonConfig.copy();
		jsc.setRootClass(targetClass);
		jsc.setClassMap(classMap);
		jsc.setCollectionType(collectionType);
		return JSONArray.toCollection((JSONArray)value, jsc);
	}

	private static Class findTargetClass(String key, Map classMap)
	{
		Class targetClass;
label0:
		{
			targetClass = (Class)classMap.get(key);
			if (targetClass != null)
				break label0;
			Iterator i = classMap.entrySet().iterator();
			java.util.Map.Entry entry;
			do
			{
				if (!i.hasNext())
					break label0;
				entry = (java.util.Map.Entry)i.next();
			} while (!RegexpUtils.getMatcher((String)entry.getKey()).matches(key));
			targetClass = (Class)entry.getValue();
		}
		return targetClass;
	}

	private static boolean isTransientField(String name, Class beanClass, JsonConfig jsonConfig)
	{
		Field field = beanClass.getDeclaredField(name);
		if ((field.getModifiers() & 0x80) == 128)
			return true;
		return isTransient(field, jsonConfig);
		Exception e;
		e;
		log.info((new StringBuilder()).append("Error while inspecting field ").append(beanClass).append(".").append(name).append(" for transient status.").toString(), e);
		return false;
	}

	private static boolean isTransient(AnnotatedElement element, JsonConfig jsonConfig)
	{
		Iterator annotations = jsonConfig.getIgnoreFieldAnnotations().iterator();
_L2:
		if (!annotations.hasNext())
			break; /* Loop/switch isn't completed */
		String annotationClassName = (String)annotations.next();
		if (element.getAnnotation(Class.forName(annotationClassName)) != null)
			return true;
		continue; /* Loop/switch isn't completed */
		Exception e;
		e;
		log.info((new StringBuilder()).append("Error while inspecting ").append(element).append(" for transient status.").toString(), e);
		if (true) goto _L2; else goto _L1
_L1:
		return false;
	}

	private static Object morphPropertyValue(String key, Object value, Class type, Class targetType)
	{
		net.sf.ezmorph.Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(targetType);
		if (IdentityObjectMorpher.getInstance().equals(morpher))
		{
			log.warn((new StringBuilder()).append("Can't transform property '").append(key).append("' from ").append(type.getName()).append(" into ").append(targetType.getName()).append(". Will register a default Morpher").toString());
			if (java/lang/Enum.isAssignableFrom(targetType))
				JSONUtils.getMorpherRegistry().registerMorpher(new EnumMorpher(targetType));
			else
				JSONUtils.getMorpherRegistry().registerMorpher(new BeanMorpher(targetType, JSONUtils.getMorpherRegistry()));
		}
		value = JSONUtils.getMorpherRegistry().morph(targetType, value);
		return value;
	}

	private static void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig)
		throws Exception
	{
		PropertySetStrategy propertySetStrategy = jsonConfig.getPropertySetStrategy() == null ? PropertySetStrategy.DEFAULT : jsonConfig.getPropertySetStrategy();
		propertySetStrategy.setProperty(bean, key, value, jsonConfig);
	}

	private static void setValue(JSONObject jsonObject, String key, Object value, Class type, JsonConfig jsonConfig, boolean bypass)
	{
		boolean accumulated = false;
		if (value == null)
		{
			value = jsonConfig.findDefaultValueProcessor(type).getDefaultValue(type);
			if (!JsonVerifier.isValidJsonValue(value))
				throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
		}
		if (jsonObject.properties.containsKey(key))
		{
			if (java/lang/String.isAssignableFrom(type))
			{
				Object o = jsonObject.opt(key);
				if (o instanceof JSONArray)
					((JSONArray)o).addString((String)value);
				else
					jsonObject.properties.put(key, (new JSONArray()).element(o).addString((String)value));
			} else
			{
				jsonObject.accumulate(key, value, jsonConfig);
			}
			accumulated = true;
		} else
		if (bypass || java/lang/String.isAssignableFrom(type))
			jsonObject.properties.put(key, value);
		else
			jsonObject.setInternal(key, value, jsonConfig);
		value = jsonObject.opt(key);
		if (accumulated)
		{
			JSONArray array = (JSONArray)value;
			value = array.get(array.size() - 1);
		}
		firePropertySetEvent(key, value, accumulated, jsonConfig);
	}

	public JSONObject()
	{
		properties = new ListOrderedMap();
	}

	public JSONObject(boolean isNull)
	{
		this();
		nullObject = isNull;
	}

	public JSONObject accumulate(String key, boolean value)
	{
		return _accumulate(key, value ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE)), new JsonConfig());
	}

	public JSONObject accumulate(String key, double value)
	{
		return _accumulate(key, Double.valueOf(value), new JsonConfig());
	}

	public JSONObject accumulate(String key, int value)
	{
		return _accumulate(key, Integer.valueOf(value), new JsonConfig());
	}

	public JSONObject accumulate(String key, long value)
	{
		return _accumulate(key, Long.valueOf(value), new JsonConfig());
	}

	public JSONObject accumulate(String key, Object value)
	{
		return _accumulate(key, value, new JsonConfig());
	}

	public JSONObject accumulate(String key, Object value, JsonConfig jsonConfig)
	{
		return _accumulate(key, value, jsonConfig);
	}

	public void accumulateAll(Map map)
	{
		accumulateAll(map, new JsonConfig());
	}

	public void accumulateAll(Map map, JsonConfig jsonConfig)
	{
		if (map instanceof JSONObject)
		{
			String key;
			Object value;
			for (Iterator entries = map.entrySet().iterator(); entries.hasNext(); accumulate(key, value, jsonConfig))
			{
				java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
				key = (String)entry.getKey();
				value = entry.getValue();
			}

		} else
		{
			String key;
			Object value;
			for (Iterator entries = map.entrySet().iterator(); entries.hasNext(); accumulate(key, value, jsonConfig))
			{
				java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
				key = String.valueOf(entry.getKey());
				value = entry.getValue();
			}

		}
	}

	public void clear()
	{
		properties.clear();
	}

	public int compareTo(Object obj)
	{
		if (obj != null && (obj instanceof JSONObject))
		{
			JSONObject other = (JSONObject)obj;
			int size1 = size();
			int size2 = other.size();
			if (size1 < size2)
				return -1;
			if (size1 > size2)
				return 1;
			if (equals(other))
				return 0;
		}
		return -1;
	}

	public boolean containsKey(Object key)
	{
		return properties.containsKey(key);
	}

	public boolean containsValue(Object value)
	{
		return containsValue(value, new JsonConfig());
	}

	public boolean containsValue(Object value, JsonConfig jsonConfig)
	{
		try
		{
			value = processValue(value, jsonConfig);
		}
		catch (JSONException e)
		{
			return false;
		}
		return properties.containsValue(value);
	}

	public JSONObject discard(String key)
	{
		verifyIsNull();
		properties.remove(key);
		return this;
	}

	public JSONObject element(String key, boolean value)
	{
		verifyIsNull();
		return element(key, value ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE)));
	}

	public JSONObject element(String key, Collection value)
	{
		return element(key, value, new JsonConfig());
	}

	public JSONObject element(String key, Collection value, JsonConfig jsonConfig)
	{
		if (!(value instanceof JSONArray))
			value = JSONArray.fromObject(value, jsonConfig);
		return setInternal(key, value, jsonConfig);
	}

	public JSONObject element(String key, double value)
	{
		verifyIsNull();
		Double d = new Double(value);
		JSONUtils.testValidity(d);
		return element(key, d);
	}

	public JSONObject element(String key, int value)
	{
		verifyIsNull();
		return element(key, new Integer(value));
	}

	public JSONObject element(String key, long value)
	{
		verifyIsNull();
		return element(key, new Long(value));
	}

	public JSONObject element(String key, Map value)
	{
		return element(key, value, new JsonConfig());
	}

	public JSONObject element(String key, Map value, JsonConfig jsonConfig)
	{
		verifyIsNull();
		if (value instanceof JSONObject)
			return setInternal(key, value, jsonConfig);
		else
			return element(key, ((Map) (fromObject(value, jsonConfig))), jsonConfig);
	}

	public JSONObject element(String key, Object value)
	{
		return element(key, value, new JsonConfig());
	}

	public JSONObject element(String key, Object value, JsonConfig jsonConfig)
	{
		verifyIsNull();
		if (key == null)
			throw new JSONException("Null key.");
		if (value != null)
		{
			value = processValue(key, value, jsonConfig);
			_setInternal(key, value, jsonConfig);
		} else
		{
			remove(key);
		}
		return this;
	}

	public JSONObject elementOpt(String key, Object value)
	{
		return elementOpt(key, value, new JsonConfig());
	}

	public JSONObject elementOpt(String key, Object value, JsonConfig jsonConfig)
	{
		verifyIsNull();
		if (key != null && value != null)
			element(key, value, jsonConfig);
		return this;
	}

	public Set entrySet()
	{
		return Collections.unmodifiableSet(properties.entrySet());
	}

	public boolean equals(Object obj)
	{
label0:
		{
			if (obj == this)
				return true;
			if (obj == null)
				return false;
			if (!(obj instanceof JSONObject))
				return false;
			JSONObject other = (JSONObject)obj;
			if (isNullObject())
				return other.isNullObject();
			if (other.isNullObject())
				return false;
			if (other.size() != size())
				return false;
			Iterator keys = properties.keySet().iterator();
			Object o1;
			Object o2;
label1:
			do
			{
				do
				{
					net.sf.ezmorph.Morpher m2;
					do
					{
						if (!keys.hasNext())
							break label0;
						String key = (String)keys.next();
						if (!other.properties.containsKey(key))
							return false;
						o1 = properties.get(key);
						o2 = other.properties.get(key);
						if (JSONNull.getInstance().equals(o1))
						{
							if (!JSONNull.getInstance().equals(o2))
								return false;
							continue;
						}
						if (JSONNull.getInstance().equals(o2))
							return false;
						if ((o1 instanceof String) && (o2 instanceof JSONFunction))
						{
							if (!o1.equals(String.valueOf(o2)))
								return false;
							continue;
						}
						if ((o1 instanceof JSONFunction) && (o2 instanceof String))
						{
							if (!o2.equals(String.valueOf(o1)))
								return false;
							continue;
						}
						if ((o1 instanceof JSONObject) && (o2 instanceof JSONObject))
						{
							if (!o1.equals(o2))
								return false;
							continue;
						}
						if ((o1 instanceof JSONArray) && (o2 instanceof JSONArray))
						{
							if (!o1.equals(o2))
								return false;
							continue;
						}
						if ((o1 instanceof JSONFunction) && (o2 instanceof JSONFunction))
						{
							if (!o1.equals(o2))
								return false;
							continue;
						}
						if (o1 instanceof String)
						{
							if (!o1.equals(String.valueOf(o2)))
								return false;
							continue;
						}
						if (o2 instanceof String)
						{
							if (!o2.equals(String.valueOf(o1)))
								return false;
							continue;
						}
						net.sf.ezmorph.Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
						m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
						if (m1 == null || m1 == IdentityObjectMorpher.getInstance())
							break;
						if (!o1.equals(JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2)))
							return false;
					} while (true);
					if (m2 == null || m2 == IdentityObjectMorpher.getInstance())
						continue label1;
				} while (JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1).equals(o2));
				return false;
			} while (o1.equals(o2));
			return false;
		}
		return true;
	}

	public Object get(Object key)
	{
		if (key instanceof String)
			return get((String)key);
		else
			return null;
	}

	public Object get(String key)
	{
		verifyIsNull();
		return properties.get(key);
	}

	public boolean getBoolean(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (o != null)
		{
			if (o.equals(Boolean.FALSE) || (o instanceof String) && ((String)o).equalsIgnoreCase("false"))
				return false;
			if (o.equals(Boolean.TRUE) || (o instanceof String) && ((String)o).equalsIgnoreCase("true"))
				return true;
		}
		throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a Boolean.").toString());
	}

	public double getDouble(String key)
	{
		Object o;
		verifyIsNull();
		o = get(key);
		if (o == null)
			break MISSING_BLOCK_LABEL_77;
		return (o instanceof Number) ? ((Number)o).doubleValue() : Double.parseDouble((String)o);
		Exception e;
		e;
		throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a number.").toString());
		throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a number.").toString());
	}

	public int getInt(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (o != null)
			return (o instanceof Number) ? ((Number)o).intValue() : (int)getDouble(key);
		else
			throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a number.").toString());
	}

	public JSONArray getJSONArray(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (o != null && (o instanceof JSONArray))
			return (JSONArray)o;
		else
			throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a JSONArray.").toString());
	}

	public JSONObject getJSONObject(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (JSONNull.getInstance().equals(o))
			return new JSONObject(true);
		if (o instanceof JSONObject)
			return (JSONObject)o;
		else
			throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a JSONObject.").toString());
	}

	public long getLong(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (o != null)
			return (o instanceof Number) ? ((Number)o).longValue() : (long)getDouble(key);
		else
			throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] is not a number.").toString());
	}

	public String getString(String key)
	{
		verifyIsNull();
		Object o = get(key);
		if (o != null)
			return o.toString();
		else
			throw new JSONException((new StringBuilder()).append("JSONObject[").append(JSONUtils.quote(key)).append("] not found.").toString());
	}

	public boolean has(String key)
	{
		verifyIsNull();
		return properties.containsKey(key);
	}

	public int hashCode()
	{
		int hashcode = 19;
		if (isNullObject())
			return hashcode + JSONNull.getInstance().hashCode();
		for (Iterator entries = properties.entrySet().iterator(); entries.hasNext();)
		{
			java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
			Object key = entry.getKey();
			Object value = entry.getValue();
			hashcode += key.hashCode() + JSONUtils.hashCode(value);
		}

		return hashcode;
	}

	public boolean isArray()
	{
		return false;
	}

	public boolean isEmpty()
	{
		return properties.isEmpty();
	}

	public boolean isNullObject()
	{
		return nullObject;
	}

	public Iterator keys()
	{
		verifyIsNull();
		return keySet().iterator();
	}

	public Set keySet()
	{
		return Collections.unmodifiableSet(properties.keySet());
	}

	public JSONArray names()
	{
		verifyIsNull();
		JSONArray ja = new JSONArray();
		for (Iterator keys = keys(); keys.hasNext(); ja.element(keys.next()));
		return ja;
	}

	public JSONArray names(JsonConfig jsonConfig)
	{
		verifyIsNull();
		JSONArray ja = new JSONArray();
		for (Iterator keys = keys(); keys.hasNext(); ja.element(keys.next(), jsonConfig));
		return ja;
	}

	public Object opt(String key)
	{
		verifyIsNull();
		return key != null ? properties.get(key) : null;
	}

	public boolean optBoolean(String key)
	{
		verifyIsNull();
		return optBoolean(key, false);
	}

	public boolean optBoolean(String key, boolean defaultValue)
	{
		verifyIsNull();
		return getBoolean(key);
		Exception e;
		e;
		return defaultValue;
	}

	public double optDouble(String key)
	{
		verifyIsNull();
		return optDouble(key, (0.0D / 0.0D));
	}

	public double optDouble(String key, double defaultValue)
	{
		verifyIsNull();
		Object o = opt(key);
		return (o instanceof Number) ? ((Number)o).doubleValue() : (new Double((String)o)).doubleValue();
		Exception e;
		e;
		return defaultValue;
	}

	public int optInt(String key)
	{
		verifyIsNull();
		return optInt(key, 0);
	}

	public int optInt(String key, int defaultValue)
	{
		verifyIsNull();
		return getInt(key);
		Exception e;
		e;
		return defaultValue;
	}

	public JSONArray optJSONArray(String key)
	{
		verifyIsNull();
		Object o = opt(key);
		return (o instanceof JSONArray) ? (JSONArray)o : null;
	}

	public JSONObject optJSONObject(String key)
	{
		verifyIsNull();
		Object o = opt(key);
		return (o instanceof JSONObject) ? (JSONObject)o : null;
	}

	public long optLong(String key)
	{
		verifyIsNull();
		return optLong(key, 0L);
	}

	public long optLong(String key, long defaultValue)
	{
		verifyIsNull();
		return getLong(key);
		Exception e;
		e;
		return defaultValue;
	}

	public String optString(String key)
	{
		verifyIsNull();
		return optString(key, "");
	}

	public String optString(String key, String defaultValue)
	{
		verifyIsNull();
		Object o = opt(key);
		return o == null ? defaultValue : o.toString();
	}

	public Object put(Object key, Object value)
	{
		if (key == null)
		{
			throw new IllegalArgumentException("key is null.");
		} else
		{
			Object previous = properties.get(key);
			element(String.valueOf(key), value);
			return previous;
		}
	}

	public void putAll(Map map)
	{
		putAll(map, new JsonConfig());
	}

	public void putAll(Map map, JsonConfig jsonConfig)
	{
		if (map instanceof JSONObject)
		{
			String key;
			Object value;
			for (Iterator entries = map.entrySet().iterator(); entries.hasNext(); properties.put(key, value))
			{
				java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
				key = (String)entry.getKey();
				value = entry.getValue();
			}

		} else
		{
			String key;
			Object value;
			for (Iterator entries = map.entrySet().iterator(); entries.hasNext(); element(key, value, jsonConfig))
			{
				java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
				key = String.valueOf(entry.getKey());
				value = entry.getValue();
			}

		}
	}

	public Object remove(Object key)
	{
		return properties.remove(key);
	}

	public Object remove(String key)
	{
		verifyIsNull();
		return properties.remove(key);
	}

	public int size()
	{
		return properties.size();
	}

	public JSONArray toJSONArray(JSONArray names)
	{
		verifyIsNull();
		if (names == null || names.size() == 0)
			return null;
		JSONArray ja = new JSONArray();
		for (int i = 0; i < names.size(); i++)
			ja.element(opt(names.getString(i)));

		return ja;
	}

	public String toString()
	{
		if (isNullObject())
			return JSONNull.getInstance().toString();
		StringBuffer sb;
		Iterator keys = keys();
		sb = new StringBuffer("{");
		Object o;
		for (; keys.hasNext(); sb.append(JSONUtils.valueToString(properties.get(o))))
		{
			if (sb.length() > 1)
				sb.append(',');
			o = keys.next();
			sb.append(JSONUtils.quote(o.toString()));
			sb.append(':');
		}

		sb.append('}');
		return sb.toString();
		Exception e;
		e;
		return null;
	}

	public String toString(int indentFactor)
	{
		if (isNullObject())
			return JSONNull.getInstance().toString();
		if (indentFactor == 0)
			return toString();
		else
			return toString(indentFactor, 0);
	}

	public String toString(int indentFactor, int indent)
	{
		if (isNullObject())
			return JSONNull.getInstance().toString();
		int n = size();
		if (n == 0)
			return "{}";
		if (indentFactor == 0)
			return toString();
		Iterator keys = keys();
		StringBuffer sb = new StringBuffer("{");
		int newindent = indent + indentFactor;
		if (n == 1)
		{
			Object o = keys.next();
			sb.append(JSONUtils.quote(o.toString()));
			sb.append(": ");
			sb.append(JSONUtils.valueToString(properties.get(o), indentFactor, indent));
		} else
		{
			Object o;
			for (; keys.hasNext(); sb.append(JSONUtils.valueToString(properties.get(o), indentFactor, newindent)))
			{
				o = keys.next();
				if (sb.length() > 1)
					sb.append(",\n");
				else
					sb.append('\n');
				for (int i = 0; i < newindent; i++)
					sb.append(' ');

				sb.append(JSONUtils.quote(o.toString()));
				sb.append(": ");
			}

			if (sb.length() > 1)
			{
				sb.append('\n');
				for (int i = 0; i < indent; i++)
					sb.append(' ');

			}
			for (int i = 0; i < indent; i++)
				sb.insert(0, ' ');

		}
		sb.append('}');
		return sb.toString();
	}

	public Collection values()
	{
		return Collections.unmodifiableCollection(properties.values());
	}

	public Writer write(Writer writer)
	{
		if (!isNullObject())
			break MISSING_BLOCK_LABEL_19;
		writer.write(JSONNull.getInstance().toString());
		return writer;
		boolean b = false;
		Iterator keys = keys();
		writer.write(123);
		for (; keys.hasNext(); b = true)
		{
			if (b)
				writer.write(44);
			Object k = keys.next();
			writer.write(JSONUtils.quote(k.toString()));
			writer.write(58);
			Object v = properties.get(k);
			if (v instanceof JSONObject)
			{
				((JSONObject)v).write(writer);
				continue;
			}
			if (v instanceof JSONArray)
				((JSONArray)v).write(writer);
			else
				writer.write(JSONUtils.valueToString(v));
		}

		writer.write(125);
		return writer;
		IOException e;
		e;
		throw new JSONException(e);
	}

	private JSONObject _accumulate(String key, Object value, JsonConfig jsonConfig)
	{
		if (isNullObject())
			throw new JSONException("Can't accumulate on null object");
		if (!has(key))
		{
			setInternal(key, value, jsonConfig);
		} else
		{
			Object o = opt(key);
			if (o instanceof JSONArray)
				((JSONArray)o).element(value, jsonConfig);
			else
				setInternal(key, (new JSONArray()).element(o).element(value, jsonConfig), jsonConfig);
		}
		return this;
	}

	protected Object _processValue(Object value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONTokener)
			return _fromJSONTokener((JSONTokener)value, jsonConfig);
		if (value != null && java/lang/Enum.isAssignableFrom(value.getClass()))
			return ((Enum)value).name();
		else
			return super._processValue(value, jsonConfig);
	}

	private JSONObject _setInternal(String key, Object value, JsonConfig jsonConfig)
	{
		verifyIsNull();
		if (key == null)
			throw new JSONException("Null key.");
		if (JSONUtils.isString(value) && JSONUtils.mayBeJSON(String.valueOf(value)))
			properties.put(key, value);
		else
		if (CycleDetectionStrategy.IGNORE_PROPERTY_OBJ != value && CycleDetectionStrategy.IGNORE_PROPERTY_ARR != value)
			properties.put(key, value);
		return this;
	}

	private Object processValue(Object value, JsonConfig jsonConfig)
	{
		if (value != null)
		{
			JsonValueProcessor processor = jsonConfig.findJsonValueProcessor(value.getClass());
			if (processor != null)
			{
				value = processor.processObjectValue(null, value, jsonConfig);
				if (!JsonVerifier.isValidJsonValue(value))
					throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
			}
		}
		return _processValue(value, jsonConfig);
	}

	private Object processValue(String key, Object value, JsonConfig jsonConfig)
	{
		if (value != null)
		{
			JsonValueProcessor processor = jsonConfig.findJsonValueProcessor(value.getClass(), key);
			if (processor != null)
			{
				value = processor.processObjectValue(null, value, jsonConfig);
				if (!JsonVerifier.isValidJsonValue(value))
					throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
			}
		}
		return _processValue(value, jsonConfig);
	}

	private JSONObject setInternal(String key, Object value, JsonConfig jsonConfig)
	{
		return _setInternal(key, processValue(key, value, jsonConfig), jsonConfig);
	}

	private void verifyIsNull()
	{
		if (isNullObject())
			throw new JSONException("null object");
		else
			return;
	}

}
