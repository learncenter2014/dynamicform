// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONBuilder.java

package net.sf.json.util;

import java.io.IOException;
import java.io.Writer;
import net.sf.json.JSONException;

// Referenced classes of package net.sf.json.util:
//			JSONUtils

public class JSONBuilder
{

	private static final int MAXDEPTH = 20;
	private boolean comma;
	protected char mode;
	private char stack[];
	private int top;
	protected Writer writer;

	public JSONBuilder(Writer w)
	{
		comma = false;
		mode = 'i';
		stack = new char[20];
		top = 0;
		writer = w;
	}

	private JSONBuilder append(String s)
	{
		if (s == null)
			throw new JSONException("Null pointer");
		if (mode == 'o' || mode == 'a')
		{
			try
			{
				if (comma && mode == 'a')
					writer.write(44);
				writer.write(s);
			}
			catch (IOException e)
			{
				throw new JSONException(e);
			}
			if (mode == 'o')
				mode = 'k';
			comma = true;
			return this;
		} else
		{
			throw new JSONException("Value out of sequence.");
		}
	}

	public JSONBuilder array()
	{
		if (mode == 'i' || mode == 'o' || mode == 'a')
		{
			push('a');
			append("[");
			comma = false;
			return this;
		} else
		{
			throw new JSONException("Misplaced array.");
		}
	}

	private JSONBuilder end(char m, char c)
	{
		if (mode != m)
			throw new JSONException(m != 'o' ? "Misplaced endArray." : "Misplaced endObject.");
		pop(m);
		try
		{
			writer.write(c);
		}
		catch (IOException e)
		{
			throw new JSONException(e);
		}
		comma = true;
		return this;
	}

	public JSONBuilder endArray()
	{
		return end('a', ']');
	}

	public JSONBuilder endObject()
	{
		return end('k', '}');
	}

	public JSONBuilder key(String s)
	{
		if (s == null)
			throw new JSONException("Null key.");
		if (mode != 'k')
			break MISSING_BLOCK_LABEL_82;
		if (comma)
			writer.write(44);
		writer.write(JSONUtils.quote(s));
		writer.write(58);
		comma = false;
		mode = 'o';
		return this;
		IOException e;
		e;
		throw new JSONException(e);
		throw new JSONException("Misplaced key.");
	}

	public JSONBuilder object()
	{
		if (mode == 'i')
			mode = 'o';
		if (mode == 'o' || mode == 'a')
		{
			append("{");
			push('k');
			comma = false;
			return this;
		} else
		{
			throw new JSONException("Misplaced object.");
		}
	}

	private void pop(char c)
	{
		if (top <= 0 || stack[top - 1] != c)
		{
			throw new JSONException("Nesting error.");
		} else
		{
			top--;
			mode = top != 0 ? stack[top - 1] : 'd';
			return;
		}
	}

	private void push(char c)
	{
		if (top >= 20)
		{
			throw new JSONException("Nesting too deep.");
		} else
		{
			stack[top] = c;
			mode = c;
			top++;
			return;
		}
	}

	public JSONBuilder value(boolean b)
	{
		return append(b ? "true" : "false");
	}

	public JSONBuilder value(double d)
	{
		return value(new Double(d));
	}

	public JSONBuilder value(long l)
	{
		return append(Long.toString(l));
	}

	public JSONBuilder value(Object o)
	{
		return append(JSONUtils.valueToString(o));
	}
}
