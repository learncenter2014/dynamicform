// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EnumMorpher.java

package net.sf.json.util;

import net.sf.ezmorph.ObjectMorpher;

public class EnumMorpher
	implements ObjectMorpher
{

	private Class enumClass;

	public EnumMorpher(Class enumClass)
	{
		if (enumClass == null)
			throw new IllegalArgumentException("enumClass is null");
		if (!java/lang/Enum.isAssignableFrom(enumClass))
		{
			throw new IllegalArgumentException("enumClass is not an Enum class");
		} else
		{
			this.enumClass = enumClass;
			return;
		}
	}

	public Object morph(Object value)
	{
		if (value == null)
			return enumClass.cast(null);
		else
			return Enum.valueOf(enumClass, String.valueOf(value));
	}

	public Class morphsTo()
	{
		return enumClass;
	}

	public boolean supports(Class clazz)
	{
		return java/lang/String.isAssignableFrom(clazz);
	}
}
