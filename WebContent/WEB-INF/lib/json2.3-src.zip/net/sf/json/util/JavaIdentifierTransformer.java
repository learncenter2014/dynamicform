// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JavaIdentifierTransformer.java

package net.sf.json.util;

import net.sf.json.JSONException;
import org.apache.commons.lang.StringUtils;

public abstract class JavaIdentifierTransformer
{
	private static final class WhiteSpaceJavaIdentifierTransformer extends JavaIdentifierTransformer
	{

		public String transformToJavaIdentifier(String str)
		{
			if (str == null)
				return null;
			String str2 = shaveOffNonJavaIdentifierStartChars(str);
			str2 = StringUtils.deleteWhitespace(str2);
			char chars[] = str2.toCharArray();
			int pos = 0;
			StringBuffer buf = new StringBuffer();
			for (; pos < chars.length; pos++)
				if (Character.isJavaIdentifierPart(chars[pos]))
					buf.append(chars[pos]);

			return buf.toString();
		}

		private WhiteSpaceJavaIdentifierTransformer()
		{
		}

	}

	private static final class UnderscoreJavaIdentifierTransformer extends JavaIdentifierTransformer
	{

		public String transformToJavaIdentifier(String str)
		{
			if (str == null)
				return null;
			String str2 = shaveOffNonJavaIdentifierStartChars(str);
			char chars[] = str2.toCharArray();
			int pos = 0;
			StringBuffer buf = new StringBuffer();
			boolean toUnderScorePreviousChar = false;
			for (; pos < chars.length; pos++)
			{
				if (!Character.isJavaIdentifierPart(chars[pos]) || Character.isWhitespace(chars[pos]))
				{
					toUnderScorePreviousChar = true;
					continue;
				}
				if (toUnderScorePreviousChar)
				{
					buf.append("_");
					toUnderScorePreviousChar = false;
				}
				buf.append(chars[pos]);
			}

			if (buf.charAt(buf.length() - 1) == '_')
				buf.deleteCharAt(buf.length() - 1);
			return buf.toString();
		}

		private UnderscoreJavaIdentifierTransformer()
		{
		}

	}

	private static final class StrictJavaIdentifierTransformer extends JavaIdentifierTransformer
	{

		public String transformToJavaIdentifier(String str)
		{
			throw new JSONException("'" + str + "' is not a valid Java identifier.");
		}

		private StrictJavaIdentifierTransformer()
		{
		}

	}

	private static final class NoopJavaIdentifierTransformer extends JavaIdentifierTransformer
	{

		public String transformToJavaIdentifier(String str)
		{
			return str;
		}

		private NoopJavaIdentifierTransformer()
		{
		}

	}

	private static final class CamelCaseJavaIdentifierTransformer extends JavaIdentifierTransformer
	{

		public String transformToJavaIdentifier(String str)
		{
			if (str == null)
				return null;
			String str2 = shaveOffNonJavaIdentifierStartChars(str);
			char chars[] = str2.toCharArray();
			int pos = 0;
			StringBuffer buf = new StringBuffer();
			boolean toUpperCaseNextChar = false;
			for (; pos < chars.length; pos++)
			{
				if (!Character.isJavaIdentifierPart(chars[pos]) || Character.isWhitespace(chars[pos]))
				{
					toUpperCaseNextChar = true;
					continue;
				}
				if (toUpperCaseNextChar)
				{
					buf.append(Character.toUpperCase(chars[pos]));
					toUpperCaseNextChar = false;
				} else
				{
					buf.append(chars[pos]);
				}
			}

			return buf.toString();
		}

		private CamelCaseJavaIdentifierTransformer()
		{
		}

	}


	public static final JavaIdentifierTransformer CAMEL_CASE = new CamelCaseJavaIdentifierTransformer();
	public static final JavaIdentifierTransformer NOOP = new NoopJavaIdentifierTransformer();
	public static final JavaIdentifierTransformer STRICT = new StrictJavaIdentifierTransformer();
	public static final JavaIdentifierTransformer UNDERSCORE = new UnderscoreJavaIdentifierTransformer();
	public static final JavaIdentifierTransformer WHITESPACE = new WhiteSpaceJavaIdentifierTransformer();

	public JavaIdentifierTransformer()
	{
	}

	public abstract String transformToJavaIdentifier(String s);

	protected final String shaveOffNonJavaIdentifierStartChars(String str)
	{
		String str2 = str;
		boolean ready = false;
		do
		{
			if (ready)
				break;
			if (!Character.isJavaIdentifierStart(str2.charAt(0)))
			{
				str2 = str2.substring(1);
				if (str2.length() == 0)
					throw new JSONException("Can't convert '" + str + "' to a valid Java identifier");
			} else
			{
				ready = true;
			}
		} while (true);
		return str2;
	}

}
