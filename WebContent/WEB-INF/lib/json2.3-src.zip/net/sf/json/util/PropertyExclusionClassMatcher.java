// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PropertyExclusionClassMatcher.java

package net.sf.json.util;

import java.util.Set;

public abstract class PropertyExclusionClassMatcher
{
	private static final class DefaultPropertyExclusionClassMatcher extends PropertyExclusionClassMatcher
	{

		public Object getMatch(Class target, Set set)
		{
			if (target != null && set != null && set.contains(target))
				return target;
			else
				return null;
		}

		private DefaultPropertyExclusionClassMatcher()
		{
		}

	}


	public static final PropertyExclusionClassMatcher DEFAULT = new DefaultPropertyExclusionClassMatcher();

	public PropertyExclusionClassMatcher()
	{
	}

	public abstract Object getMatch(Class class1, Set set);

}
