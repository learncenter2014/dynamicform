// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONTokener.java

package net.sf.json.util;

import net.sf.json.*;
import net.sf.json.regexp.RegexpMatcher;
import net.sf.json.regexp.RegexpUtils;

// Referenced classes of package net.sf.json.util:
//			JSONUtils

public class JSONTokener
{

	private int myIndex;
	private String mySource;

	public static int dehexchar(char c)
	{
		if (c >= '0' && c <= '9')
			return c - 48;
		if (c >= 'A' && c <= 'F')
			return c - 55;
		if (c >= 'a' && c <= 'f')
			return c - 87;
		else
			return -1;
	}

	public JSONTokener(String s)
	{
		myIndex = 0;
		if (s != null)
			s = s.trim();
		else
			s = "";
		if (s.length() > 0)
		{
			char first = s.charAt(0);
			char last = s.charAt(s.length() - 1);
			if (first == '[' && last != ']')
				throw syntaxError("Found starting '[' but missing ']' at the end.");
			if (first == '{' && last != '}')
				throw syntaxError("Found starting '{' but missing '}' at the end.");
		}
		mySource = s;
	}

	public void back()
	{
		if (myIndex > 0)
			myIndex--;
	}

	public int length()
	{
		if (mySource == null)
			return 0;
		else
			return mySource.length();
	}

	public boolean matches(String pattern)
	{
		String str = mySource.substring(myIndex);
		return RegexpUtils.getMatcher(pattern).matches(str);
	}

	public boolean more()
	{
		return myIndex < mySource.length();
	}

	public char next()
	{
		if (more())
		{
			char c = mySource.charAt(myIndex);
			myIndex++;
			return c;
		} else
		{
			return '\0';
		}
	}

	public char next(char c)
	{
		char n = next();
		if (n != c)
			throw syntaxError("Expected '" + c + "' and instead saw '" + n + "'.");
		else
			return n;
	}

	public String next(int n)
	{
		int i = myIndex;
		int j = i + n;
		if (j >= mySource.length())
		{
			throw syntaxError("Substring bounds error");
		} else
		{
			myIndex += n;
			return mySource.substring(i, j);
		}
	}

	public char nextClean()
	{
		char c;
		do
label0:
			do
			{
				c = next();
				if (c == '/')
				{
					switch (next())
					{
					case 47: // '/'
						do
							c = next();
						while (c != '\n' && c != '\r' && c != 0);
						continue;

					case 42: // '*'
						do
						{
							do
							{
								c = next();
								if (c == 0)
									throw syntaxError("Unclosed comment.");
							} while (c != '*');
							if (next() == '/')
								continue label0;
							back();
						} while (true);
					}
					back();
					return '/';
				}
				if (c != '#')
					break;
				do
					c = next();
				while (c != '\n' && c != '\r' && c != 0);
			} while (true);
		while (c != 0 && c <= ' ');
		return c;
	}

	public String nextString(char quote)
	{
		StringBuffer sb = new StringBuffer();
		do
		{
			char c = next();
			switch (c)
			{
			case 0: // '\0'
			case 10: // '\n'
			case 13: // '\r'
				throw syntaxError("Unterminated string");

			case 92: // '\\'
				c = next();
				switch (c)
				{
				case 98: // 'b'
					sb.append('\b');
					break;

				case 116: // 't'
					sb.append('\t');
					break;

				case 110: // 'n'
					sb.append('\n');
					break;

				case 102: // 'f'
					sb.append('\f');
					break;

				case 114: // 'r'
					sb.append('\r');
					break;

				case 117: // 'u'
					sb.append((char)Integer.parseInt(next(4), 16));
					break;

				case 120: // 'x'
					sb.append((char)Integer.parseInt(next(2), 16));
					break;

				case 99: // 'c'
				case 100: // 'd'
				case 101: // 'e'
				case 103: // 'g'
				case 104: // 'h'
				case 105: // 'i'
				case 106: // 'j'
				case 107: // 'k'
				case 108: // 'l'
				case 109: // 'm'
				case 111: // 'o'
				case 112: // 'p'
				case 113: // 'q'
				case 115: // 's'
				case 118: // 'v'
				case 119: // 'w'
				default:
					sb.append(c);
					break;
				}
				break;

			default:
				if (c == quote)
					return sb.toString();
				sb.append(c);
				break;
			}
		} while (true);
	}

	public String nextTo(char d)
	{
		StringBuffer sb = new StringBuffer();
		do
		{
			char c = next();
			if (c == d || c == 0 || c == '\n' || c == '\r')
			{
				if (c != 0)
					back();
				return sb.toString().trim();
			}
			sb.append(c);
		} while (true);
	}

	public String nextTo(String delimiters)
	{
		StringBuffer sb = new StringBuffer();
		do
		{
			char c = next();
			if (delimiters.indexOf(c) >= 0 || c == 0 || c == '\n' || c == '\r')
			{
				if (c != 0)
					back();
				return sb.toString().trim();
			}
			sb.append(c);
		} while (true);
	}

	public Object nextValue()
	{
		return nextValue(new JsonConfig());
	}

	public Object nextValue(JsonConfig jsonConfig)
	{
		String s;
		char c = nextClean();
		switch (c)
		{
		case 34: // '"'
		case 39: // '\''
			return nextString(c);

		case 123: // '{'
			back();
			return JSONObject.fromObject(this, jsonConfig);

		case 91: // '['
			back();
			return JSONArray.fromObject(this, jsonConfig);
		}
		StringBuffer sb = new StringBuffer();
		char b = c;
		for (; c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0; c = next())
			sb.append(c);

		back();
		s = sb.toString().trim();
		if (s.equals(""))
			throw syntaxError("Missing value.");
		if (s.equalsIgnoreCase("true"))
			return Boolean.TRUE;
		if (s.equalsIgnoreCase("false"))
			return Boolean.FALSE;
		if (s.equals("null") || jsonConfig.isJavascriptCompliant() && s.equals("undefined"))
			return JSONNull.getInstance();
		if ((b < '0' || b > '9') && b != '.' && b != '-' && b != '+')
			break MISSING_BLOCK_LABEL_344;
		if (b != '0')
			break MISSING_BLOCK_LABEL_309;
		if (s.length() <= 2 || s.charAt(1) != 'x' && s.charAt(1) != 'X')
			break MISSING_BLOCK_LABEL_293;
		return new Integer(Integer.parseInt(s.substring(2), 16));
		Exception e;
		e;
		break MISSING_BLOCK_LABEL_309;
		return new Integer(Integer.parseInt(s, 8));
		e;
		return new Integer(s);
		e;
		return new Long(s);
		Exception f;
		f;
		return new Double(s);
		Exception g;
		g;
		return s;
		if (JSONUtils.isFunctionHeader(s) || JSONUtils.isFunction(s))
			return s;
		switch (peek())
		{
		case 44: // ','
		case 91: // '['
		case 93: // ']'
		case 123: // '{'
		case 125: // '}'
			throw new JSONException("Unquotted string '" + s + "'");
		}
		return s;
	}

	public char peek()
	{
		if (more())
		{
			char c = mySource.charAt(myIndex);
			return c;
		} else
		{
			return '\0';
		}
	}

	public void reset()
	{
		myIndex = 0;
	}

	public void skipPast(String to)
	{
		myIndex = mySource.indexOf(to, myIndex);
		if (myIndex < 0)
			myIndex = mySource.length();
		else
			myIndex += to.length();
	}

	public char skipTo(char to)
	{
		int index = myIndex;
		char c;
		do
		{
			c = next();
			if (c == 0)
			{
				myIndex = index;
				return c;
			}
		} while (c != to);
		back();
		return c;
	}

	public JSONException syntaxError(String message)
	{
		return new JSONException(message + toString());
	}

	public String toString()
	{
		return " at character " + myIndex + " of " + mySource;
	}
}
