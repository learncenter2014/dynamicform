// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONUtils.java

package net.sf.json.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import net.sf.ezmorph.MorphUtils;
import net.sf.ezmorph.MorpherRegistry;
import net.sf.ezmorph.bean.MorphDynaBean;
import net.sf.ezmorph.bean.MorphDynaClass;
import net.sf.json.*;
import net.sf.json.regexp.RegexpMatcher;
import net.sf.json.regexp.RegexpUtils;
import org.apache.commons.beanutils.DynaBean;

// Referenced classes of package net.sf.json.util:
//			JavaIdentifierTransformer

public final class JSONUtils
{

	public static final String DOUBLE_QUOTE = "\"";
	public static final String SINGLE_QUOTE = "'";
	private static final String FUNCTION_BODY_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{(.*?)\\}$";
	private static final String FUNCTION_HEADER_PATTERN = "^function[ ]?\\(.*?\\)$";
	private static final String FUNCTION_PARAMS_PATTERN = "^function[ ]?\\((.*?)\\).*";
	private static final String FUNCTION_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{.*?\\}$";
	private static final String FUNCTION_PREFIX = "function";
	private static final MorpherRegistry morpherRegistry;

	public static String convertToJavaIdentifier(String key)
	{
		return convertToJavaIdentifier(key, new JsonConfig());
	}

	public static String convertToJavaIdentifier(String key, JsonConfig jsonConfig)
	{
		return jsonConfig.getJavaIdentifierTransformer().transformToJavaIdentifier(key);
		JSONException jsone;
		jsone;
		throw jsone;
		Exception e;
		e;
		throw new JSONException(e);
	}

	public static String doubleToString(double d)
	{
		if (Double.isInfinite(d) || Double.isNaN(d))
			return "null";
		String s = Double.toString(d);
		if (s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0)
		{
			for (; s.endsWith("0"); s = s.substring(0, s.length() - 1));
			if (s.endsWith("."))
				s = s.substring(0, s.length() - 1);
		}
		return s;
	}

	public static String getFunctionBody(String function)
	{
		return RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)[ \n\t]*\\{(.*?)\\}$", true).getGroupIfMatches(function, 1);
	}

	public static String getFunctionParams(String function)
	{
		return RegexpUtils.getMatcher("^function[ ]?\\((.*?)\\).*", true).getGroupIfMatches(function, 1);
	}

	public static Class getInnerComponentType(Class type)
	{
		if (!type.isArray())
			return type;
		else
			return getInnerComponentType(type.getComponentType());
	}

	public static MorpherRegistry getMorpherRegistry()
	{
		return morpherRegistry;
	}

	public static Map getProperties(JSONObject jsonObject)
	{
		Map properties = new HashMap();
		String key;
		for (Iterator keys = jsonObject.keys(); keys.hasNext(); properties.put(key, getTypeClass(jsonObject.get(key))))
			key = (String)keys.next();

		return properties;
	}

	public static Class getTypeClass(Object obj)
	{
		if (isNull(obj))
			return java/lang/Object;
		if (isArray(obj))
			return java/util/List;
		if (isFunction(obj))
			return net/sf/json/JSONFunction;
		if (isBoolean(obj))
			return java/lang/Boolean;
		if (isNumber(obj))
		{
			Number n = (Number)obj;
			if (isInteger(n))
				return java/lang/Integer;
			if (isLong(n))
				return java/lang/Long;
			if (isFloat(n))
				return java/lang/Float;
			if (isBigInteger(n))
				return java/math/BigInteger;
			if (isBigDecimal(n))
				return java/math/BigDecimal;
			if (isDouble(n))
				return java/lang/Double;
			else
				throw new JSONException("Unsupported type");
		}
		if (isString(obj))
			return java/lang/String;
		if (isObject(obj))
			return java/lang/Object;
		else
			throw new JSONException("Unsupported type");
	}

	public static int hashCode(Object value)
	{
		if (value == null)
			return JSONNull.getInstance().hashCode();
		if ((value instanceof JSON) || (value instanceof String) || (value instanceof JSONFunction))
			return value.hashCode();
		else
			return String.valueOf(value).hashCode();
	}

	public static boolean isArray(Class clazz)
	{
		return clazz != null && (clazz.isArray() || java/util/Collection.isAssignableFrom(clazz) || net/sf/json/JSONArray.isAssignableFrom(clazz));
	}

	public static boolean isArray(Object obj)
	{
		return obj != null && obj.getClass().isArray() || (obj instanceof Collection) || (obj instanceof JSONArray);
	}

	public static boolean isBoolean(Class clazz)
	{
		return clazz != null && (Boolean.TYPE.isAssignableFrom(clazz) || java/lang/Boolean.isAssignableFrom(clazz));
	}

	public static boolean isBoolean(Object obj)
	{
		return (obj instanceof Boolean) || obj != null && obj.getClass() == Boolean.TYPE;
	}

	public static boolean isDouble(Class clazz)
	{
		return clazz != null && (Double.TYPE.isAssignableFrom(clazz) || java/lang/Double.isAssignableFrom(clazz));
	}

	public static boolean isFunction(Object obj)
	{
		if (obj instanceof String)
		{
			String str = (String)obj;
			return str.startsWith("function") && RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)[ \n\t]*\\{.*?\\}$", true).matches(str);
		}
		return obj instanceof JSONFunction;
	}

	public static boolean isFunctionHeader(Object obj)
	{
		if (obj instanceof String)
		{
			String str = (String)obj;
			return str.startsWith("function") && RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)$", true).matches(str);
		} else
		{
			return false;
		}
	}

	public static boolean isJavaIdentifier(String str)
	{
		if (str.length() == 0 || !Character.isJavaIdentifierStart(str.charAt(0)))
			return false;
		for (int i = 1; i < str.length(); i++)
			if (!Character.isJavaIdentifierPart(str.charAt(i)))
				return false;

		return true;
	}

	public static boolean isNull(Object obj)
	{
		if (obj instanceof JSONObject)
			return ((JSONObject)obj).isNullObject();
		else
			return JSONNull.getInstance().equals(obj);
	}

	public static boolean isNumber(Class clazz)
	{
		return clazz != null && (Byte.TYPE.isAssignableFrom(clazz) || Short.TYPE.isAssignableFrom(clazz) || Integer.TYPE.isAssignableFrom(clazz) || Long.TYPE.isAssignableFrom(clazz) || Float.TYPE.isAssignableFrom(clazz) || Double.TYPE.isAssignableFrom(clazz) || java/lang/Number.isAssignableFrom(clazz));
	}

	public static boolean isNumber(Object obj)
	{
		if (obj != null && obj.getClass() == Byte.TYPE || obj != null && obj.getClass() == Short.TYPE || obj != null && obj.getClass() == Integer.TYPE || obj != null && obj.getClass() == Long.TYPE || obj != null && obj.getClass() == Float.TYPE || obj != null && obj.getClass() == Double.TYPE)
			return true;
		else
			return obj instanceof Number;
	}

	public static boolean isObject(Object obj)
	{
		return !isNumber(obj) && !isString(obj) && !isBoolean(obj) && !isArray(obj) && !isFunction(obj) || isNull(obj);
	}

	public static boolean isString(Class clazz)
	{
		return clazz != null && (java/lang/String.isAssignableFrom(clazz) || Character.TYPE.isAssignableFrom(clazz) || java/lang/Character.isAssignableFrom(clazz));
	}

	public static boolean isString(Object obj)
	{
		return (obj instanceof String) || (obj instanceof Character) || obj != null && (obj.getClass() == Character.TYPE || java/lang/String.isAssignableFrom(obj.getClass()));
	}

	public static boolean mayBeJSON(String string)
	{
		return string != null && ("null".equals(string) || string.startsWith("[") && string.endsWith("]") || string.startsWith("{") && string.endsWith("}"));
	}

	public static DynaBean newDynaBean(JSONObject jsonObject)
	{
		return newDynaBean(jsonObject, new JsonConfig());
	}

	public static DynaBean newDynaBean(JSONObject jsonObject, JsonConfig jsonConfig)
	{
		Map props = getProperties(jsonObject);
		Iterator entries = props.entrySet().iterator();
		do
		{
			if (!entries.hasNext())
				break;
			java.util.Map.Entry entry = (java.util.Map.Entry)entries.next();
			String key = (String)entry.getKey();
			if (!isJavaIdentifier(key))
			{
				String parsedKey = convertToJavaIdentifier(key, jsonConfig);
				if (parsedKey.compareTo(key) != 0)
					props.put(parsedKey, props.remove(key));
			}
		} while (true);
		MorphDynaClass dynaClass = new MorphDynaClass(props);
		MorphDynaBean dynaBean = null;
		try
		{
			dynaBean = (MorphDynaBean)dynaClass.newInstance();
			dynaBean.setDynaBeanClass(dynaClass);
		}
		catch (Exception e)
		{
			throw new JSONException(e);
		}
		return dynaBean;
	}

	public static String numberToString(Number n)
	{
		if (n == null)
			throw new JSONException("Null pointer");
		testValidity(n);
		String s = n.toString();
		if (s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0)
		{
			for (; s.endsWith("0"); s = s.substring(0, s.length() - 1));
			if (s.endsWith("."))
				s = s.substring(0, s.length() - 1);
		}
		return s;
	}

	public static String quote(String string)
	{
		if (isFunction(string))
			return string;
		if (string == null || string.length() == 0)
			return "\"\"";
		char c = '\0';
		int len = string.length();
		StringBuilder sb = new StringBuilder(len * 2);
		char chars[] = string.toCharArray();
		char buffer[] = new char[1030];
		int bufferIndex = 0;
		sb.append('"');
		for (int i = 0; i < len; i++)
		{
			if (bufferIndex > 1024)
			{
				sb.append(buffer, 0, bufferIndex);
				bufferIndex = 0;
			}
			char b = c;
			c = chars[i];
			switch (c)
			{
			case 34: // '"'
			case 92: // '\\'
				buffer[bufferIndex++] = '\\';
				buffer[bufferIndex++] = c;
				break;

			case 47: // '/'
				if (b == '<')
					buffer[bufferIndex++] = '\\';
				buffer[bufferIndex++] = c;
				break;

			default:
				if (c < ' ')
					switch (c)
					{
					case 8: // '\b'
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 'b';
						break;

					case 9: // '\t'
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 't';
						break;

					case 10: // '\n'
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 'n';
						break;

					case 12: // '\f'
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 'f';
						break;

					case 13: // '\r'
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 'r';
						break;

					case 11: // '\013'
					default:
						String t = (new StringBuilder()).append("000").append(Integer.toHexString(c)).toString();
						int tLength = t.length();
						buffer[bufferIndex++] = '\\';
						buffer[bufferIndex++] = 'u';
						buffer[bufferIndex++] = t.charAt(tLength - 4);
						buffer[bufferIndex++] = t.charAt(tLength - 3);
						buffer[bufferIndex++] = t.charAt(tLength - 2);
						buffer[bufferIndex++] = t.charAt(tLength - 1);
						break;
					}
				else
					buffer[bufferIndex++] = c;
				break;
			}
		}

		sb.append(buffer, 0, bufferIndex);
		sb.append('"');
		return sb.toString();
	}

	public static String stripQuotes(String input)
	{
		if (input.length() < 2)
			return input;
		if (input.startsWith("'") && input.endsWith("'"))
			return input.substring(1, input.length() - 1);
		if (input.startsWith("\"") && input.endsWith("\""))
			return input.substring(1, input.length() - 1);
		else
			return input;
	}

	public static boolean hasQuotes(String input)
	{
		if (input == null || input.length() < 2)
			return false;
		else
			return input.startsWith("'") && input.endsWith("'") || input.startsWith("\"") && input.endsWith("\"");
	}

	public static boolean isJsonKeyword(String input, JsonConfig jsonConfig)
	{
		if (input == null)
			return false;
		else
			return "null".equals(input) || "true".equals(input) || "false".equals(input) || jsonConfig.isJavascriptCompliant() && "undefined".equals(input);
	}

	public static void testValidity(Object o)
	{
		if (o != null)
			if (o instanceof Double)
			{
				if (((Double)o).isInfinite() || ((Double)o).isNaN())
					throw new JSONException("JSON does not allow non-finite numbers");
			} else
			if (o instanceof Float)
			{
				if (((Float)o).isInfinite() || ((Float)o).isNaN())
					throw new JSONException("JSON does not allow non-finite numbers.");
			} else
			if ((o instanceof BigDecimal) || (o instanceof BigInteger))
				return;
	}

	public static Number transformNumber(Number input)
	{
		if (input instanceof Float)
			return new Double(input.toString());
		if (input instanceof Short)
			return new Integer(input.intValue());
		if (input instanceof Byte)
			return new Integer(input.intValue());
		if (input instanceof Long)
		{
			Long max = new Long(0x7fffffffL);
			if (input.longValue() <= max.longValue() && input.longValue() >= 0xffffffff80000000L)
				return new Integer(input.intValue());
		}
		return input;
	}

	public static String valueToString(Object value)
	{
		if (value == null || isNull(value))
			return "null";
		if (value instanceof JSONFunction)
			return ((JSONFunction)value).toString();
		if (value instanceof JSONString)
		{
			Object o;
			try
			{
				o = ((JSONString)value).toJSONString();
			}
			catch (Exception e)
			{
				throw new JSONException(e);
			}
			if (o instanceof String)
				return (String)o;
			else
				throw new JSONException((new StringBuilder()).append("Bad value from toJSONString: ").append(o).toString());
		}
		if (value instanceof Number)
			return numberToString((Number)value);
		if ((value instanceof Boolean) || (value instanceof JSONObject) || (value instanceof JSONArray))
			return value.toString();
		else
			return quote(value.toString());
	}

	public static String valueToString(Object value, int indentFactor, int indent)
	{
		if (value == null || isNull(value))
			return "null";
		if (value instanceof JSONFunction)
			return ((JSONFunction)value).toString();
		if (value instanceof JSONString)
			return ((JSONString)value).toJSONString();
		if (value instanceof Number)
			return numberToString((Number)value);
		if (value instanceof Boolean)
			return value.toString();
		if (value instanceof JSONObject)
			return ((JSONObject)value).toString(indentFactor, indent);
		if (value instanceof JSONArray)
			return ((JSONArray)value).toString(indentFactor, indent);
		else
			return quote(value.toString());
	}

	private static boolean isBigDecimal(Number n)
	{
		if (n instanceof BigDecimal)
			return true;
		new BigDecimal(String.valueOf(n));
		return true;
		NumberFormatException e;
		e;
		return false;
	}

	private static boolean isBigInteger(Number n)
	{
		if (n instanceof BigInteger)
			return true;
		new BigInteger(String.valueOf(n));
		return true;
		NumberFormatException e;
		e;
		return false;
	}

	private static boolean isDouble(Number n)
	{
		if (n instanceof Double)
			return true;
		double d = Double.parseDouble(String.valueOf(n));
		return !Double.isInfinite(d);
		NumberFormatException e;
		e;
		return false;
	}

	private static boolean isFloat(Number n)
	{
		if (n instanceof Float)
			return true;
		float f = Float.parseFloat(String.valueOf(n));
		return !Float.isInfinite(f);
		NumberFormatException e;
		e;
		return false;
	}

	private static boolean isInteger(Number n)
	{
		if (n instanceof Integer)
			return true;
		Integer.parseInt(String.valueOf(n));
		return true;
		NumberFormatException e;
		e;
		return false;
	}

	private static boolean isLong(Number n)
	{
		if (n instanceof Long)
			return true;
		Long.parseLong(String.valueOf(n));
		return true;
		NumberFormatException e;
		e;
		return false;
	}

	private JSONUtils()
	{
	}

	static 
	{
		morpherRegistry = new MorpherRegistry();
		MorphUtils.registerStandardMorphers(morpherRegistry);
	}
}
