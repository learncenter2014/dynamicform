// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NewBeanInstanceStrategy.java

package net.sf.json.util;

import java.lang.reflect.*;
import net.sf.json.JSONObject;

public abstract class NewBeanInstanceStrategy
{
	private static final class DefaultNewBeanInstanceStrategy extends NewBeanInstanceStrategy
	{

		private static final Object EMPTY_ARGS[] = new Object[0];
		private static final Class EMPTY_PARAM_TYPES[] = new Class[0];

		public Object newInstance(Class target, JSONObject source)
			throws InstantiationException, IllegalAccessException, SecurityException, NoSuchMethodException, InvocationTargetException
		{
			Constructor c;
			if (target == null)
				break MISSING_BLOCK_LABEL_124;
			c = target.getDeclaredConstructor(EMPTY_PARAM_TYPES);
			c.setAccessible(true);
			return c.newInstance(EMPTY_ARGS);
			InstantiationException e;
			e;
			String cause = "";
			try
			{
				cause = e.getCause() == null ? "" : "\n" + e.getCause().getMessage();
			}
			catch (Throwable t) { }
			throw new InstantiationException("Instantiation of \"" + target + "\" failed. " + "It's probably because class is an interface, " + "abstract class, array class, primitive type or void." + cause);
			return null;
		}


		private DefaultNewBeanInstanceStrategy()
		{
		}

	}


	public static final NewBeanInstanceStrategy DEFAULT = new DefaultNewBeanInstanceStrategy();

	public NewBeanInstanceStrategy()
	{
	}

	public abstract Object newInstance(Class class1, JSONObject jsonobject)
		throws InstantiationException, IllegalAccessException, SecurityException, NoSuchMethodException, InvocationTargetException;

}
