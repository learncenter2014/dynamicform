// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CycleDetectionStrategy.java

package net.sf.json.util;

import net.sf.json.*;

public abstract class CycleDetectionStrategy
{
	private static final class StrictCycleDetectionStrategy extends CycleDetectionStrategy
	{

		public JSONArray handleRepeatedReferenceAsArray(Object reference)
		{
			throw new JSONException("There is a cycle in the hierarchy!");
		}

		public JSONObject handleRepeatedReferenceAsObject(Object reference)
		{
			throw new JSONException("There is a cycle in the hierarchy!");
		}

		private StrictCycleDetectionStrategy()
		{
		}

	}

	private static final class LenientNoRefCycleDetectionStrategy extends CycleDetectionStrategy
	{

		public JSONArray handleRepeatedReferenceAsArray(Object reference)
		{
			return CycleDetectionStrategy.IGNORE_PROPERTY_ARR;
		}

		public JSONObject handleRepeatedReferenceAsObject(Object reference)
		{
			return CycleDetectionStrategy.IGNORE_PROPERTY_OBJ;
		}

		private LenientNoRefCycleDetectionStrategy()
		{
		}

	}

	private static final class LenientCycleDetectionStrategy extends CycleDetectionStrategy
	{

		public JSONArray handleRepeatedReferenceAsArray(Object reference)
		{
			return new JSONArray();
		}

		public JSONObject handleRepeatedReferenceAsObject(Object reference)
		{
			return new JSONObject(true);
		}

		private LenientCycleDetectionStrategy()
		{
		}

	}


	public static final JSONArray IGNORE_PROPERTY_ARR = new JSONArray();
	public static final JSONObject IGNORE_PROPERTY_OBJ = new JSONObject();
	public static final CycleDetectionStrategy LENIENT = new LenientCycleDetectionStrategy();
	public static final CycleDetectionStrategy NOPROP = new LenientNoRefCycleDetectionStrategy();
	public static final CycleDetectionStrategy STRICT = new StrictCycleDetectionStrategy();

	public CycleDetectionStrategy()
	{
	}

	public abstract JSONArray handleRepeatedReferenceAsArray(Object obj);

	public abstract JSONObject handleRepeatedReferenceAsObject(Object obj);

}
