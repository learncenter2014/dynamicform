// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PropertySetStrategy.java

package net.sf.json.util;

import java.lang.reflect.Field;
import java.util.Map;
import net.sf.json.JSONException;
import net.sf.json.JsonConfig;
import org.apache.commons.beanutils.PropertyUtils;

public abstract class PropertySetStrategy
{
	private static final class DefaultPropertySetStrategy extends PropertySetStrategy
	{

		public void setProperty(Object bean, String key, Object value)
			throws JSONException
		{
			setProperty(bean, key, value, new JsonConfig());
		}

		public void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig)
			throws JSONException
		{
			if (bean instanceof Map)
				((Map)bean).put(key, value);
			else
			if (!jsonConfig.isIgnorePublicFields())
				try
				{
					Field field = bean.getClass().getField(key);
					if (field != null)
						field.set(bean, value);
				}
				catch (Exception e)
				{
					_setProperty(bean, key, value);
				}
			else
				_setProperty(bean, key, value);
		}

		private void _setProperty(Object bean, String key, Object value)
		{
			try
			{
				PropertyUtils.setSimpleProperty(bean, key, value);
			}
			catch (Exception e)
			{
				throw new JSONException(e);
			}
		}

		private DefaultPropertySetStrategy()
		{
		}

	}


	public static final PropertySetStrategy DEFAULT = new DefaultPropertySetStrategy();

	public PropertySetStrategy()
	{
	}

	public abstract void setProperty(Object obj, String s, Object obj1)
		throws JSONException;

	public void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig)
		throws JSONException
	{
		setProperty(bean, key, value);
	}

}
