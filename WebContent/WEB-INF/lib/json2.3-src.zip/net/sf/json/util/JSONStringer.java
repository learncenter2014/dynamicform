// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONStringer.java

package net.sf.json.util;

import java.io.StringWriter;

// Referenced classes of package net.sf.json.util:
//			JSONBuilder

public class JSONStringer extends JSONBuilder
{

	public JSONStringer()
	{
		super(new StringWriter());
	}

	public String toString()
	{
		return super.mode != 'd' ? null : super.writer.toString();
	}
}
