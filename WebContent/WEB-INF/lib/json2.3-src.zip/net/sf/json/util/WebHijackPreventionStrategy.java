// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WebHijackPreventionStrategy.java

package net.sf.json.util;


public abstract class WebHijackPreventionStrategy
{
	private static final class InfiniteLoopWebHijackPreventionStrategy extends WebHijackPreventionStrategy
	{

		public String protect(String str)
		{
			return "while(1);" + str;
		}

		private InfiniteLoopWebHijackPreventionStrategy()
		{
		}

	}

	private static final class CommentWebHijackPreventionStrategy extends WebHijackPreventionStrategy
	{

		public String protect(String str)
		{
			return "/*" + str + "*/";
		}

		private CommentWebHijackPreventionStrategy()
		{
		}

	}


	public static final WebHijackPreventionStrategy COMMENTS = new CommentWebHijackPreventionStrategy();
	public static final WebHijackPreventionStrategy INFINITE_LOOP = new InfiniteLoopWebHijackPreventionStrategy();

	public WebHijackPreventionStrategy()
	{
	}

	public abstract String protect(String s);

}
