// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonEventListener.java

package net.sf.json.util;

import net.sf.json.JSONException;

public interface JsonEventListener
{

	public abstract void onArrayEnd();

	public abstract void onArrayStart();

	public abstract void onElementAdded(int i, Object obj);

	public abstract void onError(JSONException jsonexception);

	public abstract void onObjectEnd();

	public abstract void onObjectStart();

	public abstract void onPropertySet(String s, Object obj, boolean flag);

	public abstract void onWarning(String s);
}
