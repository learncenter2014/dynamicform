// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WebUtils.java

package net.sf.json.util;

import java.util.Iterator;
import net.sf.json.*;

// Referenced classes of package net.sf.json.util:
//			WebHijackPreventionStrategy, JSONUtils

public class WebUtils
{

	private static final WebHijackPreventionStrategy DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY;
	private static WebHijackPreventionStrategy webHijackPreventionStrategy;

	public static WebHijackPreventionStrategy getWebHijackPreventionStrategy()
	{
		return webHijackPreventionStrategy;
	}

	public static String protect(JSON json)
	{
		return protect(json, false);
	}

	public static String protect(JSON json, boolean shrink)
	{
		String output = shrink ? toString(json) : json.toString(0);
		return webHijackPreventionStrategy.protect(output);
	}

	public static void setWebHijackPreventionStrategy(WebHijackPreventionStrategy strategy)
	{
		webHijackPreventionStrategy = strategy != null ? strategy : DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY;
	}

	public static String toString(JSON json)
	{
		if (json instanceof JSONObject)
			return toString((JSONObject)json);
		if (json instanceof JSONArray)
			return toString((JSONArray)json);
		else
			return toString((JSONNull)json);
	}

	private static String join(JSONArray jsonArray)
	{
		int len = jsonArray.size();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < len; i++)
		{
			if (i > 0)
				sb.append(",");
			Object value = jsonArray.get(i);
			sb.append(toString(value));
		}

		return sb.toString();
	}

	private static String quote(String str)
	{
		if (str.indexOf(" ") > -1 || str.indexOf(":") > -1)
			return JSONUtils.quote(str);
		else
			return str;
	}

	private static String toString(JSONArray jsonArray)
	{
		return '[' + join(jsonArray) + ']';
		Exception e;
		e;
		return null;
	}

	private static String toString(JSONNull jsonNull)
	{
		return jsonNull.toString();
	}

	private static String toString(JSONObject jsonObject)
	{
		if (jsonObject.isNullObject())
			return JSONNull.getInstance().toString();
		Iterator keys = jsonObject.keys();
		StringBuffer sb = new StringBuffer("{");
		Object o;
		for (; keys.hasNext(); sb.append(toString(jsonObject.get(String.valueOf(o)))))
		{
			if (sb.length() > 1)
				sb.append(',');
			o = keys.next();
			sb.append(quote(o.toString()));
			sb.append(':');
		}

		sb.append('}');
		return sb.toString();
	}

	private static String toString(Object object)
	{
		if (object instanceof JSON)
			return toString((JSON)object);
		else
			return JSONUtils.valueToString(object);
	}

	private WebUtils()
	{
	}

	static 
	{
		DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY = WebHijackPreventionStrategy.INFINITE_LOOP;
		webHijackPreventionStrategy = DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY;
	}
}
