// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONArray.java

package net.sf.json;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;
import net.sf.ezmorph.MorpherRegistry;
import net.sf.ezmorph.object.IdentityObjectMorpher;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.processors.JsonVerifier;
import net.sf.json.util.CycleDetectionStrategy;
import net.sf.json.util.JSONTokener;
import net.sf.json.util.JSONUtils;
import net.sf.json.util.NewBeanInstanceStrategy;
import org.apache.commons.lang.StringUtils;

// Referenced classes of package net.sf.json:
//			AbstractJSON, JsonConfig, JSONString, JSONException, 
//			JSON, JSONFunction, JSONObject, JSONNull, 
//			JSONSerializer

public final class JSONArray extends AbstractJSON
	implements JSON, List, Comparable
{
	private class JSONArrayListIterator
		implements ListIterator
	{

		int currentIndex;
		int lastIndex;
		final JSONArray this$0;

		public boolean hasNext()
		{
			return currentIndex != size();
		}

		public Object next()
		{
			Object next;
			next = get(currentIndex);
			lastIndex = currentIndex++;
			return next;
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException();
		}

		public void remove()
		{
			if (lastIndex == -1)
				throw new IllegalStateException();
			try
			{
				JSONArray.this.remove(lastIndex);
				if (lastIndex < currentIndex)
					currentIndex--;
				lastIndex = -1;
			}
			catch (IndexOutOfBoundsException e)
			{
				throw new ConcurrentModificationException();
			}
		}

		public boolean hasPrevious()
		{
			return currentIndex != 0;
		}

		public Object previous()
		{
			Object previous;
			int index = currentIndex - 1;
			previous = get(index);
			lastIndex = currentIndex = index;
			return previous;
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException();
		}

		public int nextIndex()
		{
			return currentIndex;
		}

		public int previousIndex()
		{
			return currentIndex - 1;
		}

		public void set(Object obj)
		{
			if (lastIndex == -1)
				throw new IllegalStateException();
			try
			{
				JSONArray.this.set(lastIndex, obj);
			}
			catch (IndexOutOfBoundsException ex)
			{
				throw new ConcurrentModificationException();
			}
		}

		public void add(Object obj)
		{
			try
			{
				JSONArray.this.add(currentIndex++, obj);
				lastIndex = -1;
			}
			catch (IndexOutOfBoundsException ex)
			{
				throw new ConcurrentModificationException();
			}
		}

		JSONArrayListIterator()
		{
			this$0 = JSONArray.this;
			super();
			currentIndex = 0;
			lastIndex = -1;
		}

		JSONArrayListIterator(int index)
		{
			this$0 = JSONArray.this;
			super();
			currentIndex = 0;
			lastIndex = -1;
			currentIndex = index;
		}
	}


	private List elements;
	private boolean expandElements;

	public static JSONArray fromObject(Object object)
	{
		return fromObject(object, new JsonConfig());
	}

	public static JSONArray fromObject(Object object, JsonConfig jsonConfig)
	{
		if (object instanceof JSONString)
			return _fromJSONString((JSONString)object, jsonConfig);
		if (object instanceof JSONArray)
			return _fromJSONArray((JSONArray)object, jsonConfig);
		if (object instanceof Collection)
			return _fromCollection((Collection)object, jsonConfig);
		if (object instanceof JSONTokener)
			return _fromJSONTokener((JSONTokener)object, jsonConfig);
		if (object instanceof String)
			return _fromString((String)object, jsonConfig);
		if (object != null && object.getClass().isArray())
		{
			Class type = object.getClass().getComponentType();
			if (!type.isPrimitive())
				return _fromArray((Object[])(Object[])object, jsonConfig);
			if (type == Boolean.TYPE)
				return _fromArray((boolean[])(boolean[])object, jsonConfig);
			if (type == Byte.TYPE)
				return _fromArray((byte[])(byte[])object, jsonConfig);
			if (type == Short.TYPE)
				return _fromArray((short[])(short[])object, jsonConfig);
			if (type == Integer.TYPE)
				return _fromArray((int[])(int[])object, jsonConfig);
			if (type == Long.TYPE)
				return _fromArray((long[])(long[])object, jsonConfig);
			if (type == Float.TYPE)
				return _fromArray((float[])(float[])object, jsonConfig);
			if (type == Double.TYPE)
				return _fromArray((double[])(double[])object, jsonConfig);
			if (type == Character.TYPE)
				return _fromArray((char[])(char[])object, jsonConfig);
			else
				throw new JSONException("Unsupported type");
		}
		if (JSONUtils.isBoolean(object) || JSONUtils.isFunction(object) || JSONUtils.isNumber(object) || JSONUtils.isNull(object) || JSONUtils.isString(object) || (object instanceof JSON))
		{
			fireArrayStartEvent(jsonConfig);
			JSONArray jsonArray = (new JSONArray()).element(object, jsonConfig);
			fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
			fireArrayStartEvent(jsonConfig);
			return jsonArray;
		}
		if (object instanceof Enum)
			return _fromArray((Enum)object, jsonConfig);
		if ((object instanceof Annotation) || object != null && object.getClass().isAnnotation())
			throw new JSONException("Unsupported type");
		if (JSONUtils.isObject(object))
		{
			fireArrayStartEvent(jsonConfig);
			JSONArray jsonArray = (new JSONArray()).element(JSONObject.fromObject(object, jsonConfig));
			fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
			fireArrayStartEvent(jsonConfig);
			return jsonArray;
		} else
		{
			throw new JSONException("Unsupported type");
		}
	}

	public static Class[] getCollectionType(PropertyDescriptor pd, boolean useGetter)
		throws JSONException
	{
		java.lang.reflect.Type type;
		if (useGetter)
		{
			Method m = pd.getReadMethod();
			type = m.getGenericReturnType();
		} else
		{
			Method m = pd.getWriteMethod();
			java.lang.reflect.Type gpts[] = m.getGenericParameterTypes();
			if (1 != gpts.length)
				throw new JSONException((new StringBuilder()).append("method ").append(m).append(" is not a standard setter").toString());
			type = gpts[0];
		}
		if (!(type instanceof ParameterizedType))
			return null;
		ParameterizedType pType = (ParameterizedType)type;
		java.lang.reflect.Type actualTypes[] = pType.getActualTypeArguments();
		Class ret[] = new Class[actualTypes.length];
		for (int i = 0; i < ret.length; i++)
			ret[i] = (Class)actualTypes[i];

		return ret;
	}

	public static int[] getDimensions(JSONArray jsonArray)
	{
		if (jsonArray == null || jsonArray.isEmpty())
			return (new int[] {
				0
			});
		List dims = new ArrayList();
		processArrayDimensions(jsonArray, dims, 0);
		int dimensions[] = new int[dims.size()];
		int j = 0;
		for (Iterator i = dims.iterator(); i.hasNext();)
			dimensions[j++] = ((Integer)i.next()).intValue();

		return dimensions;
	}

	public static Object toArray(JSONArray jsonArray)
	{
		return toArray(jsonArray, new JsonConfig());
	}

	public static Object toArray(JSONArray jsonArray, Class objectClass)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objectClass);
		return toArray(jsonArray, jsonConfig);
	}

	public static Object toArray(JSONArray jsonArray, Class objectClass, Map classMap)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objectClass);
		jsonConfig.setClassMap(classMap);
		return toArray(jsonArray, jsonConfig);
	}

	public static Object toArray(JSONArray jsonArray, JsonConfig jsonConfig)
	{
		Class objectClass = jsonConfig.getRootClass();
		Map classMap = jsonConfig.getClassMap();
		if (jsonArray.size() == 0)
			return Array.newInstance(((Class) (objectClass != null ? objectClass : java/lang/Object)), 0);
		int dimensions[] = getDimensions(jsonArray);
		Object array = Array.newInstance(((Class) (objectClass != null ? objectClass : java/lang/Object)), dimensions);
		int size = jsonArray.size();
		for (int i = 0; i < size; i++)
		{
			Object value = jsonArray.get(i);
			if (JSONUtils.isNull(value))
			{
				Array.set(array, i, null);
				continue;
			}
			Class type = value.getClass();
			if (net/sf/json/JSONArray.isAssignableFrom(type))
			{
				Array.set(array, i, toArray((JSONArray)value, objectClass, classMap));
				continue;
			}
			if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				if (objectClass != null && !objectClass.isAssignableFrom(type))
					value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
				Array.set(array, i, value);
				continue;
			}
			if (JSONUtils.isNumber(type))
			{
				if (objectClass != null && (java/lang/Byte.isAssignableFrom(objectClass) || Byte.TYPE.isAssignableFrom(objectClass)))
				{
					Array.set(array, i, Byte.valueOf(String.valueOf(value)));
					continue;
				}
				if (objectClass != null && (java/lang/Short.isAssignableFrom(objectClass) || Short.TYPE.isAssignableFrom(objectClass)))
					Array.set(array, i, Short.valueOf(String.valueOf(value)));
				else
					Array.set(array, i, value);
				continue;
			}
			if (objectClass != null)
			{
				JsonConfig jsc = jsonConfig.copy();
				jsc.setRootClass(objectClass);
				jsc.setClassMap(classMap);
				Array.set(array, i, JSONObject.toBean((JSONObject)value, jsc));
			} else
			{
				Array.set(array, i, JSONObject.toBean((JSONObject)value));
			}
		}

		return array;
	}

	public static Object toArray(JSONArray jsonArray, Object root, JsonConfig jsonConfig)
	{
		Class objectClass = root.getClass();
		if (jsonArray.size() == 0)
			return Array.newInstance(objectClass, 0);
		int dimensions[] = getDimensions(jsonArray);
		Object array = Array.newInstance(((Class) (objectClass != null ? objectClass : java/lang/Object)), dimensions);
		int size = jsonArray.size();
		for (int i = 0; i < size; i++)
		{
			Object value = jsonArray.get(i);
			if (JSONUtils.isNull(value))
			{
				Array.set(array, i, null);
				continue;
			}
			Class type = value.getClass();
			if (net/sf/json/JSONArray.isAssignableFrom(type))
			{
				Array.set(array, i, toArray((JSONArray)value, root, jsonConfig));
				continue;
			}
			if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || JSONUtils.isNumber(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				if (objectClass != null && !objectClass.isAssignableFrom(type))
					value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
				Array.set(array, i, value);
				continue;
			}
			try
			{
				Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(root.getClass(), null);
				Array.set(array, i, JSONObject.toBean((JSONObject)value, newRoot, jsonConfig));
			}
			catch (JSONException jsone)
			{
				throw jsone;
			}
			catch (Exception e)
			{
				throw new JSONException(e);
			}
		}

		return array;
	}

	public static Collection toCollection(JSONArray jsonArray)
	{
		return toCollection(jsonArray, new JsonConfig());
	}

	public static Collection toCollection(JSONArray jsonArray, Class objectClass)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objectClass);
		return toCollection(jsonArray, jsonConfig);
	}

	public static Collection toCollection(JSONArray jsonArray, JsonConfig jsonConfig)
	{
		Collection collection = null;
		Class collectionType = jsonConfig.getCollectionType();
		if (collectionType.isInterface())
		{
			if (collectionType.equals(java/util/List))
				collection = new ArrayList();
			else
			if (collectionType.equals(java/util/Set))
				collection = new HashSet();
			else
				throw new JSONException((new StringBuilder()).append("unknown interface: ").append(collectionType).toString());
		} else
		{
			try
			{
				collection = (Collection)collectionType.newInstance();
			}
			catch (InstantiationException e)
			{
				throw new JSONException(e);
			}
			catch (IllegalAccessException e)
			{
				throw new JSONException(e);
			}
		}
		Class objectClass = jsonConfig.getRootClass();
		Map classMap = jsonConfig.getClassMap();
		int size = jsonArray.size();
		for (int i = 0; i < size; i++)
		{
			Object value = jsonArray.get(i);
			if (JSONUtils.isNull(value))
			{
				collection.add(null);
				continue;
			}
			Class type = value.getClass();
			if (net/sf/json/JSONArray.isAssignableFrom(value.getClass()))
			{
				collection.add(toCollection((JSONArray)value, jsonConfig));
				continue;
			}
			if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || JSONUtils.isNumber(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				if (!value.getClass().isAssignableFrom(type))
					throw new JSONException((new StringBuilder()).append("can't assign value ").append(value).append(" of type ").append(value.getClass()).append(" to Collection of type ").append(type).toString());
				collection.add(value);
				continue;
			}
			if (objectClass != null)
			{
				JsonConfig jsc = jsonConfig.copy();
				jsc.setRootClass(objectClass);
				jsc.setClassMap(classMap);
				collection.add(JSONObject.toBean((JSONObject)value, jsc));
			} else
			{
				collection.add(JSONObject.toBean((JSONObject)value));
			}
		}

		return collection;
	}

	/**
	 * @deprecated Method toList is deprecated
	 */

	public static List toList(JSONArray jsonArray)
	{
		return toList(jsonArray, new JsonConfig());
	}

	/**
	 * @deprecated Method toList is deprecated
	 */

	public static List toList(JSONArray jsonArray, Class objectClass)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objectClass);
		return toList(jsonArray, jsonConfig);
	}

	/**
	 * @deprecated Method toList is deprecated
	 */

	public static List toList(JSONArray jsonArray, Class objectClass, Map classMap)
	{
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objectClass);
		jsonConfig.setClassMap(classMap);
		return toList(jsonArray, jsonConfig);
	}

	/**
	 * @deprecated Method toList is deprecated
	 */

	public static List toList(JSONArray jsonArray, JsonConfig jsonConfig)
	{
		if (jsonArray.size() == 0)
			return new ArrayList();
		Class objectClass = jsonConfig.getRootClass();
		Map classMap = jsonConfig.getClassMap();
		List list = new ArrayList();
		int size = jsonArray.size();
		for (int i = 0; i < size; i++)
		{
			Object value = jsonArray.get(i);
			if (JSONUtils.isNull(value))
			{
				list.add(null);
				continue;
			}
			Class type = value.getClass();
			if (net/sf/json/JSONArray.isAssignableFrom(type))
			{
				list.add(toList((JSONArray)value, objectClass, classMap));
				continue;
			}
			if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || JSONUtils.isNumber(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				if (objectClass != null && !objectClass.isAssignableFrom(type))
					value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
				list.add(value);
				continue;
			}
			if (objectClass != null)
			{
				JsonConfig jsc = jsonConfig.copy();
				jsc.setRootClass(objectClass);
				jsc.setClassMap(classMap);
				list.add(JSONObject.toBean((JSONObject)value, jsc));
			} else
			{
				list.add(JSONObject.toBean((JSONObject)value));
			}
		}

		return list;
	}

	public static List toList(JSONArray jsonArray, Object root, JsonConfig jsonConfig)
	{
		if (jsonArray.size() == 0 || root == null)
			return new ArrayList();
		List list = new ArrayList();
		int size = jsonArray.size();
		for (int i = 0; i < size; i++)
		{
			Object value = jsonArray.get(i);
			if (JSONUtils.isNull(value))
			{
				list.add(null);
				continue;
			}
			Class type = value.getClass();
			if (net/sf/json/JSONArray.isAssignableFrom(type))
			{
				list.add(toList((JSONArray)value, root, jsonConfig));
				continue;
			}
			if (java/lang/String.isAssignableFrom(type) || java/lang/Boolean.isAssignableFrom(type) || JSONUtils.isNumber(type) || java/lang/Character.isAssignableFrom(type) || net/sf/json/JSONFunction.isAssignableFrom(type))
			{
				list.add(value);
				continue;
			}
			try
			{
				Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(root.getClass(), null);
				list.add(JSONObject.toBean((JSONObject)value, newRoot, jsonConfig));
			}
			catch (JSONException jsone)
			{
				throw jsone;
			}
			catch (Exception e)
			{
				throw new JSONException(e);
			}
		}

		return list;
	}

	private static JSONArray _fromArray(boolean array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Boolean b = array[i] ? Boolean.TRUE : Boolean.FALSE;
			jsonArray.addValue(b, jsonConfig);
			fireElementAddedEvent(i, b, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(byte array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Number n = JSONUtils.transformNumber(new Byte(array[i]));
			jsonArray.addValue(n, jsonConfig);
			fireElementAddedEvent(i, n, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(char array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Character c = new Character(array[i]);
			jsonArray.addValue(c, jsonConfig);
			fireElementAddedEvent(i, c, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(double array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		try
		{
			for (int i = 0; i < array.length; i++)
			{
				Double d = new Double(array[i]);
				JSONUtils.testValidity(d);
				jsonArray.addValue(d, jsonConfig);
				fireElementAddedEvent(i, d, jsonConfig);
			}

		}
		catch (JSONException jsone)
		{
			removeInstance(array);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(Enum e, JsonConfig jsonConfig)
	{
		if (addInstance(e))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(e);
		JSONException jsone;
		jsone;
		removeInstance(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException re;
		re;
		removeInstance(e);
		JSONException jsone = new JSONException(re);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		if (e != null)
		{
			jsonArray.addValue(e, jsonConfig);
			fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
		} else
		{
			JSONException jsone = new JSONException("enum value is null");
			removeInstance(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(e);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(float array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		try
		{
			for (int i = 0; i < array.length; i++)
			{
				Float f = new Float(array[i]);
				JSONUtils.testValidity(f);
				jsonArray.addValue(f, jsonConfig);
				fireElementAddedEvent(i, f, jsonConfig);
			}

		}
		catch (JSONException jsone)
		{
			removeInstance(array);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(int array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Number n = new Integer(array[i]);
			jsonArray.addValue(n, jsonConfig);
			fireElementAddedEvent(i, n, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(long array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Number n = JSONUtils.transformNumber(new Long(array[i]));
			jsonArray.addValue(n, jsonConfig);
			fireElementAddedEvent(i, n, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(Object array[], JsonConfig jsonConfig)
	{
		if (addInstance(((Object) (array))))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(((Object) (array)));
		JSONException jsone;
		jsone;
		removeInstance(((Object) (array)));
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(((Object) (array)));
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		try
		{
			for (int i = 0; i < array.length; i++)
			{
				Object element = array[i];
				jsonArray.addValue(element, jsonConfig);
				fireElementAddedEvent(i, jsonArray.get(i), jsonConfig);
			}

		}
		catch (JSONException jsone)
		{
			removeInstance(((Object) (array)));
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		catch (RuntimeException e)
		{
			removeInstance(((Object) (array)));
			JSONException jsone = new JSONException(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(((Object) (array)));
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromArray(short array[], JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < array.length; i++)
		{
			Number n = JSONUtils.transformNumber(new Short(array[i]));
			jsonArray.addValue(n, jsonConfig);
			fireElementAddedEvent(i, n, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromCollection(Collection collection, JsonConfig jsonConfig)
	{
		if (addInstance(collection))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(collection);
		JSONException jsone;
		jsone;
		removeInstance(collection);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(collection);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		try
		{
			int i = 0;
			for (Iterator elements = collection.iterator(); elements.hasNext(); fireElementAddedEvent(i, jsonArray.get(i++), jsonConfig))
			{
				Object element = elements.next();
				jsonArray.addValue(element, jsonConfig);
			}

		}
		catch (JSONException jsone)
		{
			removeInstance(collection);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		catch (RuntimeException e)
		{
			removeInstance(collection);
			JSONException jsone = new JSONException(e);
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
		removeInstance(collection);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromJSONArray(JSONArray array, JsonConfig jsonConfig)
	{
		if (addInstance(array))
			break MISSING_BLOCK_LABEL_49;
		return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
		JSONException jsone;
		jsone;
		removeInstance(array);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		RuntimeException e;
		e;
		removeInstance(array);
		JSONException jsone = new JSONException(e);
		fireErrorEvent(jsone, jsonConfig);
		throw jsone;
		fireArrayStartEvent(jsonConfig);
		JSONArray jsonArray = new JSONArray();
		int index = 0;
		Object element;
		for (Iterator elements = array.iterator(); elements.hasNext(); fireElementAddedEvent(index++, element, jsonConfig))
		{
			element = elements.next();
			jsonArray.addValue(element, jsonConfig);
		}

		removeInstance(array);
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
	}

	private static JSONArray _fromJSONString(JSONString string, JsonConfig jsonConfig)
	{
		return _fromJSONTokener(new JSONTokener(string.toJSONString()), jsonConfig);
	}

	private static JSONArray _fromJSONTokener(JSONTokener tokener, JsonConfig jsonConfig)
	{
		JSONArray jsonArray;
		int index;
		jsonArray = new JSONArray();
		index = 0;
		if (tokener.nextClean() != '[')
			throw tokener.syntaxError("A JSONArray text must start with '['");
		fireArrayStartEvent(jsonConfig);
		if (tokener.nextClean() != ']')
			break MISSING_BLOCK_LABEL_45;
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
		tokener.back();
_L6:
		if (tokener.nextClean() == ',')
		{
			tokener.back();
			jsonArray.elements.add(JSONNull.getInstance());
			fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
		} else
		{
			tokener.back();
			Object v = tokener.nextValue(jsonConfig);
			if (!JSONUtils.isFunctionHeader(v))
			{
				if ((v instanceof String) && JSONUtils.mayBeJSON((String)v))
					jsonArray.addValue((new StringBuilder()).append("\"").append(v).append("\"").toString(), jsonConfig);
				else
					jsonArray.addValue(v, jsonConfig);
				fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
			} else
			{
				String params = JSONUtils.getFunctionParams((String)v);
				int i = 0;
				StringBuffer sb = new StringBuffer();
				do
				{
					char ch = tokener.next();
					if (ch == 0)
						break;
					if (ch == '{')
						i++;
					if (ch == '}')
						i--;
					sb.append(ch);
				} while (i != 0);
				if (i != 0)
					throw tokener.syntaxError((new StringBuilder()).append("Unbalanced '{' or '}' on prop: ").append(v).toString());
				String text = sb.toString();
				text = text.substring(1, text.length() - 1).trim();
				jsonArray.addValue(new JSONFunction(params == null ? null : StringUtils.split(params, ","), text), jsonConfig);
				fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
			}
		}
		tokener.nextClean();
		JVM INSTR lookupswitch 3: default 428
	//	               44: 400
	//	               59: 400
	//	               93: 422;
		   goto _L1 _L2 _L2 _L3
_L2:
		if (tokener.nextClean() != ']') goto _L5; else goto _L4
_L4:
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
_L5:
		tokener.back();
		  goto _L6
_L3:
		fireArrayEndEvent(jsonConfig);
		return jsonArray;
_L1:
		try
		{
			throw tokener.syntaxError("Expected a ',' or ']'");
		}
		catch (JSONException jsone)
		{
			fireErrorEvent(jsone, jsonConfig);
			throw jsone;
		}
	}

	private static JSONArray _fromString(String string, JsonConfig jsonConfig)
	{
		return _fromJSONTokener(new JSONTokener(string), jsonConfig);
	}

	private static void processArrayDimensions(JSONArray jsonArray, List dims, int index)
	{
		if (dims.size() <= index)
		{
			dims.add(new Integer(jsonArray.size()));
		} else
		{
			int i = ((Integer)dims.get(index)).intValue();
			if (jsonArray.size() > i)
				dims.set(index, new Integer(jsonArray.size()));
		}
		Iterator i = jsonArray.iterator();
		do
		{
			if (!i.hasNext())
				break;
			Object item = i.next();
			if (item instanceof JSONArray)
				processArrayDimensions((JSONArray)item, dims, index + 1);
		} while (true);
	}

	public JSONArray()
	{
		elements = new ArrayList();
	}

	public void add(int index, Object value)
	{
		add(index, value, new JsonConfig());
	}

	public void add(int index, Object value, JsonConfig jsonConfig)
	{
		elements.add(index, processValue(value, jsonConfig));
	}

	public boolean add(Object value)
	{
		return add(value, new JsonConfig());
	}

	public boolean add(Object value, JsonConfig jsonConfig)
	{
		element(value, jsonConfig);
		return true;
	}

	public boolean addAll(Collection collection)
	{
		return addAll(collection, new JsonConfig());
	}

	public boolean addAll(Collection collection, JsonConfig jsonConfig)
	{
		if (collection == null || collection.size() == 0)
			return false;
		for (Iterator i = collection.iterator(); i.hasNext(); element(i.next(), jsonConfig));
		return true;
	}

	public boolean addAll(int index, Collection collection)
	{
		return addAll(index, collection, new JsonConfig());
	}

	public boolean addAll(int index, Collection collection, JsonConfig jsonConfig)
	{
		if (collection == null || collection.size() == 0)
			return false;
		int offset = 0;
		for (Iterator i = collection.iterator(); i.hasNext(); elements.add(index + offset++, processValue(i.next(), jsonConfig)));
		return true;
	}

	public void clear()
	{
		elements.clear();
	}

	public int compareTo(Object obj)
	{
		if (obj != null && (obj instanceof JSONArray))
		{
			JSONArray other = (JSONArray)obj;
			int size1 = size();
			int size2 = other.size();
			if (size1 < size2)
				return -1;
			if (size1 > size2)
				return 1;
			if (equals(other))
				return 0;
		}
		return -1;
	}

	public boolean contains(Object o)
	{
		return contains(o, new JsonConfig());
	}

	public boolean contains(Object o, JsonConfig jsonConfig)
	{
		return elements.contains(processValue(o, jsonConfig));
	}

	public boolean containsAll(Collection collection)
	{
		return containsAll(collection, new JsonConfig());
	}

	public boolean containsAll(Collection collection, JsonConfig jsonConfig)
	{
		return elements.containsAll(fromObject(collection, jsonConfig));
	}

	public JSONArray discard(int index)
	{
		elements.remove(index);
		return this;
	}

	public JSONArray discard(Object o)
	{
		elements.remove(o);
		return this;
	}

	public JSONArray element(boolean value)
	{
		return element(value ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE)));
	}

	public JSONArray element(Collection value)
	{
		return element(value, new JsonConfig());
	}

	public JSONArray element(Collection value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONArray)
		{
			elements.add(value);
			return this;
		} else
		{
			return element(((Collection) (_fromCollection(value, jsonConfig))));
		}
	}

	public JSONArray element(double value)
	{
		Double d = new Double(value);
		JSONUtils.testValidity(d);
		return element(d);
	}

	public JSONArray element(int value)
	{
		return element(new Integer(value));
	}

	public JSONArray element(int index, boolean value)
	{
		return element(index, value ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE)));
	}

	public JSONArray element(int index, Collection value)
	{
		return element(index, value, new JsonConfig());
	}

	public JSONArray element(int index, Collection value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONArray)
		{
			if (index < 0)
				throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] not found.").toString());
			if (index < size())
			{
				elements.set(index, value);
			} else
			{
				for (; index != size(); element(JSONNull.getInstance()));
				element(value, jsonConfig);
			}
			return this;
		} else
		{
			return element(index, ((Collection) (_fromCollection(value, jsonConfig))));
		}
	}

	public JSONArray element(int index, double value)
	{
		return element(index, new Double(value));
	}

	public JSONArray element(int index, int value)
	{
		return element(index, new Integer(value));
	}

	public JSONArray element(int index, long value)
	{
		return element(index, new Long(value));
	}

	public JSONArray element(int index, Map value)
	{
		return element(index, value, new JsonConfig());
	}

	public JSONArray element(int index, Map value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONObject)
		{
			if (index < 0)
				throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] not found.").toString());
			if (index < size())
			{
				elements.set(index, value);
			} else
			{
				for (; index != size(); element(JSONNull.getInstance()));
				element(value, jsonConfig);
			}
			return this;
		} else
		{
			return element(index, ((Map) (JSONObject.fromObject(value, jsonConfig))));
		}
	}

	public JSONArray element(int index, Object value)
	{
		return element(index, value, new JsonConfig());
	}

	public JSONArray element(int index, Object value, JsonConfig jsonConfig)
	{
		JSONUtils.testValidity(value);
		if (index < 0)
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] not found.").toString());
		if (index < size())
		{
			elements.set(index, processValue(value, jsonConfig));
		} else
		{
			for (; index != size(); element(JSONNull.getInstance()));
			element(value, jsonConfig);
		}
		return this;
	}

	public JSONArray element(int index, String value)
	{
		return element(index, value, new JsonConfig());
	}

	public JSONArray element(int index, String value, JsonConfig jsonConfig)
	{
		if (index < 0)
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] not found.").toString());
		if (index < size())
		{
			if (value == null)
				elements.set(index, "");
			else
			if (JSONUtils.mayBeJSON(value))
				try
				{
					elements.set(index, JSONSerializer.toJSON(value, jsonConfig));
				}
				catch (JSONException jsone)
				{
					elements.set(index, JSONUtils.stripQuotes(value));
				}
			else
				elements.set(index, JSONUtils.stripQuotes(value));
		} else
		{
			for (; index != size(); element(JSONNull.getInstance()));
			element(value, jsonConfig);
		}
		return this;
	}

	public JSONArray element(JSONNull value)
	{
		elements.add(value);
		return this;
	}

	public JSONArray element(JSONObject value)
	{
		elements.add(value);
		return this;
	}

	public JSONArray element(long value)
	{
		return element(JSONUtils.transformNumber(new Long(value)));
	}

	public JSONArray element(Map value)
	{
		return element(value, new JsonConfig());
	}

	public JSONArray element(Map value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONObject)
		{
			elements.add(value);
			return this;
		} else
		{
			return element(JSONObject.fromObject(value, jsonConfig));
		}
	}

	public JSONArray element(Object value)
	{
		return element(value, new JsonConfig());
	}

	public JSONArray element(Object value, JsonConfig jsonConfig)
	{
		return addValue(value, jsonConfig);
	}

	public JSONArray element(String value)
	{
		return element(value, new JsonConfig());
	}

	public JSONArray element(String value, JsonConfig jsonConfig)
	{
		if (value == null)
			elements.add("");
		else
		if (JSONUtils.hasQuotes(value))
			elements.add(value);
		else
		if (JSONNull.getInstance().equals(value))
			elements.add(JSONNull.getInstance());
		else
		if (JSONUtils.isJsonKeyword(value, jsonConfig))
		{
			if (jsonConfig.isJavascriptCompliant() && "undefined".equals(value))
				elements.add(JSONNull.getInstance());
			else
				elements.add(value);
		} else
		if (JSONUtils.mayBeJSON(value))
			try
			{
				elements.add(JSONSerializer.toJSON(value, jsonConfig));
			}
			catch (JSONException jsone)
			{
				elements.add(value);
			}
		else
			elements.add(value);
		return this;
	}

	public boolean equals(Object obj)
	{
		if (obj == this)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof JSONArray))
			return false;
		JSONArray other = (JSONArray)obj;
		if (other.size() != size())
			return false;
		int max = size();
		for (int i = 0; i < max; i++)
		{
			Object o1 = get(i);
			Object o2 = other.get(i);
			if (JSONNull.getInstance().equals(o1))
			{
				if (!JSONNull.getInstance().equals(o2))
					return false;
				continue;
			}
			if (JSONNull.getInstance().equals(o2))
				return false;
			if ((o1 instanceof JSONArray) && (o2 instanceof JSONArray))
			{
				JSONArray e = (JSONArray)o1;
				JSONArray a = (JSONArray)o2;
				if (!a.equals(e))
					return false;
				continue;
			}
			if ((o1 instanceof String) && (o2 instanceof JSONFunction))
			{
				if (!o1.equals(String.valueOf(o2)))
					return false;
				continue;
			}
			if ((o1 instanceof JSONFunction) && (o2 instanceof String))
			{
				if (!o2.equals(String.valueOf(o1)))
					return false;
				continue;
			}
			if ((o1 instanceof JSONObject) && (o2 instanceof JSONObject))
			{
				if (!o1.equals(o2))
					return false;
				continue;
			}
			if ((o1 instanceof JSONArray) && (o2 instanceof JSONArray))
			{
				if (!o1.equals(o2))
					return false;
				continue;
			}
			if ((o1 instanceof JSONFunction) && (o2 instanceof JSONFunction))
			{
				if (!o1.equals(o2))
					return false;
				continue;
			}
			if (o1 instanceof String)
			{
				if (!o1.equals(String.valueOf(o2)))
					return false;
				continue;
			}
			if (o2 instanceof String)
			{
				if (!o2.equals(String.valueOf(o1)))
					return false;
				continue;
			}
			net.sf.ezmorph.Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
			net.sf.ezmorph.Morpher m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
			if (m1 != null && m1 != IdentityObjectMorpher.getInstance())
			{
				if (!o1.equals(JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2)))
					return false;
				continue;
			}
			if (m2 != null && m2 != IdentityObjectMorpher.getInstance())
			{
				if (!JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1).equals(o2))
					return false;
				continue;
			}
			if (!o1.equals(o2))
				return false;
		}

		return true;
	}

	public Object get(int index)
	{
		return elements.get(index);
	}

	public boolean getBoolean(int index)
	{
		Object o = get(index);
		if (o != null)
		{
			if (o.equals(Boolean.FALSE) || (o instanceof String) && ((String)o).equalsIgnoreCase("false"))
				return false;
			if (o.equals(Boolean.TRUE) || (o instanceof String) && ((String)o).equalsIgnoreCase("true"))
				return true;
		}
		throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a Boolean.").toString());
	}

	public double getDouble(int index)
	{
		Object o;
		o = get(index);
		if (o == null)
			break MISSING_BLOCK_LABEL_68;
		return (o instanceof Number) ? ((Number)o).doubleValue() : Double.parseDouble((String)o);
		Exception e;
		e;
		throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a number.").toString());
		throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a number.").toString());
	}

	public int getInt(int index)
	{
		Object o = get(index);
		if (o != null)
			return (o instanceof Number) ? ((Number)o).intValue() : (int)getDouble(index);
		else
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a number.").toString());
	}

	public JSONArray getJSONArray(int index)
	{
		Object o = get(index);
		if (o != null && (o instanceof JSONArray))
			return (JSONArray)o;
		else
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a JSONArray.").toString());
	}

	public JSONObject getJSONObject(int index)
	{
		Object o = get(index);
		if (JSONNull.getInstance().equals(o))
			return new JSONObject(true);
		if (o instanceof JSONObject)
			return (JSONObject)o;
		else
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a JSONObject.").toString());
	}

	public long getLong(int index)
	{
		Object o = get(index);
		if (o != null)
			return (o instanceof Number) ? ((Number)o).longValue() : (long)getDouble(index);
		else
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] is not a number.").toString());
	}

	public String getString(int index)
	{
		Object o = get(index);
		if (o != null)
			return o.toString();
		else
			throw new JSONException((new StringBuilder()).append("JSONArray[").append(index).append("] not found.").toString());
	}

	public int hashCode()
	{
		int hashcode = 29;
		for (Iterator e = elements.iterator(); e.hasNext();)
		{
			Object element = e.next();
			hashcode += JSONUtils.hashCode(element);
		}

		return hashcode;
	}

	public int indexOf(Object o)
	{
		return elements.indexOf(o);
	}

	public boolean isArray()
	{
		return true;
	}

	public boolean isEmpty()
	{
		return elements.isEmpty();
	}

	public boolean isExpandElements()
	{
		return expandElements;
	}

	public Iterator iterator()
	{
		return new JSONArrayListIterator();
	}

	public String join(String separator)
	{
		return join(separator, false);
	}

	public String join(String separator, boolean stripQuotes)
	{
		int len = size();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < len; i++)
		{
			if (i > 0)
				sb.append(separator);
			String value = JSONUtils.valueToString(elements.get(i));
			sb.append(stripQuotes ? JSONUtils.stripQuotes(value) : value);
		}

		return sb.toString();
	}

	public int lastIndexOf(Object o)
	{
		return elements.lastIndexOf(o);
	}

	public ListIterator listIterator()
	{
		return listIterator(0);
	}

	public ListIterator listIterator(int index)
	{
		if (index < 0 || index > size())
			throw new IndexOutOfBoundsException((new StringBuilder()).append("Index: ").append(index).toString());
		else
			return new JSONArrayListIterator(index);
	}

	public Object opt(int index)
	{
		return index >= 0 && index < size() ? elements.get(index) : null;
	}

	public boolean optBoolean(int index)
	{
		return optBoolean(index, false);
	}

	public boolean optBoolean(int index, boolean defaultValue)
	{
		return getBoolean(index);
		Exception e;
		e;
		return defaultValue;
	}

	public double optDouble(int index)
	{
		return optDouble(index, (0.0D / 0.0D));
	}

	public double optDouble(int index, double defaultValue)
	{
		return getDouble(index);
		Exception e;
		e;
		return defaultValue;
	}

	public int optInt(int index)
	{
		return optInt(index, 0);
	}

	public int optInt(int index, int defaultValue)
	{
		return getInt(index);
		Exception e;
		e;
		return defaultValue;
	}

	public JSONArray optJSONArray(int index)
	{
		Object o = opt(index);
		return (o instanceof JSONArray) ? (JSONArray)o : null;
	}

	public JSONObject optJSONObject(int index)
	{
		Object o = opt(index);
		return (o instanceof JSONObject) ? (JSONObject)o : null;
	}

	public long optLong(int index)
	{
		return optLong(index, 0L);
	}

	public long optLong(int index, long defaultValue)
	{
		return getLong(index);
		Exception e;
		e;
		return defaultValue;
	}

	public String optString(int index)
	{
		return optString(index, "");
	}

	public String optString(int index, String defaultValue)
	{
		Object o = opt(index);
		return o == null ? defaultValue : o.toString();
	}

	public Object remove(int index)
	{
		return elements.remove(index);
	}

	public boolean remove(Object o)
	{
		return elements.remove(o);
	}

	public boolean removeAll(Collection collection)
	{
		return removeAll(collection, new JsonConfig());
	}

	public boolean removeAll(Collection collection, JsonConfig jsonConfig)
	{
		return elements.removeAll(fromObject(collection, jsonConfig));
	}

	public boolean retainAll(Collection collection)
	{
		return retainAll(collection, new JsonConfig());
	}

	public boolean retainAll(Collection collection, JsonConfig jsonConfig)
	{
		return elements.retainAll(fromObject(collection, jsonConfig));
	}

	public Object set(int index, Object value)
	{
		return set(index, value, new JsonConfig());
	}

	public Object set(int index, Object value, JsonConfig jsonConfig)
	{
		Object previous = get(index);
		element(index, value, jsonConfig);
		return previous;
	}

	public void setExpandElements(boolean expandElements)
	{
		this.expandElements = expandElements;
	}

	public int size()
	{
		return elements.size();
	}

	public List subList(int fromIndex, int toIndex)
	{
		return elements.subList(fromIndex, toIndex);
	}

	public Object[] toArray()
	{
		return elements.toArray();
	}

	public Object[] toArray(Object array[])
	{
		return elements.toArray(array);
	}

	public JSONObject toJSONObject(JSONArray names)
	{
		if (names == null || names.size() == 0 || size() == 0)
			return null;
		JSONObject jo = new JSONObject();
		for (int i = 0; i < names.size(); i++)
			jo.element(names.getString(i), opt(i));

		return jo;
	}

	public String toString()
	{
		return (new StringBuilder()).append('[').append(join(",")).append(']').toString();
		Exception e;
		e;
		return null;
	}

	public String toString(int indentFactor)
	{
		if (indentFactor == 0)
			return toString();
		else
			return toString(indentFactor, 0);
	}

	public String toString(int indentFactor, int indent)
	{
		int len = size();
		if (len == 0)
			return "[]";
		if (indentFactor == 0)
			return toString();
		StringBuffer sb = new StringBuffer("[");
		if (len == 1)
		{
			sb.append(JSONUtils.valueToString(elements.get(0), indentFactor, indent));
		} else
		{
			int newindent = indent + indentFactor;
			sb.append('\n');
			for (int i = 0; i < len; i++)
			{
				if (i > 0)
					sb.append(",\n");
				for (int j = 0; j < newindent; j++)
					sb.append(' ');

				sb.append(JSONUtils.valueToString(elements.get(i), indentFactor, newindent));
			}

			sb.append('\n');
			for (int i = 0; i < indent; i++)
				sb.append(' ');

			for (int i = 0; i < indent; i++)
				sb.insert(0, ' ');

		}
		sb.append(']');
		return sb.toString();
	}

	public Writer write(Writer writer)
	{
		boolean b = false;
		int len = size();
		writer.write(91);
		for (int i = 0; i < len; i++)
		{
			if (b)
				writer.write(44);
			Object v = elements.get(i);
			if (v instanceof JSONObject)
				((JSONObject)v).write(writer);
			else
			if (v instanceof JSONArray)
				((JSONArray)v).write(writer);
			else
				writer.write(JSONUtils.valueToString(v));
			b = true;
		}

		writer.write(93);
		return writer;
		IOException e;
		e;
		throw new JSONException(e);
	}

	protected JSONArray addString(String str)
	{
		if (str != null)
			elements.add(str);
		return this;
	}

	private JSONArray _addValue(Object value, JsonConfig jsonConfig)
	{
		elements.add(value);
		return this;
	}

	protected Object _processValue(Object value, JsonConfig jsonConfig)
	{
		if (value instanceof JSONTokener)
			return _fromJSONTokener((JSONTokener)value, jsonConfig);
		if (value != null && java/lang/Enum.isAssignableFrom(value.getClass()))
			return ((Enum)value).name();
		if ((value instanceof Annotation) || value != null && value.getClass().isAnnotation())
			throw new JSONException("Unsupported type");
		else
			return super._processValue(value, jsonConfig);
	}

	private JSONArray addValue(Object value, JsonConfig jsonConfig)
	{
		return _addValue(processValue(value, jsonConfig), jsonConfig);
	}

	private Object processValue(Object value, JsonConfig jsonConfig)
	{
		if (value != null)
		{
			JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(value.getClass());
			if (jsonValueProcessor != null)
			{
				value = jsonValueProcessor.processArrayValue(value, jsonConfig);
				if (!JsonVerifier.isValidJsonValue(value))
					throw new JSONException((new StringBuilder()).append("Value is not a valid JSON value. ").append(value).toString());
			}
		}
		return _processValue(value, jsonConfig);
	}
}
