// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MappingPropertyFilter.java

package net.sf.json.filters;

import java.util.*;
import net.sf.json.util.PropertyFilter;

public abstract class MappingPropertyFilter
	implements PropertyFilter
{

	private Map filters;

	public MappingPropertyFilter()
	{
		this(null);
	}

	public MappingPropertyFilter(Map filters)
	{
		this.filters = new HashMap();
		if (filters != null)
		{
			Iterator i = filters.entrySet().iterator();
			do
			{
				if (!i.hasNext())
					break;
				java.util.Map.Entry entry = (java.util.Map.Entry)i.next();
				Object key = entry.getKey();
				Object filter = entry.getValue();
				if (filter instanceof PropertyFilter)
					this.filters.put(key, filter);
			} while (true);
		}
	}

	public void addPropertyFilter(Object target, PropertyFilter filter)
	{
		if (filter != null)
			filters.put(target, filter);
	}

	public boolean apply(Object source, String name, Object value)
	{
		for (Iterator i = filters.entrySet().iterator(); i.hasNext();)
		{
			java.util.Map.Entry entry = (java.util.Map.Entry)i.next();
			Object key = entry.getKey();
			if (keyMatches(key, source, name, value))
			{
				PropertyFilter filter = (PropertyFilter)entry.getValue();
				return filter.apply(source, name, value);
			}
		}

		return false;
	}

	public void removePropertyFilter(Object target)
	{
		if (target != null)
			filters.remove(target);
	}

	protected abstract boolean keyMatches(Object obj, Object obj1, String s, Object obj2);
}
