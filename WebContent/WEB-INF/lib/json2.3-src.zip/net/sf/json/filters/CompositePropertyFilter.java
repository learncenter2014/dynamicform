// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CompositePropertyFilter.java

package net.sf.json.filters;

import java.util.*;
import net.sf.json.util.PropertyFilter;

public class CompositePropertyFilter
	implements PropertyFilter
{

	private List filters;

	public CompositePropertyFilter()
	{
		this(null);
	}

	public CompositePropertyFilter(List filters)
	{
		this.filters = new ArrayList();
		if (filters != null)
		{
			Iterator i = filters.iterator();
			do
			{
				if (!i.hasNext())
					break;
				Object filter = i.next();
				if (filter instanceof PropertyFilter)
					this.filters.add(filter);
			} while (true);
		}
	}

	public void addPropertyFilter(PropertyFilter filter)
	{
		if (filter != null)
			filters.add(filter);
	}

	public boolean apply(Object source, String name, Object value)
	{
		for (Iterator i = filters.iterator(); i.hasNext();)
		{
			PropertyFilter filter = (PropertyFilter)i.next();
			if (filter.apply(source, name, value))
				return true;
		}

		return false;
	}

	public void removePropertyFilter(PropertyFilter filter)
	{
		if (filter != null)
			filters.remove(filter);
	}
}
