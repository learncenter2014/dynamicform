// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NotPropertyFilter.java

package net.sf.json.filters;

import net.sf.json.util.PropertyFilter;

public class NotPropertyFilter
	implements PropertyFilter
{

	private PropertyFilter filter;

	public NotPropertyFilter(PropertyFilter filter)
	{
		this.filter = filter;
	}

	public boolean apply(Object source, String name, Object value)
	{
		if (filter != null)
			return !filter.apply(source, name, value);
		else
			return false;
	}
}
