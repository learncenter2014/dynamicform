// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FalsePropertyFilter.java

package net.sf.json.filters;

import net.sf.json.util.PropertyFilter;

public class FalsePropertyFilter
	implements PropertyFilter
{

	public FalsePropertyFilter()
	{
	}

	public boolean apply(Object source, String name, Object value)
	{
		return false;
	}
}
