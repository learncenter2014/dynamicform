// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AndPropertyFilter.java

package net.sf.json.filters;

import net.sf.json.util.PropertyFilter;

public class AndPropertyFilter
	implements PropertyFilter
{

	private PropertyFilter filter1;
	private PropertyFilter filter2;

	public AndPropertyFilter(PropertyFilter filter1, PropertyFilter filter2)
	{
		this.filter1 = filter1;
		this.filter2 = filter2;
	}

	public boolean apply(Object source, String name, Object value)
	{
		return filter1 != null && filter1.apply(source, name, value) && filter2 != null && filter2.apply(source, name, value);
	}
}
