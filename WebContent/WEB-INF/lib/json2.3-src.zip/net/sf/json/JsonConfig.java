// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonConfig.java

package net.sf.json;

import java.util.*;
import net.sf.json.processors.DefaultDefaultValueProcessor;
import net.sf.json.processors.DefaultValueProcessor;
import net.sf.json.processors.DefaultValueProcessorMatcher;
import net.sf.json.processors.JsonBeanProcessor;
import net.sf.json.processors.JsonBeanProcessorMatcher;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.processors.JsonValueProcessorMatcher;
import net.sf.json.processors.PropertyNameProcessor;
import net.sf.json.processors.PropertyNameProcessorMatcher;
import net.sf.json.util.CycleDetectionStrategy;
import net.sf.json.util.JavaIdentifierTransformer;
import net.sf.json.util.JsonEventListener;
import net.sf.json.util.NewBeanInstanceStrategy;
import net.sf.json.util.PropertyExclusionClassMatcher;
import net.sf.json.util.PropertyFilter;
import net.sf.json.util.PropertySetStrategy;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;

// Referenced classes of package net.sf.json:
//			JSONException

public class JsonConfig
{

	public static final DefaultValueProcessorMatcher DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
	public static final JsonBeanProcessorMatcher DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
	public static final JsonValueProcessorMatcher DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
	public static final NewBeanInstanceStrategy DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
	public static final PropertyExclusionClassMatcher DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
	public static final PropertyNameProcessorMatcher DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
	public static final int MODE_LIST = 1;
	public static final int MODE_OBJECT_ARRAY = 2;
	public static final int MODE_SET = 2;
	private static final Class DEFAULT_COLLECTION_TYPE;
	private static final CycleDetectionStrategy DEFAULT_CYCLE_DETECTION_STRATEGY;
	private static final String DEFAULT_EXCLUDES[] = {
		"class", "declaringClass", "metaClass"
	};
	private static final JavaIdentifierTransformer DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
	private static final DefaultValueProcessor DEFAULT_VALUE_PROCESSOR = new DefaultDefaultValueProcessor();
	private static final String EMPTY_EXCLUDES[] = new String[0];
	private int arrayMode;
	private MultiKeyMap beanKeyMap;
	private Map beanProcessorMap;
	private MultiKeyMap beanTypeMap;
	private Map classMap;
	private Class collectionType;
	private CycleDetectionStrategy cycleDetectionStrategy;
	private Map defaultValueMap;
	private DefaultValueProcessorMatcher defaultValueProcessorMatcher;
	private Class enclosedType;
	private List eventListeners;
	private String excludes[];
	private Map exclusionMap;
	private boolean handleJettisonEmptyElement;
	private boolean handleJettisonSingleElementArray;
	private boolean ignoreDefaultExcludes;
	private boolean ignoreTransientFields;
	private boolean ignorePublicFields;
	private boolean javascriptCompliant;
	private JavaIdentifierTransformer javaIdentifierTransformer;
	private PropertyFilter javaPropertyFilter;
	private Map javaPropertyNameProcessorMap;
	private PropertyNameProcessorMatcher javaPropertyNameProcessorMatcher;
	private JsonBeanProcessorMatcher jsonBeanProcessorMatcher;
	private PropertyFilter jsonPropertyFilter;
	private Map jsonPropertyNameProcessorMap;
	private PropertyNameProcessorMatcher jsonPropertyNameProcessorMatcher;
	private JsonValueProcessorMatcher jsonValueProcessorMatcher;
	private Map keyMap;
	private NewBeanInstanceStrategy newBeanInstanceStrategy;
	private PropertyExclusionClassMatcher propertyExclusionClassMatcher;
	private PropertySetStrategy propertySetStrategy;
	private Class rootClass;
	private boolean skipJavaIdentifierTransformationInMapKeys;
	private boolean triggerEvents;
	private Map typeMap;
	private List ignoreFieldAnnotations;
	private boolean allowNonStringKeys;

	public JsonConfig()
	{
		arrayMode = 1;
		beanKeyMap = new MultiKeyMap();
		beanProcessorMap = new HashMap();
		beanTypeMap = new MultiKeyMap();
		collectionType = DEFAULT_COLLECTION_TYPE;
		cycleDetectionStrategy = DEFAULT_CYCLE_DETECTION_STRATEGY;
		defaultValueMap = new HashMap();
		defaultValueProcessorMatcher = DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
		eventListeners = new ArrayList();
		excludes = EMPTY_EXCLUDES;
		exclusionMap = new HashMap();
		ignorePublicFields = true;
		javaIdentifierTransformer = DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
		javaPropertyNameProcessorMap = new HashMap();
		javaPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
		jsonBeanProcessorMatcher = DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
		jsonPropertyNameProcessorMap = new HashMap();
		jsonPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
		jsonValueProcessorMatcher = DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
		keyMap = new HashMap();
		newBeanInstanceStrategy = DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
		propertyExclusionClassMatcher = DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
		typeMap = new HashMap();
		ignoreFieldAnnotations = new ArrayList();
		allowNonStringKeys = false;
	}

	public synchronized void addJsonEventListener(JsonEventListener listener)
	{
		if (!eventListeners.contains(listener))
			eventListeners.add(listener);
	}

	public void clearJavaPropertyNameProcessors()
	{
		javaPropertyNameProcessorMap.clear();
	}

	public void clearJsonBeanProcessors()
	{
		beanProcessorMap.clear();
	}

	public synchronized void clearJsonEventListeners()
	{
		eventListeners.clear();
	}

	public void clearJsonPropertyNameProcessors()
	{
		jsonPropertyNameProcessorMap.clear();
	}

	public void clearJsonValueProcessors()
	{
		beanKeyMap.clear();
		beanTypeMap.clear();
		keyMap.clear();
		typeMap.clear();
	}

	public void clearPropertyExclusions()
	{
		exclusionMap.clear();
	}

	/**
	 * @deprecated Method clearPropertyNameProcessors is deprecated
	 */

	public void clearPropertyNameProcessors()
	{
		clearJavaPropertyNameProcessors();
	}

	public JsonConfig copy()
	{
		JsonConfig jsc = new JsonConfig();
		jsc.beanKeyMap.putAll(beanKeyMap);
		jsc.beanTypeMap.putAll(beanTypeMap);
		jsc.classMap = new HashMap();
		if (classMap != null)
			jsc.classMap.putAll(classMap);
		jsc.cycleDetectionStrategy = cycleDetectionStrategy;
		if (eventListeners != null)
			jsc.eventListeners.addAll(eventListeners);
		if (excludes != null)
		{
			jsc.excludes = new String[excludes.length];
			System.arraycopy(excludes, 0, jsc.excludes, 0, excludes.length);
		}
		jsc.handleJettisonEmptyElement = handleJettisonEmptyElement;
		jsc.handleJettisonSingleElementArray = handleJettisonSingleElementArray;
		jsc.ignoreDefaultExcludes = ignoreDefaultExcludes;
		jsc.ignoreTransientFields = ignoreTransientFields;
		jsc.ignorePublicFields = ignorePublicFields;
		jsc.javaIdentifierTransformer = javaIdentifierTransformer;
		jsc.javascriptCompliant = javascriptCompliant;
		jsc.keyMap.putAll(keyMap);
		jsc.beanProcessorMap.putAll(beanProcessorMap);
		jsc.rootClass = rootClass;
		jsc.skipJavaIdentifierTransformationInMapKeys = skipJavaIdentifierTransformationInMapKeys;
		jsc.triggerEvents = triggerEvents;
		jsc.typeMap.putAll(typeMap);
		jsc.jsonPropertyFilter = jsonPropertyFilter;
		jsc.javaPropertyFilter = javaPropertyFilter;
		jsc.jsonBeanProcessorMatcher = jsonBeanProcessorMatcher;
		jsc.newBeanInstanceStrategy = newBeanInstanceStrategy;
		jsc.defaultValueProcessorMatcher = defaultValueProcessorMatcher;
		jsc.defaultValueMap.putAll(defaultValueMap);
		jsc.propertySetStrategy = propertySetStrategy;
		jsc.collectionType = collectionType;
		jsc.enclosedType = enclosedType;
		jsc.jsonValueProcessorMatcher = jsonValueProcessorMatcher;
		jsc.javaPropertyNameProcessorMatcher = javaPropertyNameProcessorMatcher;
		jsc.javaPropertyNameProcessorMap.putAll(javaPropertyNameProcessorMap);
		jsc.jsonPropertyNameProcessorMatcher = jsonPropertyNameProcessorMatcher;
		jsc.jsonPropertyNameProcessorMap.putAll(jsonPropertyNameProcessorMap);
		jsc.propertyExclusionClassMatcher = propertyExclusionClassMatcher;
		jsc.exclusionMap.putAll(exclusionMap);
		jsc.ignoreFieldAnnotations.addAll(ignoreFieldAnnotations);
		jsc.allowNonStringKeys = allowNonStringKeys;
		return jsc;
	}

	public void disableEventTriggering()
	{
		triggerEvents = false;
	}

	public void enableEventTriggering()
	{
		triggerEvents = true;
	}

	public DefaultValueProcessor findDefaultValueProcessor(Class target)
	{
		if (!defaultValueMap.isEmpty())
		{
			Object key = defaultValueProcessorMatcher.getMatch(target, defaultValueMap.keySet());
			DefaultValueProcessor processor = (DefaultValueProcessor)defaultValueMap.get(key);
			if (processor != null)
				return processor;
		}
		return DEFAULT_VALUE_PROCESSOR;
	}

	public PropertyNameProcessor findJavaPropertyNameProcessor(Class beanClass)
	{
		if (!javaPropertyNameProcessorMap.isEmpty())
		{
			Object key = javaPropertyNameProcessorMatcher.getMatch(beanClass, javaPropertyNameProcessorMap.keySet());
			return (PropertyNameProcessor)javaPropertyNameProcessorMap.get(key);
		} else
		{
			return null;
		}
	}

	public JsonBeanProcessor findJsonBeanProcessor(Class target)
	{
		if (!beanProcessorMap.isEmpty())
		{
			Object key = jsonBeanProcessorMatcher.getMatch(target, beanProcessorMap.keySet());
			return (JsonBeanProcessor)beanProcessorMap.get(key);
		} else
		{
			return null;
		}
	}

	public PropertyNameProcessor findJsonPropertyNameProcessor(Class beanClass)
	{
		if (!jsonPropertyNameProcessorMap.isEmpty())
		{
			Object key = jsonPropertyNameProcessorMatcher.getMatch(beanClass, jsonPropertyNameProcessorMap.keySet());
			return (PropertyNameProcessor)jsonPropertyNameProcessorMap.get(key);
		} else
		{
			return null;
		}
	}

	public JsonValueProcessor findJsonValueProcessor(Class propertyType)
	{
		if (!typeMap.isEmpty())
		{
			Object key = jsonValueProcessorMatcher.getMatch(propertyType, typeMap.keySet());
			return (JsonValueProcessor)typeMap.get(key);
		} else
		{
			return null;
		}
	}

	public JsonValueProcessor findJsonValueProcessor(Class beanClass, Class propertyType, String key)
	{
		JsonValueProcessor jsonValueProcessor = null;
		jsonValueProcessor = (JsonValueProcessor)beanKeyMap.get(beanClass, key);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		jsonValueProcessor = (JsonValueProcessor)beanTypeMap.get(beanClass, propertyType);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		jsonValueProcessor = (JsonValueProcessor)keyMap.get(key);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		Object tkey = jsonValueProcessorMatcher.getMatch(propertyType, typeMap.keySet());
		jsonValueProcessor = (JsonValueProcessor)typeMap.get(tkey);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		else
			return null;
	}

	public JsonValueProcessor findJsonValueProcessor(Class propertyType, String key)
	{
		JsonValueProcessor jsonValueProcessor = null;
		jsonValueProcessor = (JsonValueProcessor)keyMap.get(key);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		Object tkey = jsonValueProcessorMatcher.getMatch(propertyType, typeMap.keySet());
		jsonValueProcessor = (JsonValueProcessor)typeMap.get(tkey);
		if (jsonValueProcessor != null)
			return jsonValueProcessor;
		else
			return null;
	}

	/**
	 * @deprecated Method findPropertyNameProcessor is deprecated
	 */

	public PropertyNameProcessor findPropertyNameProcessor(Class beanClass)
	{
		return findJavaPropertyNameProcessor(beanClass);
	}

	public int getArrayMode()
	{
		return arrayMode;
	}

	public Map getClassMap()
	{
		return classMap;
	}

	public Class getCollectionType()
	{
		return collectionType;
	}

	public CycleDetectionStrategy getCycleDetectionStrategy()
	{
		return cycleDetectionStrategy;
	}

	public DefaultValueProcessorMatcher getDefaultValueProcessorMatcher()
	{
		return defaultValueProcessorMatcher;
	}

	public Class getEnclosedType()
	{
		return enclosedType;
	}

	public String[] getExcludes()
	{
		return excludes;
	}

	public JavaIdentifierTransformer getJavaIdentifierTransformer()
	{
		return javaIdentifierTransformer;
	}

	public PropertyFilter getJavaPropertyFilter()
	{
		return javaPropertyFilter;
	}

	public PropertyNameProcessorMatcher getJavaPropertyNameProcessorMatcher()
	{
		return javaPropertyNameProcessorMatcher;
	}

	public JsonBeanProcessorMatcher getJsonBeanProcessorMatcher()
	{
		return jsonBeanProcessorMatcher;
	}

	public synchronized List getJsonEventListeners()
	{
		return eventListeners;
	}

	public PropertyFilter getJsonPropertyFilter()
	{
		return jsonPropertyFilter;
	}

	public PropertyNameProcessorMatcher getJsonPropertyNameProcessorMatcher()
	{
		return javaPropertyNameProcessorMatcher;
	}

	public JsonValueProcessorMatcher getJsonValueProcessorMatcher()
	{
		return jsonValueProcessorMatcher;
	}

	public Collection getMergedExcludes()
	{
		Collection exclusions = new HashSet();
		for (int i = 0; i < excludes.length; i++)
		{
			String exclusion = excludes[i];
			if (!StringUtils.isBlank(excludes[i]))
				exclusions.add(exclusion.trim());
		}

		if (!ignoreDefaultExcludes)
		{
			for (int i = 0; i < DEFAULT_EXCLUDES.length; i++)
				if (!exclusions.contains(DEFAULT_EXCLUDES[i]))
					exclusions.add(DEFAULT_EXCLUDES[i]);

		}
		return exclusions;
	}

	public Collection getMergedExcludes(Class target)
	{
		if (target == null)
			return getMergedExcludes();
		Collection exclusionSet = getMergedExcludes();
		if (!exclusionMap.isEmpty())
		{
			Object key = propertyExclusionClassMatcher.getMatch(target, exclusionMap.keySet());
			Set set = (Set)exclusionMap.get(key);
			if (set != null && !set.isEmpty())
			{
				Iterator i = set.iterator();
				do
				{
					if (!i.hasNext())
						break;
					Object e = i.next();
					if (!exclusionSet.contains(e))
						exclusionSet.add(e);
				} while (true);
			}
		}
		return exclusionSet;
	}

	public NewBeanInstanceStrategy getNewBeanInstanceStrategy()
	{
		return newBeanInstanceStrategy;
	}

	public PropertyExclusionClassMatcher getPropertyExclusionClassMatcher()
	{
		return propertyExclusionClassMatcher;
	}

	/**
	 * @deprecated Method getPropertyNameProcessorMatcher is deprecated
	 */

	public PropertyNameProcessorMatcher getPropertyNameProcessorMatcher()
	{
		return getJavaPropertyNameProcessorMatcher();
	}

	public PropertySetStrategy getPropertySetStrategy()
	{
		return propertySetStrategy;
	}

	public Class getRootClass()
	{
		return rootClass;
	}

	public boolean isAllowNonStringKeys()
	{
		return allowNonStringKeys;
	}

	public boolean isEventTriggeringEnabled()
	{
		return triggerEvents;
	}

	public boolean isHandleJettisonEmptyElement()
	{
		return handleJettisonEmptyElement;
	}

	public boolean isHandleJettisonSingleElementArray()
	{
		return handleJettisonSingleElementArray;
	}

	public boolean isIgnoreDefaultExcludes()
	{
		return ignoreDefaultExcludes;
	}

	public boolean isIgnoreJPATransient()
	{
		return ignoreFieldAnnotations.contains("javax.persistence.Transient");
	}

	public boolean isIgnoreTransientFields()
	{
		return ignoreTransientFields;
	}

	public boolean isIgnorePublicFields()
	{
		return ignorePublicFields;
	}

	public boolean isJavascriptCompliant()
	{
		return javascriptCompliant;
	}

	public boolean isSkipJavaIdentifierTransformationInMapKeys()
	{
		return skipJavaIdentifierTransformationInMapKeys;
	}

	public void registerDefaultValueProcessor(Class target, DefaultValueProcessor defaultValueProcessor)
	{
		if (target != null && defaultValueProcessor != null)
			defaultValueMap.put(target, defaultValueProcessor);
	}

	public void registerJavaPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor)
	{
		if (target != null && propertyNameProcessor != null)
			javaPropertyNameProcessorMap.put(target, propertyNameProcessor);
	}

	public void registerJsonBeanProcessor(Class target, JsonBeanProcessor jsonBeanProcessor)
	{
		if (target != null && jsonBeanProcessor != null)
			beanProcessorMap.put(target, jsonBeanProcessor);
	}

	public void registerJsonPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor)
	{
		if (target != null && propertyNameProcessor != null)
			jsonPropertyNameProcessorMap.put(target, propertyNameProcessor);
	}

	public void registerJsonValueProcessor(Class beanClass, Class propertyType, JsonValueProcessor jsonValueProcessor)
	{
		if (beanClass != null && propertyType != null && jsonValueProcessor != null)
			beanTypeMap.put(beanClass, propertyType, jsonValueProcessor);
	}

	public void registerJsonValueProcessor(Class propertyType, JsonValueProcessor jsonValueProcessor)
	{
		if (propertyType != null && jsonValueProcessor != null)
			typeMap.put(propertyType, jsonValueProcessor);
	}

	public void registerJsonValueProcessor(Class beanClass, String key, JsonValueProcessor jsonValueProcessor)
	{
		if (beanClass != null && key != null && jsonValueProcessor != null)
			beanKeyMap.put(beanClass, key, jsonValueProcessor);
	}

	public void registerJsonValueProcessor(String key, JsonValueProcessor jsonValueProcessor)
	{
		if (key != null && jsonValueProcessor != null)
			keyMap.put(key, jsonValueProcessor);
	}

	public void registerPropertyExclusion(Class target, String propertyName)
	{
		if (target != null && propertyName != null)
		{
			Set set = (Set)exclusionMap.get(target);
			if (set == null)
			{
				set = new HashSet();
				exclusionMap.put(target, set);
			}
			if (!set.contains(propertyName))
				set.add(propertyName);
		}
	}

	public void registerPropertyExclusions(Class target, String properties[])
	{
		if (target != null && properties != null && properties.length > 0)
		{
			Set set = (Set)exclusionMap.get(target);
			if (set == null)
			{
				set = new HashSet();
				exclusionMap.put(target, set);
			}
			for (int i = 0; i < properties.length; i++)
				if (!set.contains(properties[i]))
					set.add(properties[i]);

		}
	}

	/**
	 * @deprecated Method registerPropertyNameProcessor is deprecated
	 */

	public void registerPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor)
	{
		registerJavaPropertyNameProcessor(target, propertyNameProcessor);
	}

	public synchronized void removeJsonEventListener(JsonEventListener listener)
	{
		eventListeners.remove(listener);
	}

	public void reset()
	{
		excludes = EMPTY_EXCLUDES;
		ignoreDefaultExcludes = false;
		ignoreTransientFields = false;
		ignorePublicFields = true;
		javascriptCompliant = false;
		javaIdentifierTransformer = DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
		cycleDetectionStrategy = DEFAULT_CYCLE_DETECTION_STRATEGY;
		skipJavaIdentifierTransformationInMapKeys = false;
		triggerEvents = false;
		handleJettisonEmptyElement = false;
		handleJettisonSingleElementArray = false;
		arrayMode = 1;
		rootClass = null;
		classMap = null;
		keyMap.clear();
		typeMap.clear();
		beanKeyMap.clear();
		beanTypeMap.clear();
		jsonPropertyFilter = null;
		javaPropertyFilter = null;
		jsonBeanProcessorMatcher = DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
		newBeanInstanceStrategy = DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
		defaultValueProcessorMatcher = DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
		defaultValueMap.clear();
		propertySetStrategy = null;
		collectionType = DEFAULT_COLLECTION_TYPE;
		enclosedType = null;
		jsonValueProcessorMatcher = DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
		javaPropertyNameProcessorMap.clear();
		javaPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
		jsonPropertyNameProcessorMap.clear();
		jsonPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
		beanProcessorMap.clear();
		propertyExclusionClassMatcher = DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
		exclusionMap.clear();
		ignoreFieldAnnotations.clear();
		allowNonStringKeys = false;
	}

	public void setAllowNonStringKeys(boolean allowNonStringKeys)
	{
		this.allowNonStringKeys = allowNonStringKeys;
	}

	public void setArrayMode(int arrayMode)
	{
		if (arrayMode == 2)
			this.arrayMode = arrayMode;
		else
		if (arrayMode == 2)
		{
			this.arrayMode = arrayMode;
			collectionType = java.util.Set.class;
		} else
		{
			this.arrayMode = 1;
			enclosedType = DEFAULT_COLLECTION_TYPE;
		}
	}

	public void setClassMap(Map classMap)
	{
		this.classMap = classMap;
	}

	public void setCollectionType(Class collectionType)
	{
		if (collectionType != null)
		{
			if (!(java.util.Collection.class).isAssignableFrom(collectionType))
				throw new JSONException("The configured collectionType is not a Collection: " + collectionType.getName());
			this.collectionType = collectionType;
		} else
		{
			collectionType = DEFAULT_COLLECTION_TYPE;
		}
	}

	public void setCycleDetectionStrategy(CycleDetectionStrategy cycleDetectionStrategy)
	{
		this.cycleDetectionStrategy = cycleDetectionStrategy != null ? cycleDetectionStrategy : DEFAULT_CYCLE_DETECTION_STRATEGY;
	}

	public void setDefaultValueProcessorMatcher(DefaultValueProcessorMatcher defaultValueProcessorMatcher)
	{
		this.defaultValueProcessorMatcher = defaultValueProcessorMatcher != null ? defaultValueProcessorMatcher : DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
	}

	public void setEnclosedType(Class enclosedType)
	{
		this.enclosedType = enclosedType;
	}

	public void setExcludes(String excludes[])
	{
		this.excludes = excludes != null ? excludes : EMPTY_EXCLUDES;
	}

	public void setHandleJettisonEmptyElement(boolean handleJettisonEmptyElement)
	{
		this.handleJettisonEmptyElement = handleJettisonEmptyElement;
	}

	public void setHandleJettisonSingleElementArray(boolean handleJettisonSingleElementArray)
	{
		this.handleJettisonSingleElementArray = handleJettisonSingleElementArray;
	}

	public void setIgnoreDefaultExcludes(boolean ignoreDefaultExcludes)
	{
		this.ignoreDefaultExcludes = ignoreDefaultExcludes;
	}

	public void setIgnoreJPATransient(boolean ignoreJPATransient)
	{
		if (ignoreJPATransient)
			addIgnoreFieldAnnotation("javax.persistence.Transient");
		else
			removeIgnoreFieldAnnotation("javax.persistence.Transient");
	}

	public void addIgnoreFieldAnnotation(String annotationClassName)
	{
		if (annotationClassName != null && !ignoreFieldAnnotations.contains(annotationClassName))
			ignoreFieldAnnotations.add(annotationClassName);
	}

	public void removeIgnoreFieldAnnotation(String annotationClassName)
	{
		if (annotationClassName != null)
			ignoreFieldAnnotations.remove(annotationClassName);
	}

	public void addIgnoreFieldAnnotation(Class annotationClass)
	{
		if (annotationClass != null && !ignoreFieldAnnotations.contains(annotationClass.getName()))
			ignoreFieldAnnotations.add(annotationClass.getName());
	}

	public void removeIgnoreFieldAnnotation(Class annotationClass)
	{
		if (annotationClass != null)
			ignoreFieldAnnotations.remove(annotationClass.getName());
	}

	public List getIgnoreFieldAnnotations()
	{
		return Collections.unmodifiableList(ignoreFieldAnnotations);
	}

	public void setIgnoreTransientFields(boolean ignoreTransientFields)
	{
		this.ignoreTransientFields = ignoreTransientFields;
	}

	public void setIgnorePublicFields(boolean ignorePublicFields)
	{
		this.ignorePublicFields = ignorePublicFields;
	}

	public void setJavascriptCompliant(boolean javascriptCompliant)
	{
		this.javascriptCompliant = javascriptCompliant;
	}

	public void setJavaIdentifierTransformer(JavaIdentifierTransformer javaIdentifierTransformer)
	{
		this.javaIdentifierTransformer = javaIdentifierTransformer != null ? javaIdentifierTransformer : DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
	}

	public void setJavaPropertyFilter(PropertyFilter javaPropertyFilter)
	{
		this.javaPropertyFilter = javaPropertyFilter;
	}

	public void setJavaPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher)
	{
		javaPropertyNameProcessorMatcher = propertyNameProcessorMatcher != null ? propertyNameProcessorMatcher : DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
	}

	public void setJsonBeanProcessorMatcher(JsonBeanProcessorMatcher jsonBeanProcessorMatcher)
	{
		this.jsonBeanProcessorMatcher = jsonBeanProcessorMatcher != null ? jsonBeanProcessorMatcher : DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
	}

	public void setJsonPropertyFilter(PropertyFilter jsonPropertyFilter)
	{
		this.jsonPropertyFilter = jsonPropertyFilter;
	}

	public void setJsonPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher)
	{
		jsonPropertyNameProcessorMatcher = propertyNameProcessorMatcher != null ? propertyNameProcessorMatcher : DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
	}

	public void setJsonValueProcessorMatcher(JsonValueProcessorMatcher jsonValueProcessorMatcher)
	{
		this.jsonValueProcessorMatcher = jsonValueProcessorMatcher != null ? jsonValueProcessorMatcher : DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
	}

	public void setNewBeanInstanceStrategy(NewBeanInstanceStrategy newBeanInstanceStrategy)
	{
		this.newBeanInstanceStrategy = newBeanInstanceStrategy != null ? newBeanInstanceStrategy : DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
	}

	public void setPropertyExclusionClassMatcher(PropertyExclusionClassMatcher propertyExclusionClassMatcher)
	{
		this.propertyExclusionClassMatcher = propertyExclusionClassMatcher != null ? propertyExclusionClassMatcher : DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
	}

	/**
	 * @deprecated Method setPropertyNameProcessorMatcher is deprecated
	 */

	public void setPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher)
	{
		setJavaPropertyNameProcessorMatcher(propertyNameProcessorMatcher);
	}

	public void setPropertySetStrategy(PropertySetStrategy propertySetStrategy)
	{
		this.propertySetStrategy = propertySetStrategy;
	}

	public void setRootClass(Class rootClass)
	{
		this.rootClass = rootClass;
	}

	public void setSkipJavaIdentifierTransformationInMapKeys(boolean skipJavaIdentifierTransformationInMapKeys)
	{
		this.skipJavaIdentifierTransformationInMapKeys = skipJavaIdentifierTransformationInMapKeys;
	}

	public void unregisterDefaultValueProcessor(Class target)
	{
		if (target != null)
			defaultValueMap.remove(target);
	}

	public void unregisterJavaPropertyNameProcessor(Class target)
	{
		if (target != null)
			javaPropertyNameProcessorMap.remove(target);
	}

	public void unregisterJsonBeanProcessor(Class target)
	{
		if (target != null)
			beanProcessorMap.remove(target);
	}

	public void unregisterJsonPropertyNameProcessor(Class target)
	{
		if (target != null)
			jsonPropertyNameProcessorMap.remove(target);
	}

	public void unregisterJsonValueProcessor(Class propertyType)
	{
		if (propertyType != null)
			typeMap.remove(propertyType);
	}

	public void unregisterJsonValueProcessor(Class beanClass, Class propertyType)
	{
		if (beanClass != null && propertyType != null)
			beanTypeMap.remove(beanClass, propertyType);
	}

	public void unregisterJsonValueProcessor(Class beanClass, String key)
	{
		if (beanClass != null && key != null)
			beanKeyMap.remove(beanClass, key);
	}

	public void unregisterJsonValueProcessor(String key)
	{
		if (key != null)
			keyMap.remove(key);
	}

	public void unregisterPropertyExclusion(Class target, String propertyName)
	{
		if (target != null && propertyName != null)
		{
			Set set = (Set)exclusionMap.get(target);
			if (set == null)
			{
				set = new HashSet();
				exclusionMap.put(target, set);
			}
			set.remove(propertyName);
		}
	}

	public void unregisterPropertyExclusions(Class target)
	{
		if (target != null)
		{
			Set set = (Set)exclusionMap.get(target);
			if (set != null)
				set.clear();
		}
	}

	/**
	 * @deprecated Method unregisterPropertyNameProcessor is deprecated
	 */

	public void unregisterPropertyNameProcessor(Class target)
	{
		unregisterJavaPropertyNameProcessor(target);
	}

	static 
	{
		DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER = DefaultValueProcessorMatcher.DEFAULT;
		DEFAULT_JSON_BEAN_PROCESSOR_MATCHER = JsonBeanProcessorMatcher.DEFAULT;
		DEFAULT_JSON_VALUE_PROCESSOR_MATCHER = JsonValueProcessorMatcher.DEFAULT;
		DEFAULT_NEW_BEAN_INSTANCE_STRATEGY = NewBeanInstanceStrategy.DEFAULT;
		DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER = PropertyExclusionClassMatcher.DEFAULT;
		DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER = PropertyNameProcessorMatcher.DEFAULT;
		DEFAULT_COLLECTION_TYPE = java.util.List.class;
		DEFAULT_CYCLE_DETECTION_STRATEGY = CycleDetectionStrategy.STRICT;
		DEFAULT_JAVA_IDENTIFIER_TRANSFORMER = JavaIdentifierTransformer.NOOP;
	}
}
