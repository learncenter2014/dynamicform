// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AbstractJSON.java

package net.sf.json;

import java.lang.ref.SoftReference;
import java.util.*;
import net.sf.json.util.JSONUtils;
import net.sf.json.util.JsonEventListener;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

// Referenced classes of package net.sf.json:
//			JSONString, JSON, JSONException, JsonConfig, 
//			JSONNull, JSONFunction, JSONSerializer, JSONArray, 
//			JSONObject

abstract class AbstractJSON
{
	private static class CycleSet extends ThreadLocal
	{

		protected Object initialValue()
		{
			return new SoftReference(new HashSet());
		}

		public Set getSet()
		{
			Set set = (Set)((SoftReference)get()).get();
			if (set == null)
			{
				set = new HashSet();
				set(new SoftReference(set));
			}
			return set;
		}

		private CycleSet()
		{
		}

	}


	private static CycleSet cycleSet = new CycleSet();
	private static final Log log;

	AbstractJSON()
	{
	}

	protected static boolean addInstance(Object instance)
	{
		return getCycleSet().add(instance);
	}

	protected static void fireArrayEndEvent(JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onArrayEnd();
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireArrayStartEvent(JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onArrayStart();
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireElementAddedEvent(int index, Object element, JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onElementAdded(index, element);
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireErrorEvent(JSONException jsone, JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onError(jsone);
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireObjectEndEvent(JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onObjectEnd();
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireObjectStartEvent(JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onObjectStart();
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void firePropertySetEvent(String key, Object value, boolean accumulated, JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onPropertySet(key, value, accumulated);
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void fireWarnEvent(String warning, JsonConfig jsonConfig)
	{
		if (jsonConfig.isEventTriggeringEnabled())
		{
			for (Iterator listeners = jsonConfig.getJsonEventListeners().iterator(); listeners.hasNext();)
			{
				JsonEventListener listener = (JsonEventListener)listeners.next();
				try
				{
					listener.onWarning(warning);
				}
				catch (RuntimeException e)
				{
					log.warn(e);
				}
			}

		}
	}

	protected static void removeInstance(Object instance)
	{
		getCycleSet().remove(instance);
	}

	protected Object _processValue(Object value, JsonConfig jsonConfig)
	{
		String str;
		if (JSONNull.getInstance().equals(value))
			return JSONNull.getInstance();
		if ((java.lang.Class.class).isAssignableFrom(value.getClass()) || (value instanceof Class))
			return ((Class)value).getName();
		if (JSONUtils.isFunction(value))
		{
			if (value instanceof String)
				value = JSONFunction.parse((String)value);
			return value;
		}
		if (value instanceof JSONString)
			return JSONSerializer.toJSON((JSONString)value, jsonConfig);
		if (value instanceof JSON)
			return JSONSerializer.toJSON(value, jsonConfig);
		if (JSONUtils.isArray(value))
			return JSONArray.fromObject(value, jsonConfig);
		if (!JSONUtils.isString(value))
			break MISSING_BLOCK_LABEL_233;
		str = String.valueOf(value);
		if (JSONUtils.hasQuotes(str))
		{
			str = JSONUtils.stripQuotes(str);
			if (JSONUtils.isFunction(str))
				return "\"" + str + "\"";
			else
				return str;
		}
		if (JSONUtils.isJsonKeyword(str, jsonConfig))
			if (jsonConfig.isJavascriptCompliant() && "undefined".equals(str))
				return JSONNull.getInstance();
			else
				return str;
		if (!JSONUtils.mayBeJSON(str))
			break MISSING_BLOCK_LABEL_231;
		return JSONSerializer.toJSON(str, jsonConfig);
		JSONException jsone;
		jsone;
		return str;
		return str;
		if (JSONUtils.isNumber(value))
		{
			JSONUtils.testValidity(value);
			return JSONUtils.transformNumber((Number)value);
		}
		if (JSONUtils.isBoolean(value))
			return value;
		JSONObject jsonObject = JSONObject.fromObject(value, jsonConfig);
		if (jsonObject.isNullObject())
			return JSONNull.getInstance();
		else
			return jsonObject;
	}

	private static Set getCycleSet()
	{
		return cycleSet.getSet();
	}

	static 
	{
		log = LogFactory.getLog(net.sf.json.AbstractJSON.class);
	}
}
