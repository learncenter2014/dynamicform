// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONNull.java

package net.sf.json;

import java.io.IOException;
import java.io.Writer;

// Referenced classes of package net.sf.json:
//			JSONObject, JSONException, JSON

public final class JSONNull
	implements JSON
{

	private static JSONNull instance = new JSONNull();

	public static JSONNull getInstance()
	{
		return instance;
	}

	private JSONNull()
	{
	}

	public boolean equals(Object object)
	{
		return object == null || object == this || object == instance || (object instanceof JSONObject) && ((JSONObject)object).isNullObject() || "null".equals(object);
	}

	public int hashCode()
	{
		return 37 + "null".hashCode();
	}

	public boolean isArray()
	{
		return false;
	}

	public boolean isEmpty()
	{
		throw new JSONException("Object is null");
	}

	public int size()
	{
		throw new JSONException("Object is null");
	}

	public String toString()
	{
		return "null";
	}

	public String toString(int indentFactor)
	{
		return toString();
	}

	public String toString(int indentFactor, int indent)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < indent; i++)
			sb.append(' ');

		sb.append(toString());
		return sb.toString();
	}

	public Writer write(Writer writer)
	{
		writer.write(toString());
		return writer;
		IOException e;
		e;
		throw new JSONException(e);
	}

}
