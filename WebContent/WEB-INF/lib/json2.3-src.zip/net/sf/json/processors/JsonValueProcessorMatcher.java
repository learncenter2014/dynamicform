// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonValueProcessorMatcher.java

package net.sf.json.processors;

import java.util.Set;

public abstract class JsonValueProcessorMatcher
{
	private static final class DefaultJsonValueProcessorMatcher extends JsonValueProcessorMatcher
	{

		public Object getMatch(Class target, Set set)
		{
			if (target != null && set != null && set.contains(target))
				return target;
			else
				return null;
		}

		private DefaultJsonValueProcessorMatcher()
		{
		}

	}


	public static final JsonValueProcessorMatcher DEFAULT = new DefaultJsonValueProcessorMatcher();

	public JsonValueProcessorMatcher()
	{
	}

	public abstract Object getMatch(Class class1, Set set);

}
