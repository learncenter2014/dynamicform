// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsDateJsonValueProcessor.java

package net.sf.json.processors;

import net.sf.json.JsonConfig;

// Referenced classes of package net.sf.json.processors:
//			JsDateJsonBeanProcessor, JsonValueProcessor, JsonBeanProcessor

public class JsDateJsonValueProcessor
	implements JsonValueProcessor
{

	private JsonBeanProcessor processor;

	public JsDateJsonValueProcessor()
	{
		processor = new JsDateJsonBeanProcessor();
	}

	public Object processArrayValue(Object value, JsonConfig jsonConfig)
	{
		return process(value, jsonConfig);
	}

	public Object processObjectValue(String key, Object value, JsonConfig jsonConfig)
	{
		return process(value, jsonConfig);
	}

	private Object process(Object value, JsonConfig jsonConfig)
	{
		return processor.processBean(value, jsonConfig);
	}
}
