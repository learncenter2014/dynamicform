// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DefaultDefaultValueProcessor.java

package net.sf.json.processors;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.util.JSONUtils;

// Referenced classes of package net.sf.json.processors:
//			DefaultValueProcessor

public class DefaultDefaultValueProcessor
	implements DefaultValueProcessor
{

	public DefaultDefaultValueProcessor()
	{
	}

	public Object getDefaultValue(Class type)
	{
		if (JSONUtils.isArray(type))
			return new JSONArray();
		if (JSONUtils.isNumber(type))
			if (JSONUtils.isDouble(type))
				return new Double(0.0D);
			else
				return new Integer(0);
		if (JSONUtils.isBoolean(type))
			return Boolean.FALSE;
		if (JSONUtils.isString(type))
			return "";
		else
			return JSONNull.getInstance();
	}
}
