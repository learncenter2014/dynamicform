// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DefaultValueProcessorMatcher.java

package net.sf.json.processors;

import java.util.Set;

public abstract class DefaultValueProcessorMatcher
{
	private static final class DefaultDefaultValueProcessorMatcher extends DefaultValueProcessorMatcher
	{

		public Object getMatch(Class target, Set set)
		{
			if (target != null && set != null && set.contains(target))
				return target;
			else
				return null;
		}

		private DefaultDefaultValueProcessorMatcher()
		{
		}

	}


	public static final DefaultValueProcessorMatcher DEFAULT = new DefaultDefaultValueProcessorMatcher();

	public DefaultValueProcessorMatcher()
	{
	}

	public abstract Object getMatch(Class class1, Set set);

}
