// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsDateJsonBeanProcessor.java

package net.sf.json.processors;

import java.sql.Date;
import java.util.Calendar;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

// Referenced classes of package net.sf.json.processors:
//			JsonBeanProcessor

public class JsDateJsonBeanProcessor
	implements JsonBeanProcessor
{

	public JsDateJsonBeanProcessor()
	{
	}

	public JSONObject processBean(Object bean, JsonConfig jsonConfig)
	{
		JSONObject jsonObject = null;
		if (bean instanceof Date)
			bean = new java.util.Date(((Date)bean).getTime());
		if (bean instanceof java.util.Date)
		{
			Calendar c = Calendar.getInstance();
			c.setTime((java.util.Date)bean);
			jsonObject = (new JSONObject()).element("year", c.get(1)).element("month", c.get(2)).element("day", c.get(5)).element("hours", c.get(11)).element("minutes", c.get(12)).element("seconds", c.get(13)).element("milliseconds", c.get(14));
		} else
		{
			jsonObject = new JSONObject(true);
		}
		return jsonObject;
	}
}
