// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JsonVerifier.java

package net.sf.json.processors;

import java.math.BigDecimal;
import java.math.BigInteger;
import net.sf.json.*;

public final class JsonVerifier
{

	public JsonVerifier()
	{
	}

	public static boolean isValidJsonValue(Object value)
	{
		return JSONNull.getInstance().equals(value) || (value instanceof JSON) || (value instanceof Boolean) || (value instanceof Byte) || (value instanceof Short) || (value instanceof Integer) || (value instanceof Long) || (value instanceof Double) || (value instanceof BigInteger) || (value instanceof BigDecimal) || (value instanceof JSONFunction) || (value instanceof JSONString) || (value instanceof String);
	}
}
