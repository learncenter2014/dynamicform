// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONException.java

package net.sf.json;

import org.apache.commons.lang.exception.NestableRuntimeException;

public class JSONException extends NestableRuntimeException
{

	private static final long serialVersionUID = 0x61138a9fcf312ca7L;

	public JSONException()
	{
	}

	public JSONException(String msg)
	{
		super(msg, null);
	}

	public JSONException(String msg, Throwable cause)
	{
		super(msg, cause);
	}

	public JSONException(Throwable cause)
	{
		super(cause != null ? cause.toString() : null, cause);
	}
}
