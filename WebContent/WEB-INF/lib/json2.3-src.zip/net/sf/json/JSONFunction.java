// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSONFunction.java

package net.sf.json;

import java.io.Serializable;
import net.sf.json.util.JSONUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

// Referenced classes of package net.sf.json:
//			JSONException

public class JSONFunction
	implements Serializable
{

	private static final String EMPTY_PARAM_ARRAY[] = new String[0];
	private String params[];
	private String text;

	public static JSONFunction parse(String str)
	{
		if (!JSONUtils.isFunction(str))
		{
			throw new JSONException("String is not a function. " + str);
		} else
		{
			String params = JSONUtils.getFunctionParams(str);
			String text = JSONUtils.getFunctionBody(str);
			return new JSONFunction(params == null ? null : StringUtils.split(params, ","), text == null ? "" : text);
		}
	}

	public JSONFunction(String text)
	{
		this(null, text);
	}

	public JSONFunction(String params[], String text)
	{
		this.text = text == null ? "" : text.trim();
		if (params != null)
		{
			if (params.length == 1 && params[0].trim().equals(""))
			{
				this.params = EMPTY_PARAM_ARRAY;
			} else
			{
				this.params = new String[params.length];
				System.arraycopy(params, 0, this.params, 0, params.length);
				for (int i = 0; i < params.length; i++)
					this.params[i] = this.params[i].trim();

			}
		} else
		{
			this.params = EMPTY_PARAM_ARRAY;
		}
	}

	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof String))
			break MISSING_BLOCK_LABEL_37;
		JSONFunction other = parse((String)obj);
		return equals(other);
		JSONException e;
		e;
		return false;
		if (!(obj instanceof JSONFunction))
			return false;
		e = (JSONFunction)obj;
		if (params.length != ((JSONFunction) (e)).params.length)
			return false;
		EqualsBuilder builder = new EqualsBuilder();
		for (int i = 0; i < params.length; i++)
			builder.append(params[i], ((JSONFunction) (e)).params[i]);

		builder.append(text, ((JSONFunction) (e)).text);
		return builder.isEquals();
	}

	public String[] getParams()
	{
		return params;
	}

	public String getText()
	{
		return text;
	}

	public int hashCode()
	{
		HashCodeBuilder builder = new HashCodeBuilder();
		for (int i = 0; i < params.length; i++)
			builder.append(params[i]);

		builder.append(text);
		return builder.toHashCode();
	}

	public String toString()
	{
		StringBuffer b = new StringBuffer("function(");
		if (params.length > 0)
		{
			for (int i = 0; i < params.length - 1; i++)
				b.append(params[i]).append(',');

			b.append(params[params.length - 1]);
		}
		b.append("){");
		if (text.length() > 0)
			b.append(' ').append(text).append(' ');
		b.append('}');
		return b.toString();
	}

}
